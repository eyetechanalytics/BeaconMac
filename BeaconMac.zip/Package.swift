// swift-tools-version: 5.9
// BeaconMac — Mac Keyboard Shortcuts Reference App
// Build: swift build -c release
// Create .app bundle: ./build-app.sh

import PackageDescription

let package = Package(
    name: "BeaconMac",
    platforms: [
        .macOS(.v12)
    ],
    products: [
        .executable(name: "BeaconMac", targets: ["BeaconMac"])
    ],
    targets: [
        .executableTarget(
            name: "BeaconMac",
            dependencies: [],
            path: "Sources/BeaconMac",
            swiftSettings: [
                .unsafeFlags(["-framework", "AppKit", "-framework", "WebKit"])
            ]
        )
    ]
)
