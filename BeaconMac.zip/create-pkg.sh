#!/bin/bash
# =============================================================================
#  create-pkg.sh — Build BeaconMac and package it as a macOS Installer (.pkg)
#
#  The PKG installer is the most accessible distribution format for VoiceOver
#  users.  Apple's Installer.app is a fully native, step-by-step wizard that
#  VoiceOver reads clearly at every step — no dragging, no Finder navigation.
#  Users double-click the .pkg, click Continue / Install / Close, and the app
#  is placed in /Applications automatically.
#
#  Usage:
#    chmod +x create-pkg.sh
#    ./create-pkg.sh
#
#  Output:
#    BeaconMac-1.0.0.pkg   (installer, upload this to your website)
#
#  Requirements:
#    • Xcode Command Line Tools  (xcode-select --install)
#    • build-app.sh must be in the same folder
# =============================================================================

set -e

APP_NAME="BeaconMac"
BUNDLE_ID="com.eyetechanalytics.BeaconMac"
VERSION="1.0.0"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
APP_BUNDLE="$SCRIPT_DIR/$APP_NAME.app"
STAGING_DIR="$SCRIPT_DIR/.pkg-staging"
PKG_OUTPUT="$SCRIPT_DIR/${APP_NAME}-${VERSION}.pkg"

echo "──────────────────────────────────────────────────"
echo "  Creating BeaconMac $VERSION Installer (.pkg)"
echo "──────────────────────────────────────────────────"

# ── Step 1: Build the app ────────────────────────────────────────────────────
echo ""
echo "▸ Building app bundle..."
bash "$SCRIPT_DIR/build-app.sh"

if [ ! -d "$APP_BUNDLE" ]; then
    echo "✗ App bundle not found at $APP_BUNDLE — build-app.sh may have failed."
    exit 1
fi

# ── Step 2: Prepare staging area ─────────────────────────────────────────────
echo ""
echo "▸ Preparing installer staging area..."
rm -rf "$STAGING_DIR"
mkdir -p "$STAGING_DIR/scripts"
mkdir -p "$STAGING_DIR/resources"

# ── Step 3: Write installer resources ────────────────────────────────────────
# welcome.html — shown on the first screen of the installer
cat > "$STAGING_DIR/resources/welcome.html" << 'WELCOME'
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"/></head>
<body>
<h1>Welcome to BeaconMac</h1>
<p>BeaconMac is a keyboard shortcut reference tool for macOS with full
VoiceOver support. It gives you instant access to 82 shortcut guides
covering macOS, Microsoft Office, Google Workspace, Adobe Creative Suite,
developer tools, and more — from any app, with a single keystroke.</p>

<p>This installer will place <strong>BeaconMac.app</strong> in your
<strong>Applications</strong> folder. No other files are installed.</p>

<p>After installation, launch BeaconMac from Applications and grant
Accessibility permission when prompted so the global hotkey can work
from any app.</p>
</body>
</html>
WELCOME

# readme.html — shown on the "Read Me" screen
cat > "$STAGING_DIR/resources/readme.html" << 'README'
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"/></head>
<body>
<h1>Before You Begin</h1>

<h2>System Requirements</h2>
<p>macOS Monterey (12.0) or later. Apple Silicon and Intel both supported.</p>

<h2>Accessibility Permission</h2>
<p>BeaconMac needs one permission to function: Accessibility. This lets it
detect the global hotkey (default: Control + Option + G) from any app.
On first launch, macOS will ask you to grant this in System Settings →
Privacy &amp; Security → Accessibility.</p>

<h2>VoiceOver Navigation</h2>
<p>Once running, press the hotkey to open the guide list. Navigate guides
with Up and Down Arrow. Press Return to open a guide. Inside a guide, use
VO + Right / Left Arrow to move through shortcuts, and H or Shift + H to
jump between section headings. Press Escape to return to the guide list.</p>

<h2>Uninstalling</h2>
<p>Drag BeaconMac.app from your Applications folder to the Trash.
No other files need to be removed.</p>
</body>
</html>
README

# ── Step 4: Build component package ──────────────────────────────────────────
echo ""
echo "▸ Building component package..."
COMPONENT_PKG="$STAGING_DIR/BeaconMac-component.pkg"

pkgbuild \
    --install-location /Applications \
    --component "$APP_BUNDLE" \
    --identifier "$BUNDLE_ID" \
    --version "$VERSION" \
    "$COMPONENT_PKG"

echo "  ✓ Component package built"

# ── Step 5: Write distribution XML ───────────────────────────────────────────
# The distribution XML controls the installer wizard: title, welcome/readme
# pages, and which component packages to install.
DIST_XML="$STAGING_DIR/distribution.xml"
cat > "$DIST_XML" << DISTXML
<?xml version="1.0" encoding="utf-8"?>
<installer-gui-script minSpecVersion="2">

    <title>BeaconMac $VERSION</title>
    <organization>com.eyetechanalytics</organization>

    <!-- Show Welcome and ReadMe screens before the install destination step -->
    <welcome    file="welcome.html" mime-type="text/html"/>
    <readme     file="readme.html"  mime-type="text/html"/>

    <!-- Restrict to the boot volume — single-machine installs only -->
    <allowed-os-versions>
        <os-version min="12.0"/>
    </allowed-os-versions>
    <options customize="never" require-scripts="false" hostArchitectures="x86_64,arm64"/>

    <!-- Single-choice install: no component selection screen -->
    <choices-outline>
        <line choice="default"/>
    </choices-outline>

    <choice id="default" visible="false">
        <pkg-ref id="$BUNDLE_ID"/>
    </choice>

    <pkg-ref id="$BUNDLE_ID" version="$VERSION" onConclusion="none">BeaconMac-component.pkg</pkg-ref>

</installer-gui-script>
DISTXML

echo "  ✓ Distribution XML written"

# ── Step 6: Build the final product archive ───────────────────────────────────
echo ""
echo "▸ Building installer package..."

# Check whether a signing identity is available for the PKG itself
PKG_SIGN_ARGS=""
SIGN_ID=$(security find-identity -v -p basic 2>/dev/null \
    | grep '"Developer ID Installer' | grep -v "REVOKED" | head -1 \
    | sed 's/.*"\(.*\)".*/\1/')

if [ -n "$SIGN_ID" ]; then
    PKG_SIGN_ARGS="--sign \"$SIGN_ID\""
    echo "  ✓ Will sign PKG with: $SIGN_ID"
else
    echo "  ℹ No 'Developer ID Installer' certificate found — PKG will be unsigned."
    echo "    Users can still install it via right-click > Open."
    echo "    For a fully signed/notarized PKG, enroll in the Apple Developer Program."
fi

productbuild \
    --distribution "$DIST_XML" \
    --package-path "$STAGING_DIR" \
    --resources "$STAGING_DIR/resources" \
    ${SIGN_ID:+--sign "$SIGN_ID"} \
    "$PKG_OUTPUT"

# ── Step 7: Clean up staging ─────────────────────────────────────────────────
rm -rf "$STAGING_DIR"

# ── Step 8: Verify and summarise ─────────────────────────────────────────────
if [ ! -f "$PKG_OUTPUT" ]; then
    echo "✗ PKG not created — productbuild may have failed."
    exit 1
fi

PKG_SIZE=$(du -sh "$PKG_OUTPUT" | cut -f1)

echo ""
echo "──────────────────────────────────────────────────"
echo "  ✓ Installer ready!"
echo ""
echo "  File:     $PKG_OUTPUT"
echo "  Size:     $PKG_SIZE"
echo ""
echo "  Upload BeaconMac-$VERSION.pkg to:"
echo "  https://eyetechanalytics.com/wp-content/uploads/downloads/"
echo "  (rename to BeaconMac.pkg so the update URL stays constant)"
echo ""
echo "  Installation experience for users:"
echo "    1. Double-click BeaconMac.pkg"
echo "    2. Click Continue through the Welcome and Read Me screens"
echo "    3. Click Install — enter password or use Touch ID if prompted"
echo "    4. Click Close"
echo "    5. Launch BeaconMac from Applications"
echo "──────────────────────────────────────────────────"
