#!/bin/bash
# =============================================================================
#  build-app.sh — Build BeaconMac and package it as a macOS .app bundle
#
#  Usage:
#    chmod +x build-app.sh
#    ./build-app.sh
#
#  Output: BeaconMac.app  (in the same folder as this script)
#  Requirements: Xcode Command Line Tools (xcode-select --install)
# =============================================================================

set -e  # Exit on any error

APP_NAME="BeaconMac"
BUNDLE_ID="com.eyetechanalytics.BeaconMac"
VERSION="1.0.0"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
APP_BUNDLE="$SCRIPT_DIR/$APP_NAME.app"
MACOS_DIR="$APP_BUNDLE/Contents/MacOS"
RESOURCES_DIR="$APP_BUNDLE/Contents/Resources"

echo "──────────────────────────────────────────"
echo "  Building BeaconMac $VERSION"
echo "──────────────────────────────────────────"

# ── Step 1: Compile with Swift Package Manager ──────────────────────────────
echo ""
echo "▸ Compiling (swift build -c release)..."
cd "$SCRIPT_DIR"
swift build -c release 2>&1

BINARY="$SCRIPT_DIR/.build/release/$APP_NAME"
if [ ! -f "$BINARY" ]; then
    echo "✗ Build failed — binary not found at $BINARY"
    exit 1
fi
echo "  ✓ Binary built: $BINARY"

# ── Step 2: Create .app bundle structure ────────────────────────────────────
echo ""
echo "▸ Creating app bundle..."
rm -rf "$APP_BUNDLE"
mkdir -p "$MACOS_DIR"
mkdir -p "$RESOURCES_DIR"

# Copy executable
cp "$BINARY" "$MACOS_DIR/$APP_NAME"
chmod +x "$MACOS_DIR/$APP_NAME"

# Copy Info.plist
cp "$SCRIPT_DIR/Resources/Info.plist" "$APP_BUNDLE/Contents/Info.plist"

# Copy app icon
if [ -f "$SCRIPT_DIR/Resources/BeaconMac.icns" ]; then
    cp "$SCRIPT_DIR/Resources/BeaconMac.icns" "$RESOURCES_DIR/BeaconMac.icns"
    echo "  ✓ Icon copied: BeaconMac.icns"
else
    echo "  ⚠ No icon found at Resources/BeaconMac.icns — app will use default icon"
fi

echo "  ✓ App bundle created: $APP_BUNDLE"

# ── Step 3: Code signing ─────────────────────────────────────────────────────
# WHY A REAL CERTIFICATE IS IMPORTANT:
#   Ad-hoc signing ("codesign --sign -") embeds a hash-based identity unique to
#   each compiled binary.  Without any signature, macOS 12+ ALSO computes an
#   implicit code-directory hash for unsigned binaries and stores it in TCC.
#   Either way, every "swift build" changes the binary → changes the hash →
#   macOS TCC sees a brand-new unknown app and REVOKES the Accessibility
#   permission, forcing you to re-grant it every single time you rebuild.
#
#   Signing with a REAL certificate (Developer ID, Apple Development, or even a
#   self-signed cert created in Keychain Access) gives TCC a STABLE identity.
#   The permission is tied to the certificate, so it survives every rebuild as
#   long as the .app stays in the same location (/Applications/).
#
# HOW TO CREATE A FREE LOCAL CERTIFICATE (one-time, 5 minutes):
#   1. Open Keychain Access  (Applications > Utilities > Keychain Access)
#   2. Menu: Keychain Access > Certificate Assistant > Create a Certificate…
#   3.   Name:              BeaconMac-Dev
#        Identity Type:     Self Signed Root
#        Certificate Type:  Code Signing
#   4. Expand "▶ Override Defaults" — accept every screen as-is — click Create
#   5. Re-run ./build-app.sh — it will find and use the new certificate
#      automatically, and your Accessibility permission will persist forever.
#
# FOR PUBLIC DISTRIBUTION:
#   Sign with an Apple Developer ID and notarize with "xcrun notarytool".
#   See: https://developer.apple.com/documentation/security/notarizing_macos_software_before_distribution

echo ""
echo "▸ Code signing..."

# ── Find the best available stable code-signing identity ─────────────────────
# Helper: returns the first cert CN matching a grep pattern (skips REVOKED entries)
find_cert() {
    security find-identity -v -p codesigning 2>/dev/null \
        | grep "\"$1" | grep -v "REVOKED" | head -1 \
        | sed 's/.*"\(.*\)".*/\1/'
}

SIGNING_IDENTITY=""

# Priority 1 — Apple Developer ID (best for distribution)
[ -z "$SIGNING_IDENTITY" ] && SIGNING_IDENTITY=$(find_cert "Developer ID Application")
# Priority 2 — Apple Development (Xcode + Apple ID, free)
[ -z "$SIGNING_IDENTITY" ] && SIGNING_IDENTITY=$(find_cert "Apple Development")
# Priority 3 — Mac Developer (older Xcode cert name)
[ -z "$SIGNING_IDENTITY" ] && SIGNING_IDENTITY=$(find_cert "Mac Developer")
# Priority 4 — Any local cert that has "BeaconMac" in the name
[ -z "$SIGNING_IDENTITY" ] && SIGNING_IDENTITY=$(find_cert "BeaconMac")
# Priority 5 — Any non-revoked codesigning cert at all
if [ -z "$SIGNING_IDENTITY" ]; then
    SIGNING_IDENTITY=$(security find-identity -v -p codesigning 2>/dev/null \
        | grep '"' | grep -v "REVOKED" | head -1 \
        | sed 's/.*"\(.*\)".*/\1/')
fi

if [ -n "$SIGNING_IDENTITY" ]; then
    if codesign --force --deep --sign "$SIGNING_IDENTITY" "$APP_BUNDLE" 2>/dev/null; then
        echo "  ✓ Signed with: $SIGNING_IDENTITY"
        echo "  ✓ Accessibility permission will persist across rebuilds"
    else
        echo "  ⚠ Signing with '$SIGNING_IDENTITY' failed — falling back to ad-hoc"
        SIGNING_IDENTITY=""
    fi
fi

if [ -z "$SIGNING_IDENTITY" ]; then
    # Last resort — ad-hoc, but warn the user loudly
    codesign --force --deep --sign - "$APP_BUNDLE" 2>/dev/null || true
    echo ""
    echo "  ╔══════════════════════════════════════════════════════════════╗"
    echo "  ║  ⚠  NO STABLE CODE-SIGNING CERTIFICATE FOUND               ║"
    echo "  ║                                                              ║"
    echo "  ║  An ad-hoc (hash-based) signature was applied as a fallback.║"
    echo "  ║  Every rebuild will change the binary hash, causing macOS to ║"
    echo "  ║  REVOKE the Accessibility permission — so you'll be prompted ║"
    echo "  ║  to re-grant it after every build.                          ║"
    echo "  ║                                                              ║"
    echo "  ║  Fix: create a free local certificate ONCE (5 min):         ║"
    echo "  ║  1. Open Keychain Access > Certificate Assistant >          ║"
    echo "  ║     Create a Certificate…                                   ║"
    echo "  ║  2. Name: BeaconMac-Dev                                     ║"
    echo "  ║     Identity Type: Self Signed Root                         ║"
    echo "  ║     Certificate Type: Code Signing                          ║"
    echo "  ║  3. Accept all defaults → Create                            ║"
    echo "  ║  4. Re-run ./build-app.sh                                   ║"
    echo "  ╚══════════════════════════════════════════════════════════════╝"
    echo ""
fi

# ── Step 4: Remove quarantine (optional — for local testing) ────────────────
# If you're distributing the app, skip this step and let users open it via
# right-click > Open the first time.
echo ""
echo "▸ Removing quarantine attribute (local testing)..."
xattr -rd com.apple.quarantine "$APP_BUNDLE" 2>/dev/null && echo "  ✓ Quarantine removed" || echo "  (no quarantine to remove)"

# ── Step 5: Summary ──────────────────────────────────────────────────────────
echo ""
echo "──────────────────────────────────────────"
echo "  ✓ BeaconMac.app is ready!"
echo ""
echo "  Location:  $APP_BUNDLE"
echo ""
echo "  To install:"
echo "    cp -r \"$APP_BUNDLE\" /Applications/"
echo ""
echo "  To create a distributable ZIP:"
echo "    cd \"$SCRIPT_DIR\""
echo "    zip -r BeaconMac-$VERSION.zip BeaconMac.app"
echo ""
echo "  First launch:"
echo "    Open BeaconMac.app — if blocked by Gatekeeper,"
echo "    right-click the .app and choose Open."
echo "    Grant Accessibility permission when prompted."
echo "──────────────────────────────────────────"
