================================================================
        BEACONMAC SWIFT — NATIVE macOS APP
        Keyboard Shortcuts Reference System
        Version 1.0.0
================================================================

OVERVIEW
--------
BeaconMac Swift is a 100% native macOS application — no Hammerspoon,
no AutoHotkey, no dependencies. Just a single standalone .app that
you drag to Applications and run.

It provides an 82-guide keyboard shortcut reference covering macOS,
Apple iWork, Microsoft Office, Google Suite, and popular third-party
apps, packaged as a proper macOS binary that can be distributed on a
website, shared with colleagues, or deployed to multiple Macs without
any additional software.

  Source files:       BeaconMac-Swift/ (this folder)
  Technologies:       Swift 5.9, AppKit, WebKit
  macOS requirement:  12.0 (Monterey) or later
  Architecture:       Universal (Apple Silicon + Intel) if built with -arch arm64 -arch x86_64


================================================================
                    BUILDING THE APP
================================================================

OPTION A — Build Script (Recommended, one command)
----------------------------------------------------
  Run from INSIDE the BeaconMac-Swift folder:

  chmod +x build-app.sh
  ./build-app.sh

  Output: BeaconMac.app (in the same folder as the script)

  Note: the script locates itself automatically, so you can also
  run it from anywhere:
    /path/to/BeaconMac-Swift/build-app.sh


OPTION B — Xcode (for signing, notarizing, and distribution)
--------------------------------------------------------------
  1. Open Xcode
  2. File > New > Project > macOS > App
     Name: BeaconMac
     Bundle ID: com.yourname.BeaconMac
     Interface: None (NOT SwiftUI)
     Language: Swift

  3. Delete the auto-generated ContentView.swift and AppDelegate
     (or replace their contents with the files in Sources/BeaconMac/)

  4. Add all .swift files from Sources/BeaconMac/ to the project:
       main.swift, AppDelegate.swift, GlobalHotkey.swift,
       HotkeySetting.swift, PreferencesWindow.swift, AppDetector.swift,
       SearchPanel.swift, ContentWindow.swift, HTMLGenerator.swift,
       ShortcutGuide.swift, ShortcutContent.swift

  5. Add Info.plist from Resources/ to the project. In Build Settings,
     set "Info.plist File" to point to your Resources/Info.plist.

  6. In the project target's General settings:
     - Set "App Category" to Utilities
     - Check "App is agent (UIElement)" — or set LSUIElement in Info.plist

  7. Product > Build (⌘B), then Product > Archive to export a signed .app


OPTION C — Manual swift build
------------------------------
  cd BeaconMac-Swift
  swift build -c release

  The binary is at: .build/release/BeaconMac
  Manually wrap it:
    mkdir -p BeaconMac.app/Contents/{MacOS,Resources}
    cp .build/release/BeaconMac BeaconMac.app/Contents/MacOS/
    cp Resources/Info.plist BeaconMac.app/Contents/
    codesign --force --deep --sign - BeaconMac.app


OPTION D — Universal binary (Apple Silicon + Intel)
----------------------------------------------------
  If you have an Apple Developer account and want to support all Macs:

  swift build -c release \
    --arch arm64 \
    --arch x86_64

  Then follow the same wrapping steps as Option C.


================================================================
                    INSTALLING THE APP
================================================================

1. Copy BeaconMac.app to /Applications
   (drag and drop, or: cp -r BeaconMac.app /Applications/)

2. Open BeaconMac from Applications or Spotlight

3. If macOS Gatekeeper blocks it (first time, unsigned):
   Right-click the .app → choose Open → click Open in the dialog

4. Grant Accessibility permission when prompted:
   System Settings → Privacy & Security → Accessibility
   → Enable the toggle next to BeaconMac

5. The BeaconMac icon (⌨) appears in your menu bar.

6. Press Ctrl + Option + G to open the shortcut guide menu.


================================================================
                    USING THE APP
================================================================

Trigger:    Ctrl + Option + G  (anywhere on your Mac)
            — or click the ⌨ icon in the menu bar and choose
              "Open Shortcut Guide"

Focus-aware search:
  When you press the hotkey, BeaconMac detects which app you were
  just using and automatically pre-filters the search panel for
  that app's shortcuts.

  Examples:
    • You were in Excel  → panel opens showing "Excel" results
    • You were in Chrome → panel opens showing "Chrome" results
    • You were in an unrecognized app → panel opens unfiltered

  You can clear the search field (⌘A then Delete) at any time to
  see all 82 guides. The panel stays open, so you can type freely
  to search across every category.

  Recognized apps (auto-detected):
    macOS built-in: Finder, Safari, Mail, Calendar, Notes, Photos,
           Preview, Terminal / iTerm2, TextEdit, QuickTime, Calculator,
           Maps, Activity Monitor, System Settings, Xcode
    Apple iWork:    Pages, Numbers, Keynote
    Microsoft:      Word, Excel, PowerPoint, Outlook, OneNote,
                    Teams, OneDrive
    Google:         Chrome (including Canary)
    Other:          Firefox, Zoom, Slack, VS Code / VSCodium,
                    Adobe Acrobat / Reader, VLC, Spotify

  To add more apps, see ADDING SUPPORTED APPS below.

Search panel:
  • Start typing to instantly filter all 55 guides
  • Arrow keys Up/Down to navigate the list
  • Return or double-click to open a guide
  • Escape to close the search panel

Content window:
  • Shows full shortcut reference in a styled, scrollable window
  • Automatically adapts to your Mac's dark or light mode
  • Escape or the red close button to dismiss
  • Multiple guides can be open at the same time


================================================================
                    CHANGING THE HOTKEY
================================================================

METHOD A — In-app Preferences (recommended, no rebuild needed)
---------------------------------------------------------------
1. Click the ⌨ menu bar icon
2. Choose "Preferences…"  (or press ⌘,)
3. Click "Change Hotkey"
4. Press the new key combination you want
   (e.g. Ctrl+Shift+Space, Cmd+Option+B, etc.)
5. Click "Save"

The hotkey changes immediately — no restart required.
Your choice is saved to user preferences and persists across
app restarts.

Rules for recorded hotkeys:
  • Must include at least one modifier (⌃ ⌥ ⌘ ⇧)
  • Escape cancels the recording
  • Single-key shortcuts (no modifier) are not accepted


METHOD B — Default at compile time (change before building)
-----------------------------------------------------------
Open Sources/BeaconMac/HotkeySetting.swift and edit the
`default` static property:

    static let `default` = HotkeySetting(
        keyCode:   5,          // kVK_ANSI_G
        modifiers: ["ctrl", "alt"]
    )

Change keyCode and/or modifiers to your preferred combination.

Common key codes (from Carbon / IOKit):
  A=0  S=1  D=2  F=3  G=5  H=4  J=38 K=40 L=37
  Z=6  X=7  C=8  V=9  B=11 N=45 M=46
  Space=49 Tab=48 Return=36 Delete=51
  1=18 2=19 3=20 4=21 5=23 6=22 7=26 8=28 9=25 0=29
  F1=122 F2=120 F3=99 F4=118 F5=96 F6=97 F7=98 F8=100

Modifier strings (any combination):
  "ctrl"    = Control (⌃)
  "alt"     = Option (⌥)
  "cmd"     = Command (⌘)
  "shift"   = Shift (⇧)

After changing, rebuild with ./build-app.sh and reinstall.
(Users who have already saved a hotkey via Preferences will
keep their saved choice; the default only applies on first
launch before any preference has been saved.)


================================================================
                    ADDING SUPPORTED APPS
================================================================

When the hotkey fires, BeaconMac looks up the frontmost app in
AppDetector.swift and returns a search query to pre-fill the
panel.  To add a new app:

1. Open Sources/BeaconMac/AppDetector.swift

2. Find the `bundleIDMap` array near the top and add a tuple:

       ("com.example.myapp",   "MyApp"),

   The first string is a case-insensitive substring of the
   app's bundle ID; the second is the search query that will
   be pre-filled in the panel.  Choose the search query to
   match the guide's title (or category) in ShortcutContent.

3. Optionally add a matching entry in `appNameMap` as a
   fallback for cases where the bundle ID isn't available:

       ("myapp",   "MyApp"),

4. Rebuild: ./build-app.sh

To find an app's bundle ID on your Mac, run this in Terminal:
  osascript -e 'id of app "AppName"'
  e.g.: osascript -e 'id of app "Slack"'


================================================================
                    ADDING NEW SHORTCUT GUIDES
================================================================

1. Open Sources/BeaconMac/ShortcutContent.swift

2. Add a new content provider (anywhere in the enum, before allGuides):

   private static var GetMyAppContent: () -> String = {
       return """
       -- General --
       Cmd + K:                Do something useful
       Cmd + Shift + K:        Do something else

       -- Advanced --
       Cmd + Option + K:       Advanced action
       """
   }

3. Add an entry to the allGuides array:

   ShortcutGuide(
       id: "MyApp",
       title: "My App Shortcuts",
       description: "Keyboard shortcuts for My App",
       category: "Other Apps",
       content: GetMyAppContent
   ),

4. Rebuild: ./build-app.sh

Available categories (or add your own):
  "General"               "macOS System"
  "Microsoft Office (Mac)" "Office 365 Online"
  "Google Suite"          "macOS Built-in Apps"
  "Apple iWork"           "Other Apps"
  "Multimedia"            "Accessibility"
  "About"

Content format:
  -- Section Name --          (becomes a bold colored h2 header; VoiceOver H-key jumps here)
  >> Note text                (shown as an italic callout block below the header)
  Key: Action :: Context      (three-column row: key | action | context note)
  Key: Description            (two-column row; backward-compatible shorthand)
  (blank line)                (adds vertical spacing)
  Any other text              (shown as an italic grey note line)


================================================================
                    DISTRIBUTING ON YOUR WEBSITE
================================================================

After building BeaconMac.app:

  1. Create a ZIP for download:
       zip -r BeaconMac-1.0.0.zip BeaconMac.app

  2. Upload to your website as a direct download link.

  3. In your download instructions, include:
     a. "Double-click to open. If Gatekeeper blocks it:
        right-click the app → Open → Open"
     b. "Grant Accessibility permission when prompted
        (System Settings > Privacy & Security > Accessibility)"

  For broader distribution with seamless Gatekeeper approval:
  • Sign with an Apple Developer ID certificate ($99/year)
  • Notarize with Apple's notarization service (xcrun notarytool)
  • Staple the ticket to the .app
  • Then users can double-click to open without any security prompt

  See: https://developer.apple.com/documentation/security/notarizing_macos_software_before_distribution


================================================================
                    SOURCE FILE OVERVIEW
================================================================

Sources/BeaconMac/
  main.swift              Entry point. Creates NSApplication and AppDelegate.
  AppDelegate.swift       App lifecycle, NSStatusItem (menu bar icon),
                          hotkey wiring, focus-aware panel toggling,
                          Preferences menu item, and window management.
  GlobalHotkey.swift      Global hotkey registration via CGEventTap.
                          Uses a C callback bridge to call Swift code.
                          Supports runtime hotkey changes via updateSetting()
                          and recording suppression via suppressFiring.
                          Requires Accessibility permission.
  HotkeySetting.swift     Hotkey configuration struct: keyCode + modifiers.
                          Persists to UserDefaults. Provides displayString
                          (e.g. "⌃⌥G") and matches() for event comparison.
  PreferencesWindow.swift Single-window preferences UI with hotkey recorder.
                          Captures any key combo (with ≥1 modifier), shows
                          preview, and saves instantly without app restart.
  AppDetector.swift       Focus-aware app detection. Maps bundle IDs and
                          app names to pre-fill queries for the search panel.
                          Edit bundleIDMap / appNameMap to add more apps.
  SearchPanel.swift       The Spotlight-style floating search panel.
                          NSPanel + NSVisualEffectView + NSTableView.
                          Accepts an optional initialQuery to pre-filter
                          for the frontmost app.
                          Full keyboard navigation (arrows, Return, Escape).
  ContentWindow.swift     NSWindow wrapping WKWebView for guide display.
                          Cascades so multiple guides can be open at once.
  HTMLGenerator.swift     Converts raw shortcut text to styled HTML.
                          Uses CSS @media prefers-color-scheme for
                          automatic dark/light mode support.
  ShortcutGuide.swift     Data model: id, title, description, category,
                          content closure.
  ShortcutContent.swift   All 82 shortcut guides as Swift string literals.
                          The largest file (~5,100 lines) — edit this to add/change content.
                          Each guide has a dedicated VoiceOver Tips section where applicable.

Resources/
  Info.plist              App metadata: bundle ID, version, LSUIElement=true
                          (hides Dock icon), Accessibility usage description.

build-app.sh              Builds the release binary and wraps it into
                          a proper .app bundle. Run this to produce the
                          distributable app.


================================================================
                    TROUBLESHOOTING
================================================================

Hotkey does nothing after installing
  → Check Accessibility: System Settings > Privacy & Security > Accessibility
    Make sure BeaconMac has the toggle turned ON.
  → If the toggle is there but grayed out, try removing and re-adding it.
  → Restart BeaconMac after granting permission.

"BeaconMac can't be opened because Apple cannot check it for malicious software"
  → Right-click the .app → Open → click Open in the dialog.
  → This only happens once for unsigned apps.

Panel doesn't appear above full-screen apps
  → This is expected behavior for apps without a full-screen entitlement.
    The panel will appear when you exit the full-screen app.
    (To fix: add com.apple.security.temporary-exception.mach-lookup.* entitlement
    or use NSWindow.Level.screenSaver — not needed for typical use.)

App crashes immediately on launch
  → Open Console.app and filter by "BeaconMac" to see the error.
  → Common cause: missing Accessibility permission with a bad CGEventTap setup.

Swift build fails: "no such module 'AppKit'"
  → Make sure you're building on macOS, not Linux.
  → Run: xcode-select --install (to install Xcode Command Line Tools).

"Cannot find type 'ShortcutGuide'" compiler error
  → Make sure ShortcutGuide.swift is included in the target.
  → When using Swift Package Manager, all .swift files in the Sources/BeaconMac/
    folder are included automatically.

================================================================
