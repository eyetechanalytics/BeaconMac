// =============================================================================
//  UpdateChecker.swift — Background version check and update prompt
//
//  At launch, silently fetches a plain-text version file from the BeaconMac
//  website and compares it with the current build.  If a newer version is
//  available, shows a modal alert offering to open the download page.
//
//  Called from AppDelegate.applicationDidFinishLaunching with a short delay
//  (5 s) so it does not compete with startup work or accessibility prompts.
//
//  The version file at versionURL must contain only a semantic version string,
//  e.g. "1.1.0" (with an optional trailing newline).  Any network or parse
//  error is swallowed silently in the default (silent) mode.
//
//  For a manual "Check for Updates" from Preferences, call with silent: false —
//  that mode always shows a result to the user (up-to-date or error).
// =============================================================================
import AppKit

enum UpdateChecker {

    // MARK: - Version

    /// The version string embedded in this build.  Must match CFBundleShortVersionString.
    static let currentVersion = "1.0.0"

    // MARK: - URLs

    /// Plain-text file on the server: contains only the latest version string.
    /// Example file contents: "1.1.0"
    private static let versionURL = URL(string:
        "https://eyetechanalytics.com/wp-content/uploads/downloads/Beaconmac_version.txt")!

    /// Direct download URL for the latest BeaconMac installer package.
    private static let downloadURL = URL(string:
        "https://eyetechanalytics.com/wp-content/uploads/downloads/BeaconMac.pkg")!

    // MARK: - Public API

    /// Checks for updates on a background URLSession thread.
    ///
    /// - Parameter silent: When `true` (default), does nothing if the app is
    ///   already up to date or if the network is unreachable.  Pass `false` to
    ///   always show a result (used by the "Check for Updates" button).
    static func checkForUpdates(silent: Bool = true) {
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest  = 10
        config.timeoutIntervalForResource = 15
        let session = URLSession(configuration: config)

        let task = session.dataTask(with: versionURL) { data, _, error in
            guard error == nil,
                  let data = data,
                  let raw  = String(data: data, encoding: .utf8)?
                                  .trimmingCharacters(in: .whitespacesAndNewlines),
                  !raw.isEmpty
            else {
                if !silent {
                    DispatchQueue.main.async { showErrorAlert() }
                }
                return
            }

            // Validate: accept only version-looking strings (digits and dots)
            guard raw.range(of: #"^\d+(\.\d+)*$"#, options: .regularExpression) != nil else {
                if !silent {
                    DispatchQueue.main.async { showErrorAlert() }
                }
                return
            }

            if isNewer(raw, than: currentVersion) {
                DispatchQueue.main.async { showUpdateAlert(latestVersion: raw) }
            } else if !silent {
                DispatchQueue.main.async { showUpToDateAlert(latestVersion: raw) }
            }
        }
        task.resume()
    }

    // MARK: - Version Comparison

    /// Returns `true` if `candidate` is semantically newer than `current`.
    /// Handles any number of dot-separated components, e.g. "2.0" > "1.9.5".
    static func isNewer(_ candidate: String, than current: String) -> Bool {
        let a = candidate.split(separator: ".").compactMap { Int($0) }
        let b = current  .split(separator: ".").compactMap { Int($0) }
        let count = max(a.count, b.count)
        for i in 0..<count {
            let av = i < a.count ? a[i] : 0
            let bv = i < b.count ? b[i] : 0
            if av > bv { return true  }
            if av < bv { return false }
        }
        return false   // equal
    }

    // MARK: - Alerts (must be called on the main thread)

    // MARK: - Alert helpers

    /// Activates the app, then defers the actual alert one run-loop turn so
    /// AppKit has finished processing the activation before the modal appears.
    /// Without the deferral, a menu-bar app that isn't currently focused can
    /// lose the activation race and show the alert behind the frontmost window.
    private static func presentAlert(_ build: @escaping () -> NSApplication.ModalResponse) {
        NSApp.activate(ignoringOtherApps: true)
        DispatchQueue.main.async {
            _ = build()
        }
    }

    private static func showUpdateAlert(latestVersion: String) {
        presentAlert {
            let alert = NSAlert()
            alert.messageText     = "BeaconMac \(latestVersion) Available"
            alert.informativeText = """
                You are running version \(currentVersion). \
                Version \(latestVersion) is now available.

                Click "Download BeaconMac.pkg" to download the latest version directly.
                """
            alert.alertStyle = .informational
            alert.addButton(withTitle: "Download BeaconMac.pkg")
            alert.addButton(withTitle: "Later")
            let response = alert.runModal()
            if response == .alertFirstButtonReturn {
                NSWorkspace.shared.open(downloadURL)
            }
            return response
        }
    }

    private static func showUpToDateAlert(latestVersion: String) {
        presentAlert {
            let alert = NSAlert()
            alert.messageText     = "BeaconMac is Up to Date"
            alert.informativeText = "You are running version \(currentVersion), which is the latest version."
            alert.alertStyle      = .informational
            alert.addButton(withTitle: "OK")
            return alert.runModal()
        }
    }

    private static func showErrorAlert() {
        presentAlert {
            let alert = NSAlert()
            alert.messageText     = "Update Check Failed"
            alert.informativeText = "BeaconMac could not reach the update server. Please check your internet connection and try again."
            alert.alertStyle      = .warning
            alert.addButton(withTitle: "OK")
            return alert.runModal()
        }
    }
}
