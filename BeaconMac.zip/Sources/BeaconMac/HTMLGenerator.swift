// =============================================================================
//  HTMLGenerator.swift — Converts ShortcutGuide content to styled HTML
//
//  Uses CSS @media (prefers-color-scheme) so the WKWebView automatically
//  adapts to macOS dark/light mode with no extra Swift logic needed.
// =============================================================================
import Foundation

enum HTMLGenerator {

    // MARK: - Public Entry Point

    static func generate(for guide: ShortcutGuide) -> String {
        // Auto-inject a Description and Instructions section at the top of
        // every guide so users always know what the guide covers and how to
        // navigate it, without having to copy-paste text into all 50 closures.
        let preamble = """
        -- Description --
        \(guide.description)

        -- Instructions --
        VO + Right Arrow:       Move to the next shortcut or heading
        VO + Left Arrow:        Move to the previous shortcut or heading
        Down Arrow / Up Arrow:  Move to the next / previous shortcut or heading
        ] (right bracket):      Jump forward to the next section heading
        [ (left bracket):       Jump back to the previous section heading
        H (with VoiceOver):     Jump forward to the next section heading
        Shift + H (VoiceOver):  Jump back to the previous section heading
        Escape:                 Close this guide and return to the guide list

        """
        let body = parseContent(preamble + guide.content())
        return buildPage(title: guide.title, description: guide.description, body: body)
    }

    // MARK: - Content Parser

    /// Converts the plain-text shortcut format into HTML rows.
    /// Lines starting with "-- ... --" become section headers.
    /// Lines with "Key: Description" become shortcut rows.
    /// Everything else is treated as a plain note line.
    private static func parseContent(_ raw: String) -> String {
        var html = ""
        let lines = raw.components(separatedBy: "\n")

        for line in lines {
            // Section header: "-- Section Name --"
            // Use <h2> so VoiceOver's H-key heading navigation works.
            if let name = sectionHeaderName(from: line) {
                html += "<h2 class=\"section-header\">\(escape(name))</h2>\n"
                continue
            }

            // Blank / whitespace line
            if line.trimmingCharacters(in: .whitespaces).isEmpty {
                html += "<div class=\"spacer\"></div>\n"
                continue
            }

            // Section note: lines beginning with ">>"
            // Renders as an italic paragraph beneath the section heading.
            let trimmed = line.trimmingCharacters(in: .whitespaces)
            if trimmed.hasPrefix(">>") {
                let note = trimmed.dropFirst(2).trimmingCharacters(in: .whitespaces)
                if !note.isEmpty {
                    html += "<div class=\"section-note\">\(escape(note))</div>\n"
                    continue
                }
            }

            // Shortcut row: split on first ":"
            if let colonIdx = line.firstIndex(of: ":") {
                let key      = String(line[..<colonIdx]).trimmingCharacters(in: .whitespaces)
                let remainder = String(line[line.index(after: colonIdx)...]).trimmingCharacters(in: .whitespaces)
                if !key.isEmpty, !remainder.isEmpty, key.count < 60 {

                    // Three-column row: "Key: Action :: Context"
                    // aria-label reads all three parts for VoiceOver users.
                    if let sepRange = remainder.range(of: " :: ") {
                        let action  = String(remainder[..<sepRange.lowerBound]).trimmingCharacters(in: .whitespaces)
                        let context = String(remainder[sepRange.upperBound...]).trimmingCharacters(in: .whitespaces)
                        if !action.isEmpty, !context.isEmpty {
                            let ariaLabel = "\(escape(key)): \(escape(action)). \(escape(context))"
                            html += """
                                <div class="shortcut-row" aria-label="\(ariaLabel)">\
                                <span class="key-cell" aria-hidden="true"><kbd>\(escape(key))</kbd></span>\
                                <span class="action-cell" aria-hidden="true">\(escape(action))</span>\
                                <span class="context-cell" aria-hidden="true">\(linkifyDesc(context))</span>\
                                </div>\n
                                """
                            continue
                        }
                    }

                    // Two-column row: "Key: Description" (no context separator)
                    // Kept for backward compatibility during guide migration,
                    // and for rows where context would be redundant.
                    html += """
                        <div class="shortcut-row" \
                        aria-label="\(escape(key)): \(escape(remainder))">\
                        <span class="key-cell" aria-hidden="true"><kbd>\(escape(key))</kbd></span>\
                        <span class="desc-cell" aria-hidden="true">\(linkifyDesc(remainder))</span>\
                        </div>\n
                        """
                    continue
                }
            }

            // Plain text / notes
            html += "<div class=\"plain-line\">\(escape(line))</div>\n"
        }
        return html
    }

    // MARK: - Section Header Parser

    private static func sectionHeaderName(from line: String) -> String? {
        let t = line.trimmingCharacters(in: .whitespaces)
        guard t.hasPrefix("--") && t.hasSuffix("--") && t.count > 4 else { return nil }
        let inner = t.dropFirst(2).dropLast(2).trimmingCharacters(in: .whitespaces)
        return inner.isEmpty ? nil : inner
    }

    // MARK: - HTML Escape

    private static func escape(_ s: String) -> String {
        s
            .replacingOccurrences(of: "&",  with: "&amp;")
            .replacingOccurrences(of: "<",  with: "&lt;")
            .replacingOccurrences(of: ">",  with: "&gt;")
            .replacingOccurrences(of: "\"", with: "&quot;")
    }

    // MARK: - Link Detection

    /// Returns an HTML `<a>` element if the string looks like a URL or email
    /// address; otherwise returns the plain-escaped string.
    /// Used to make the visible desc-cell clickable without affecting the
    /// aria-label (which stays plain text for clean VoiceOver reading).
    private static func linkifyDesc(_ s: String) -> String {
        let trimmed = s.trimmingCharacters(in: .whitespaces)
        // URL
        if trimmed.hasPrefix("https://") || trimmed.hasPrefix("http://") {
            let escaped = escape(trimmed)
            return "<a href=\"\(escaped)\">\(escaped)</a>"
        }
        // Email: no spaces, contains @, and the domain part contains a dot
        if !trimmed.contains(" "),
           let atIdx = trimmed.firstIndex(of: "@"),
           trimmed[trimmed.index(after: atIdx)...].contains(".") {
            let escaped = escape(trimmed)
            return "<a href=\"mailto:\(escaped)\">\(escaped)</a>"
        }
        return escape(s)
    }

    // MARK: - Full Page Template

    private static func buildPage(title: String, description: String, body: String) -> String {
        // CSS uses @media (prefers-color-scheme) — WKWebView detects system theme.
        return """
        <!DOCTYPE html>
        <html lang="en">
        <head>
        <meta charset="UTF-8">
        <meta name="color-scheme" content="light dark">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>BeaconMac — \(escape(title)) Shortcuts</title>
        <style>
          /* ── Reset ── */
          *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

          /* ── Base ── */
          html, body {
            height: 100%;
            font-family: -apple-system, "SF Pro Text", "Helvetica Neue", Arial, sans-serif;
            font-size: 13px;
            line-height: 1.55;
            -webkit-font-smoothing: antialiased;
          }

          /* ── Light theme (default) ── */
          body                { background: #f2f2f7; color: #1c1c1e; }
          .page-header        { background: #ffffff; border-bottom-color: #c6c6c8; }
          .page-header h1     { color: #1c1c1e; }
          .page-header p      { color: #6c6c70; }
          .section-header     { color: #0071e3; border-bottom-color: #0071e3; }
          kbd                 { color: #5c3317; background: #e8e8ed; }
          .desc-cell          { color: #1c1c1e; }
          .desc-cell a        { color: #0071e3; text-decoration: none; }
          .desc-cell a:hover  { text-decoration: underline; }
          .plain-line         { color: #6c6c70; }
          ::-webkit-scrollbar-thumb { background: #c7c7cc; }

          /* ── Dark theme ── */
          @media (prefers-color-scheme: dark) {
            body                { background: #1c1c1e; color: #e5e5ea; }
            .page-header        { background: #2c2c2e; border-bottom-color: #3a3a3c; }
            .page-header h1     { color: #ffffff; }
            .page-header p      { color: #8e8e93; }
            .section-header     { color: #64d2ff; border-bottom-color: #64d2ff; }
            kbd                 { color: #ffd60a; background: #3a3a3c; }
            .desc-cell          { color: #e5e5ea; }
            .desc-cell a        { color: #64d2ff; }
            .plain-line         { color: #8e8e93; }
            ::-webkit-scrollbar-thumb { background: #48484a; }
          }

          /* ── Sticky header ── */
          .page-header {
            position: sticky;
            top: 0;
            z-index: 100;
            border-bottom: 1px solid;
            padding: 13px 18px 11px;
          }
          .page-header h1 {
            font-size: 15px;
            font-weight: 600;
            letter-spacing: -0.01em;
            margin-bottom: 3px;
          }
          /* Suppress the browser focus ring on the title element — it receives
             programmatic focus purely to anchor VoiceOver, not for sighted users */
          #vo-focus-target:focus { outline: none; }
          .page-header p { font-size: 11.5px; }

          /* ── Content ── */
          .content { padding: 10px 18px 30px; }

          /* ── Section headers ── */
          .section-header {
            font-size: 10.5px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.09em;
            margin-top: 18px;
            margin-bottom: 5px;
            padding-bottom: 5px;
            border-bottom: 1.5px solid;
          }
          .section-header:first-child { margin-top: 10px; }

          /* ── Shortcut rows ── */
          .shortcut-row {
            display: flex;
            align-items: baseline;
            padding: 2.5px 0;
          }
          .shortcut-row:hover {
            background: rgba(128,128,128,0.07);
            border-radius: 4px;
            margin: 0 -6px;
            padding-left: 6px;
            padding-right: 6px;
          }
          .key-cell {
            flex: 0 0 200px;
            margin-right: 12px;
          }
          kbd {
            display: inline-block;
            font-family: "SF Mono", "Menlo", "Monaco", monospace;
            font-size: 11.5px;
            border-radius: 4px;
            padding: 1px 6px;
            white-space: nowrap;
            max-width: 195px;
            overflow: hidden;
            text-overflow: ellipsis;
          }
          /* Two-column rows (no context) */
          .desc-cell { flex: 1; font-size: 12.5px; }
          /* Three-column rows */
          .action-cell {
            flex: 0 0 175px;
            font-size: 12.5px;
            font-weight: 500;
            padding-right: 12px;
            margin-right: 12px;
            border-right: 1px solid #c6c6c8;
          }
          .context-cell {
            flex: 1;
            font-size: 11.5px;
            font-style: italic;
          }
          @media (prefers-color-scheme: dark) {
            .action-cell  { border-right-color: #3a3a3c; }
          }
          /* ── Section notes ── */
          .section-note {
            font-size: 12px;
            font-style: italic;
            background: rgba(128,128,128,0.06);
            border-left: 3px solid #c6c6c8;
            padding: 6px 10px;
            margin-bottom: 7px;
            border-radius: 0 4px 4px 0;
            line-height: 1.55;
            color: #6c6c70;
          }
          @media (prefers-color-scheme: dark) {
            .section-note {
              background: rgba(255,255,255,0.04);
              border-left-color: #3a3a3c;
              color: #8e8e93;
            }
          }

          /* ── Plain notes ── */
          .plain-line {
            font-size: 12px;
            padding: 1.5px 0;
            font-style: italic;
            white-space: pre-wrap;
          }

          .spacer { height: 5px; }

          /* ── Scrollbar ── */
          ::-webkit-scrollbar { width: 7px; }
          ::-webkit-scrollbar-track { background: transparent; }
          ::-webkit-scrollbar-thumb { border-radius: 10px; }

          /* ── Keyboard focus ring (Up/Down navigation) ── */
          h2.section-header:focus,
          .shortcut-row:focus {
            outline: 2px solid #0071e3;
            outline-offset: 2px;
            border-radius: 4px;
          }
          @media (prefers-color-scheme: dark) {
            h2.section-header:focus,
            .shortcut-row:focus { outline-color: #64d2ff; }
          }
        </style>
        </head>
        <body>
          <div class="page-header">
            <h1 id="vo-focus-target" tabindex="-1">\(escape(title))</h1>
            <p>\(escape(description))</p>
          </div>
          <div class="content">
            \(body)
          </div>
          <script>
          // ── Keyboard navigation ─────────────────────────────────────────────
          // Builds an ordered list of every h2 section header and shortcut row,
          // then moves focus between them in response to the keys documented in
          // the SearchPanel help overlay:
          //   ArrowDown / ArrowUp  — next / previous item (any row or heading)
          //   ]        (bracket)  — next heading
          //   [        (bracket)  — previous heading
          // Focusing a shortcut-row triggers VoiceOver to read its aria-label.
          // Focusing an h2 triggers VoiceOver to announce the heading text.
          // The [ / ] handlers match the behaviour advertised by SearchPanel's
          // in-app help and by the installer's Read Me screen, and complement
          // VoiceOver's own H / Shift-H rotor navigation.
          (function () {
            var items = [];
            var idx   = -1;

            function build() {
              items = Array.from(
                document.querySelectorAll('h2.section-header, div.shortcut-row')
              );
              items.forEach(function (el) { el.setAttribute('tabindex', '-1'); });
            }

            function focusItem(nextIdx) {
              if (nextIdx === idx) return;
              idx = nextIdx;
              var el = items[idx];
              el.focus({ preventScroll: true });
              el.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
            }

            function go(delta) {
              if (!items.length) build();
              if (!items.length) return;
              var next = Math.max(0, Math.min(items.length - 1, idx + delta));
              focusItem(next);
            }

            // Move focus to the nearest heading in the given direction.
            // direction = +1 → next heading, -1 → previous heading.
            // If no heading exists in that direction, focus stays put.
            function goHeading(direction) {
              if (!items.length) build();
              if (!items.length) return;
              var i = idx;
              // Step from the current position until we find a heading.
              while (true) {
                i += direction;
                if (i < 0 || i >= items.length) return;
                if (items[i].classList.contains('section-header')) {
                  focusItem(i);
                  return;
                }
              }
            }

            document.addEventListener('keydown', function (e) {
              if (e.metaKey || e.ctrlKey || e.altKey) return;
              if (e.key === 'ArrowDown')     { e.preventDefault(); go(1);           }
              else if (e.key === 'ArrowUp')  { e.preventDefault(); go(-1);          }
              else if (e.key === ']')        { e.preventDefault(); goHeading(1);    }
              else if (e.key === '[')        { e.preventDefault(); goHeading(-1);   }
            });

            if (document.readyState === 'loading') {
              document.addEventListener('DOMContentLoaded', build);
            } else {
              build();
            }
          }());
          </script>
        </body>
        </html>
        """
    }
}
