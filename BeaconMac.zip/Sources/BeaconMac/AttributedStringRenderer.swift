// =============================================================================
//  AttributedStringRenderer.swift
//
//  NOTE: This file is retained for historical reference only.
//  All shortcut guide content is rendered via HTMLGenerator + WKWebView.
//  The NSAttributedString rendering path below is no longer used.
// =============================================================================
