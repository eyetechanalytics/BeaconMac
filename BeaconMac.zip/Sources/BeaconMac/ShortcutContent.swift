// =============================================================================
//  ShortcutContent.swift — All 82 Shortcut Guides
// =============================================================================
import Foundation

enum ShortcutContent {

    // MARK: - All Guides (ordered)

    static let allGuides: [ShortcutGuide] = [
        ShortcutGuide(
            id: "Introduction",
            title: "Introduction — About BeaconMac",
            description: "Overview of this shortcuts system and how to use it",
            category: "General",
            content: GetIntroductionContent
        ),
        ShortcutGuide(
            id: "BrowseAll",
            title: "Browse All Guides",
            description: "See every available shortcut guide organised by category",
            category: "General",
            content: GetBrowseAllContent
        ),
        ShortcutGuide(
            id: "ModifierKeys",
            title: "Modifier Keys Reference",
            description: "Mac modifier keys: Cmd, Option, Control, Shift, Fn and special keys",
            category: "General",
            content: GetModifierKeysContent
        ),
        ShortcutGuide(
            id: "MacSystem",
            title: "macOS System Shortcuts",
            description: "Essential macOS shortcuts: Spotlight, window management, screenshots, Dock",
            category: "macOS System",
            content: GetMacSystemContent
        ),
        ShortcutGuide(
            id: "CommandShortcuts",
            title: "Command (⌘) Shortcuts",
            description: "Universal Cmd shortcuts that work across most Mac apps",
            category: "macOS System",
            content: GetCommandShortcutsContent
        ),
        ShortcutGuide(
            id: "Clipboard",
            title: "Clipboard Shortcuts",
            description: "Copy, cut, paste, Universal Clipboard, and screenshot-to-clipboard",
            category: "macOS System",
            content: GetClipboardContent
        ),
        ShortcutGuide(
            id: "TextNavigation",
            title: "Text Navigation Shortcuts",
            description: "Cursor movement, text selection, and editing with keyboard",
            category: "macOS System",
            content: GetTextNavigationContent
        ),
        ShortcutGuide(
            id: "AppSwitching",
            title: "App Switching & Window Management",
            description: "Cmd+Tab switcher, Mission Control, Spaces, and Dock navigation",
            category: "macOS System",
            content: GetAppSwitchingContent
        ),
        ShortcutGuide(
            id: "Screenshots",
            title: "Screenshots & Screen Recording",
            description: "All screenshot shortcuts and screen recording with Cmd+Shift+3/4/5",
            category: "macOS System",
            content: GetScreenshotsContent
        ),
        ShortcutGuide(
            id: "WordMac",
            title: "Microsoft Word for Mac",
            description: "Word for Mac keyboard shortcuts — formatting, navigation, editing",
            category: "Microsoft Office (Mac)",
            content: GetWordMacContent
        ),
        ShortcutGuide(
            id: "ExcelMac",
            title: "Microsoft Excel for Mac",
            description: "Excel for Mac shortcuts — cells, formulas, navigation, formatting",
            category: "Microsoft Office (Mac)",
            content: GetExcelMacContent
        ),
        ShortcutGuide(
            id: "PowerPointMac",
            title: "Microsoft PowerPoint for Mac",
            description: "PowerPoint for Mac shortcuts — slides, editing, presentation mode",
            category: "Microsoft Office (Mac)",
            content: GetPowerPointMacContent
        ),
        ShortcutGuide(
            id: "OutlookMac",
            title: "Microsoft Outlook for Mac",
            description: "Outlook for Mac shortcuts — mail, calendar, contacts, composing",
            category: "Microsoft Office (Mac)",
            content: GetOutlookMacContent
        ),
        ShortcutGuide(
            id: "OneNoteMac",
            title: "Microsoft OneNote for Mac",
            description: "OneNote for Mac shortcuts — notes, formatting, navigation",
            category: "Microsoft Office (Mac)",
            content: GetOneNoteMacContent
        ),
        ShortcutGuide(
            id: "WordOnline",
            title: "Word Online Shortcuts (Office 365)",
            description: "Word Online keyboard shortcuts for browser-based document editing",
            category: "Office 365 Online",
            content: GetWordOnlineContent
        ),
        ShortcutGuide(
            id: "ExcelOnline",
            title: "Excel Online Shortcuts (Office 365)",
            description: "Excel Online shortcuts for browser-based spreadsheet work",
            category: "Office 365 Online",
            content: GetExcelOnlineContent
        ),
        ShortcutGuide(
            id: "PowerPointOnline",
            title: "PowerPoint Online Shortcuts (Office 365)",
            description: "PowerPoint Online shortcuts for browser-based presentations",
            category: "Office 365 Online",
            content: GetPowerPointOnlineContent
        ),
        ShortcutGuide(
            id: "OutlookOnline",
            title: "Outlook Online Shortcuts (Office 365)",
            description: "Outlook on the web keyboard shortcuts for email and calendar",
            category: "Office 365 Online",
            content: GetOutlookOnlineContent
        ),
        ShortcutGuide(
            id: "OneNoteOnline",
            title: "OneNote Online Shortcuts (Office 365)",
            description: "OneNote Online shortcuts for browser-based note-taking",
            category: "Office 365 Online",
            content: GetOneNoteOnlineContent
        ),
        ShortcutGuide(
            id: "TeamsWeb",
            title: "Microsoft Teams Web Shortcuts",
            description: "Teams web app shortcuts — messaging, meetings, navigation",
            category: "Office 365 Online",
            content: GetTeamsWebContent
        ),
        ShortcutGuide(
            id: "OneDriveWeb",
            title: "OneDrive Web Shortcuts",
            description: "OneDrive web interface shortcuts for file management",
            category: "Office 365 Online",
            content: GetOneDriveWebContent
        ),
        ShortcutGuide(
            id: "SharePointOnline",
            title: "SharePoint Online Shortcuts",
            description: "SharePoint Online shortcuts for collaboration and document management",
            category: "Office 365 Online",
            content: GetSharePointOnlineContent
        ),
        ShortcutGuide(
            id: "GoogleDocs",
            title: "Google Docs Shortcuts",
            description: "Google Docs keyboard shortcuts for document editing and formatting",
            category: "Google Workspace",
            content: GetGoogleDocsContent
        ),
        ShortcutGuide(
            id: "GoogleSheets",
            title: "Google Sheets Shortcuts",
            description: "Google Sheets shortcuts for spreadsheet editing and navigation",
            category: "Google Workspace",
            content: GetGoogleSheetsContent
        ),
        ShortcutGuide(
            id: "GoogleSlides",
            title: "Google Slides Shortcuts",
            description: "Google Slides shortcuts for presentations",
            category: "Google Workspace",
            content: GetGoogleSlidesContent
        ),
        ShortcutGuide(
            id: "Gmail",
            title: "Gmail Shortcuts",
            description: "Gmail keyboard shortcuts — enable in Settings > General first",
            category: "Google Workspace",
            content: GetGmailContent
        ),
        ShortcutGuide(
            id: "GoogleMeet",
            title: "Google Meet Shortcuts",
            description: "Google Meet shortcuts for muting, camera, sharing, and chat",
            category: "Google Workspace",
            content: GetGoogleMeetContent
        ),
        ShortcutGuide(
            id: "Finder",
            title: "Finder Shortcuts",
            description: "Finder navigation, file operations, views, and selection",
            category: "macOS Built-in Apps",
            content: GetFinderContent
        ),
        ShortcutGuide(
            id: "Safari",
            title: "Safari Shortcuts",
            description: "Safari navigation, tabs, bookmarks, and Reader View",
            category: "macOS Built-in Apps",
            content: GetSafariContent
        ),
        ShortcutGuide(
            id: "Mail",
            title: "Mail App Shortcuts",
            description: "macOS Mail shortcuts — composing, replying, navigation, search",
            category: "macOS Built-in Apps",
            content: GetMailContent
        ),
        ShortcutGuide(
            id: "Calendar",
            title: "Calendar App Shortcuts",
            description: "macOS Calendar shortcuts — events, navigation, views",
            category: "macOS Built-in Apps",
            content: GetCalendarContent
        ),
        ShortcutGuide(
            id: "Notes",
            title: "Notes App Shortcuts",
            description: "macOS Notes shortcuts — creating, formatting, and organizing notes",
            category: "macOS Built-in Apps",
            content: GetNotesContent
        ),
        ShortcutGuide(
            id: "Photos",
            title: "Photos App Shortcuts",
            description: "macOS Photos shortcuts — viewing, editing, and managing photos",
            category: "macOS Built-in Apps",
            content: GetPhotosContent
        ),
        ShortcutGuide(
            id: "Preview",
            title: "Preview App Shortcuts (PDF & Images)",
            description: "Preview shortcuts for PDF navigation, zoom, markup, and annotation",
            category: "macOS Built-in Apps",
            content: GetPreviewContent
        ),
        ShortcutGuide(
            id: "Terminal",
            title: "Terminal Shortcuts",
            description: "macOS Terminal shortcuts — command line editing, history, sessions",
            category: "macOS Built-in Apps",
            content: GetTerminalContent
        ),
        ShortcutGuide(
            id: "TextEdit",
            title: "TextEdit Shortcuts",
            description: "TextEdit shortcuts for plain and rich text editing",
            category: "macOS Built-in Apps",
            content: GetTextEditContent
        ),
        ShortcutGuide(
            id: "Messages",
            title: "Messages Shortcuts",
            description: "macOS Messages shortcuts for composing, replying, and navigating conversations",
            category: "macOS Built-in Apps",
            content: GetMessagesContent
        ),
        ShortcutGuide(
            id: "FaceTime",
            title: "FaceTime Shortcuts",
            description: "FaceTime shortcuts for calls, audio, video, and full screen",
            category: "macOS Built-in Apps",
            content: GetFaceTimeContent
        ),
        ShortcutGuide(
            id: "Reminders",
            title: "Reminders Shortcuts",
            description: "macOS Reminders shortcuts for creating, completing, and organizing reminders",
            category: "macOS Built-in Apps",
            content: GetRemindersContent
        ),
        ShortcutGuide(
            id: "MusicApp",
            title: "Music (Apple Music) Shortcuts",
            description: "Apple Music shortcuts for playback, library navigation, and queue management",
            category: "macOS Built-in Apps",
            content: GetMusicAppContent
        ),
        ShortcutGuide(
            id: "Contacts",
            title: "Contacts App Shortcuts",
            description: "macOS Contacts shortcuts for creating, editing, and finding contacts",
            category: "macOS Built-in Apps",
            content: GetContactsAppContent
        ),
        ShortcutGuide(
            id: "iMovie",
            title: "iMovie Shortcuts",
            description: "iMovie shortcuts for timeline editing, playback, and clip management",
            category: "macOS Built-in Apps",
            content: GetiMovieContent
        ),
        ShortcutGuide(
            id: "GarageBand",
            title: "GarageBand Shortcuts",
            description: "GarageBand shortcuts for recording, editing, playback, and track management",
            category: "macOS Built-in Apps",
            content: GetGarageBandContent
        ),
        ShortcutGuide(
            id: "Browser",
            title: "Browser Shortcuts (Chrome & Firefox)",
            description: "Chrome / Firefox shortcuts — tabs, navigation, bookmarks, developer tools",
            category: "Other Apps",
            content: GetBrowserContent
        ),
        ShortcutGuide(
            id: "Zoom",
            title: "Zoom Meeting Shortcuts",
            description: "Zoom shortcuts for muting, video, screen share, recording, and chat",
            category: "Other Apps",
            content: GetZoomContent
        ),
        ShortcutGuide(
            id: "TeamsDesktop",
            title: "Microsoft Teams Desktop (Mac)",
            description: "Teams desktop app shortcuts — navigation, meetings, messaging",
            category: "Other Apps",
            content: GetTeamsDesktopMacContent
        ),
        ShortcutGuide(
            id: "AdobeReader",
            title: "Adobe Acrobat / Reader Shortcuts",
            description: "Adobe Reader shortcuts for PDF navigation, zoom, and annotation",
            category: "Other Apps",
            content: GetAdobeReaderContent
        ),
        ShortcutGuide(
            id: "Slack",
            title: "Slack Shortcuts",
            description: "Slack shortcuts for navigation, messaging, formatting, and search",
            category: "Other Apps",
            content: GetSlackContent
        ),
        ShortcutGuide(
            id: "VSCode",
            title: "Visual Studio Code Shortcuts (Mac)",
            description: "VS Code shortcuts for editing, navigation, multi-cursor, and debugging",
            category: "Other Apps",
            content: GetVSCodeContent
        ),
        ShortcutGuide(
            id: "Xcode",
            title: "Xcode Shortcuts",
            description: "Xcode shortcuts for building, running, debugging, and navigating code",
            category: "Other Apps",
            content: GetXcodeContent
        ),
        ShortcutGuide(
            id: "Discord",
            title: "Discord Shortcuts",
            description: "Discord shortcuts for navigation, messaging, voice, and channel management",
            category: "Other Apps",
            content: GetDiscordContent
        ),
        ShortcutGuide(
            id: "Figma",
            title: "Figma Shortcuts",
            description: "Figma shortcuts for tools, layers, view, and editing on Mac",
            category: "Other Apps",
            content: GetFigmaContent
        ),
        ShortcutGuide(
            id: "Sketch",
            title: "Sketch Shortcuts",
            description: "Sketch shortcuts for tools, vector editing, layers, and view",
            category: "Other Apps",
            content: GetSketchContent
        ),
        ShortcutGuide(
            id: "OnePassword",
            title: "1Password Shortcuts",
            description: "1Password shortcuts for autofill, vault navigation, and item management",
            category: "Other Apps",
            content: GetOnePasswordContent
        ),
        ShortcutGuide(
            id: "Obsidian",
            title: "Obsidian Shortcuts",
            description: "Obsidian shortcuts for note navigation, editing, and vault search",
            category: "Other Apps",
            content: GetObsidianContent
        ),
        ShortcutGuide(
            id: "Notion",
            title: "Notion Shortcuts",
            description: "Notion shortcuts for page navigation, block editing, and formatting",
            category: "Other Apps",
            content: GetNotionContent
        ),
        ShortcutGuide(
            id: "Bear",
            title: "Bear Shortcuts",
            description: "Bear shortcuts for notes, markdown formatting, and navigation",
            category: "Other Apps",
            content: GetBearContent
        ),
        ShortcutGuide(
            id: "iTerm2",
            title: "iTerm2 Shortcuts",
            description: "iTerm2 shortcuts for tabs, split panes, sessions, and command editing",
            category: "Other Apps",
            content: GetITerm2Content
        ),
        ShortcutGuide(
            id: "WhatsApp",
            title: "WhatsApp Desktop Shortcuts",
            description: "WhatsApp Desktop shortcuts for chat navigation, messaging, and calls",
            category: "Other Apps",
            content: GetWhatsAppContent
        ),
        ShortcutGuide(
            id: "Pages",
            title: "Pages Shortcuts (Apple)",
            description: "Apple Pages shortcuts for document editing, formatting, and navigation",
            category: "Apple iWork",
            content: GetPagesContent
        ),
        ShortcutGuide(
            id: "Numbers",
            title: "Numbers Shortcuts (Apple)",
            description: "Apple Numbers shortcuts for spreadsheet editing, cells, and formulas",
            category: "Apple iWork",
            content: GetNumbersContent
        ),
        ShortcutGuide(
            id: "Keynote",
            title: "Keynote Shortcuts (Apple)",
            description: "Apple Keynote shortcuts for slide editing, presentation, and navigation",
            category: "Apple iWork",
            content: GetKeynoteContent
        ),
        ShortcutGuide(
            id: "YouTube",
            title: "YouTube Shortcuts",
            description: "YouTube browser shortcuts for playback, seeking, volume, and display",
            category: "Multimedia",
            content: GetYouTubeContent
        ),
        ShortcutGuide(
            id: "VLC",
            title: "VLC Media Player Shortcuts",
            description: "VLC shortcuts for playback, seeking, speed, audio, and subtitles",
            category: "Multimedia",
            content: GetVLCContent
        ),
        ShortcutGuide(
            id: "Spotify",
            title: "Spotify Shortcuts",
            description: "Spotify shortcuts for playback, volume, shuffle, repeat, and navigation",
            category: "Multimedia",
            content: GetSpotifyContent
        ),
        ShortcutGuide(
            id: "QuickTime",
            title: "QuickTime Player Shortcuts",
            description: "QuickTime shortcuts for playback, chapters, frame stepping, and recording",
            category: "Multimedia",
            content: GetQuickTimeContent
        ),
        ShortcutGuide(
            id: "FinalCutPro",
            title: "Final Cut Pro Shortcuts",
            description: "Final Cut Pro shortcuts for timeline editing, playback, and clip trimming",
            category: "Multimedia",
            content: GetFinalCutProContent
        ),
        ShortcutGuide(
            id: "LogicPro",
            title: "Logic Pro Shortcuts",
            description: "Logic Pro shortcuts for recording, editing, mixing, and navigation",
            category: "Multimedia",
            content: GetLogicProContent
        ),
        ShortcutGuide(
            id: "Photoshop",
            title: "Adobe Photoshop Shortcuts (Mac)",
            description: "Photoshop shortcuts for tools, layers, canvas navigation, and editing",
            category: "Multimedia",
            content: GetPhotoshopContent
        ),
        ShortcutGuide(
            id: "Illustrator",
            title: "Adobe Illustrator Shortcuts (Mac)",
            description: "Illustrator shortcuts for tools, objects, view, and artboard navigation",
            category: "Multimedia",
            content: GetIllustratorContent
        ),
        ShortcutGuide(
            id: "PremierePro",
            title: "Adobe Premiere Pro Shortcuts (Mac)",
            description: "Premiere Pro shortcuts for timeline editing, playback, and clip trimming",
            category: "Multimedia",
            content: GetPremiereProContent
        ),
        ShortcutGuide(
            id: "ProTools",
            title: "Pro Tools Shortcuts (Mac)",
            description: "Pro Tools shortcuts for session editing, playback, recording, and mixing",
            category: "Multimedia",
            content: GetProToolsContent
        ),
        ShortcutGuide(
            id: "REAPER",
            title: "REAPER + OSARA Shortcuts (Mac)",
            description: "REAPER DAW shortcuts with OSARA screen reader extension for accessible audio production",
            category: "Multimedia",
            content: GetREAPERContent
        ),
        ShortcutGuide(
            id: "AccessibilityOverview",
            title: "Accessibility Overview",
            description: "macOS accessibility feature shortcuts — Zoom, Color Invert, Spoken Content",
            category: "Accessibility",
            content: GetAccessibilityOverviewContent
        ),
        ShortcutGuide(
            id: "VoiceOver",
            title: "VoiceOver Screen Reader Shortcuts",
            description: "VoiceOver shortcuts for navigation, reading, and web browsing",
            category: "Accessibility",
            content: GetVoiceOverContent
        ),
        ShortcutGuide(
            id: "ZoomAccessibility",
            title: "Zoom Accessibility (Screen Magnifier)",
            description: "macOS Zoom feature shortcuts for screen magnification and Hover Text",
            category: "Accessibility",
            content: GetZoomAccessibilityContent
        ),
        ShortcutGuide(
            id: "VoiceControl",
            title: "Voice Control Shortcuts",
            description: "macOS Voice Control commands for hands-free computer use",
            category: "Accessibility",
            content: GetVoiceControlContent
        ),
        ShortcutGuide(
            id: "Dictation",
            title: "Dictation Shortcuts",
            description: "macOS Dictation shortcut and voice commands for text input",
            category: "Accessibility",
            content: GetDictationContent
        ),
        ShortcutGuide(
            id: "FloTools",
            title: "Flo Tools for Pro Tools (Mac)",
            description: "Flo Tools keyboard commands for navigating Pro Tools with VoiceOver on Mac",
            category: "Accessibility",
            content: GetFloToolsContent
        ),
        ShortcutGuide(
            id: "PTAccess",
            title: "PTAccess — Pro Tools Screen Reader Guide",
            description: "PTAccess navigation and workflow guide for using Pro Tools with a screen reader",
            category: "Accessibility",
            content: GetPTAccessContent
        ),
        ShortcutGuide(
            id: "Libby",
            title: "Libby — Library Ebooks & Audiobooks",
            description: "Libby keyboard shortcuts for browsing, borrowing, reading, and listening with VoiceOver",
            category: "Accessibility",
            content: GetLibbyContent
        ),
        ShortcutGuide(
            id: "Contact",
            title: "About BeaconMac",
            description: "About BeaconMac, system requirements, and how to customize or rebuild",
            category: "About",
            content: GetContactContent
        ),
    ]

    // MARK: - Content Providers

    private static var GetIntroductionContent: () -> String = {
        return """
-- Welcome --
>> BeaconMac sits in your menu bar and waits. Press your hotkey from any app and a floating search panel appears instantly — no mouse needed. Type a few letters to find a guide, press Return to open it, and press Escape when you're done to return exactly where you were.

Open BeaconMac:         Press your configured hotkey :: Works from any app — even full-screen apps
Search for a guide:     Start typing to filter the list :: The list narrows with each keystroke
Browse all guides:      Select "Browse All Guides" :: Shows every available guide in the panel
Open a guide:           Press Return :: Opens the full shortcut reference window
Return to search:       Press Escape in a guide :: Closes the guide and reopens the search panel
Close BeaconMac:        Press Escape in the search panel :: Dismisses the panel entirely

-- Customizing BeaconMac --
>> These settings let you tailor BeaconMac to your workflow. Change the hotkey if it conflicts with another app, or add your own guides by editing the source and rebuilding.

Change your hotkey:     Ctrl + F8 → navigate to BeaconMac ⌨ → Preferences… :: Ctrl + F8 focuses the menu bar; then arrow to the BeaconMac icon and press Cmd + ,
Launch at login:        Preferences → Launch at Login checkbox :: Requires macOS 13 Ventura or later
Add or edit guides:     Edit ShortcutContent.swift and rebuild :: Each guide is a plain-text closure
Rebuild the app:        cd BeaconMac-Swift && ./build-app.sh :: Places the new .app in the project folder
"""
    }

    // NOTE: BrowseAll content is intentionally empty — selecting "Browse All
    // Guides" in the search panel clears the search filter and shows all guides
    // as list items directly in the panel itself.  No ContentWindow is opened,
    // so this closure is never called.  The ShortcutGuide struct requires a
    // content property, so we provide a no-op placeholder.
    private static var GetBrowseAllContent: () -> String = { "" }

    private static var GetModifierKeysContent: () -> String = {
        return """
-- Mac Modifier Keys --
>> These are the four modifier keys used in virtually every Mac shortcut. You hold them while pressing another key to trigger a command. Most shortcuts use Cmd as the primary modifier — it is the key with the ⌘ symbol, typically next to the spacebar.

Cmd:                    Command key (⌘) :: The main Mac modifier — equivalent to Ctrl on Windows
Option:                 Option / Alt key (⌥) :: Adds alternate or extended functions to shortcuts
Control:                Control key (⌃) :: Used for system shortcuts and some app-specific commands
Shift:                  Shift key (⇧) :: Extends selections, reverses actions, and toggles uppercase
Fn:                     Function key :: Unlocks F1–F12 and hardware keys on compact keyboards
Caps Lock:              Caps Lock (⇪) :: Can be remapped to Escape or Control in System Settings

-- Special Keys --
>> These keys appear in many shortcuts. Forward Delete is often missing from compact keyboards — use fn + Delete as the equivalent.

Return:                 Return / Enter key (↩) :: Confirms dialogs, opens items, adds new lines
Delete:                 Backspace / Delete key (⌫) :: Deletes the character to the left of the cursor
Fwd Delete:             Forward Delete (⌦) :: Deletes the character to the right (fn + Delete)
Escape:                 Escape key (⎋) :: Cancels actions, closes dialogs, exits modes
Tab:                    Tab key (⇥) :: Moves focus forward between fields and controls
Space:                  Spacebar :: Triggers Quick Look in Finder; plays/pauses media
Arrow Keys:             Up / Down / Left / Right (↑ ↓ ← →) :: Navigate lists, text, and UI elements
Page Up / Down:         fn + Up / Down arrow :: Scrolls the view up or down by one full page
Home / End:             fn + Left / Right arrow :: Jumps to the very beginning or end of a document

-- Common Key Combinations --
>> Combining modifiers multiplies the number of available shortcuts. Cmd + Shift is the most common way to access alternate or reversed versions of a Cmd shortcut.

Cmd + Shift + …:        Alternate or reversed Cmd shortcut :: e.g. Cmd+Z undoes; Cmd+Shift+Z redoes
Cmd + Option + …:       Extended or system-level variant :: e.g. Cmd+Option+Esc opens Force Quit
Control + Cmd + …:      System shortcuts like Mission Control :: e.g. Ctrl+Cmd+F for full screen
Cmd + Fn + …:           Hardware key access :: e.g. Cmd+Fn+F2 controls display brightness

-- Symbols Quick Reference --
⌘:  Command     ⌥:  Option      ⌃:  Control     ⇧:  Shift
⌫:  Delete      ⌦:  Fwd Delete  ↩:  Return       ⎋:  Escape
⇥:  Tab         ␣:  Space       fn: Function
"""
    }

    private static var GetMacSystemContent: () -> String = {
        return """
-- Essential macOS Shortcuts --
>> These shortcuts work system-wide in virtually every Mac application. Cmd + Space and Cmd + Tab are the two most useful for navigating quickly without the mouse.

Cmd + Space:            Open Spotlight search :: Search for apps, files, calculations, and web results
Cmd + Tab:              Switch between open apps :: Hold Cmd and press Tab to cycle; release to switch
Cmd + `:                Cycle windows of current app :: Moves between multiple open windows of the same app
Cmd + Q:                Quit current app :: Fully exits the application, not just the window
Cmd + W:                Close current window / tab :: Closes the front window; app stays running
Cmd + H:                Hide current app :: Hides all windows; app continues running in background
Cmd + M:                Minimize window to Dock :: Sends window to Dock; click it there to restore
Cmd + Option + M:       Minimize all windows :: Minimizes every window belonging to the current app
Cmd + N:                New window / document :: Opens a new window or document in the current app
Cmd + O:                Open file :: Shows the Open dialog to choose a file
Cmd + S:                Save :: Saves the current document; shows Save dialog on first save
Cmd + Shift + S:        Save As :: Saves a copy of the document with a new name or location
Cmd + P:                Print :: Opens the Print dialog for the current document
Cmd + Z:                Undo :: Reverses the last action; press repeatedly to step back further
Cmd + Shift + Z:        Redo :: Re-applies an action you just undid
Cmd + A:                Select All :: Selects all text, files, or items in the current context
Cmd + X:                Cut :: Removes the selection and places it on the clipboard
Cmd + C:                Copy :: Copies the selection to the clipboard; original stays in place
Cmd + V:                Paste :: Inserts the clipboard contents at the current cursor position
Cmd + Shift + V:        Paste and Match Style :: Pastes as plain text, matching the destination formatting
Cmd + F:                Find :: Opens the search bar in the current window or document
Cmd + G:                Find Next :: Jumps to the next match for the current search term
Cmd + Shift + G:        Find Previous :: Jumps back to the previous search match

-- Window & App Management --
>> Use these to organise your workspace without reaching for the mouse. Mission Control gives a bird's-eye view of all open windows and Spaces.

Cmd + Option + H:       Hide all other apps :: Clears the screen to just the current app
Control + Cmd + F:      Toggle full screen :: Expands or collapses the front window to fill the screen
Cmd + Option + Esc:     Force Quit dialog :: Opens the Force Quit window to close frozen apps
Control + Up:           Mission Control :: Shows all open windows and Spaces at once
Control + Down:         App Exposé :: Shows all windows of the current app only
Control + Left / Right: Switch between Spaces :: Moves to the next or previous desktop Space
F11:                    Show Desktop :: Temporarily moves all windows aside to reveal the Desktop

-- Screenshots --
>> Screenshots are saved to the Desktop by default. Hold Ctrl with any of these shortcuts to save to the clipboard instead of a file.

Cmd + Shift + 3:        Screenshot entire screen :: Saves a full-screen image to the Desktop
Cmd + Shift + 4:        Screenshot selected area :: Drag to draw a region; release to capture
Cmd + Shift + 4, Space: Screenshot a window :: Click any window to capture just that window
Cmd + Shift + 5:        Screenshot toolbar :: All screenshot and screen recording options in one place
Cmd + Shift + 6:        Screenshot Touch Bar :: Captures the Touch Bar (if present on your Mac)

-- Finder & Files --
>> These shortcuts work in Finder windows and on the Desktop. Quick Look (Space) is one of the most useful — it previews almost any file without opening an app.

Cmd + Delete:           Move to Trash :: Sends the selected file or folder to the Trash
Cmd + Shift + Delete:   Empty Trash :: Permanently deletes everything in the Trash
Cmd + D:                Duplicate file :: Creates an instant copy with "copy" appended to the name
Cmd + I:                Get Info :: Shows file size, permissions, metadata, and more
Cmd + R:                Show original :: Reveals the original file that an alias points to
Return / Enter:         Rename selected item :: Puts the filename into edit mode in Finder
Space:                  Quick Look preview :: Instantly previews almost any file without opening an app

-- System Power --
>> Use these to lock, sleep, restart, or shut down without using the Apple menu. The lock screen shortcut is the quickest way to secure your Mac when stepping away.

Cmd + Control + Q:      Lock screen :: Immediately locks the screen and requires your password
Cmd + Option + Power:   Put Mac to sleep :: Puts the entire Mac to sleep immediately
Ctrl + Shift + Power:   Sleep the display :: Turns off the screen while leaving the Mac running
Cmd + Control + Power:  Force restart :: Forces the Mac to restart without saving open documents
Cmd + Control + Option + Power: Quit all apps and shut down :: Prompts to save open documents, then shuts down

-- VoiceOver Quick Reference --
>> Essential VoiceOver commands for navigating the macOS system with a screen reader.
>> Start/stop VoiceOver: Cmd + F5 (or triple-press Touch ID on supported MacBooks).
Cmd + F5:               Toggle VoiceOver on / off :: Enables or disables the VoiceOver screen reader
VO + Right / Left:      Move to next / previous item :: The primary navigation gesture (VO = Ctrl+Option)
VO + Spacebar:          Activate item :: Click, press, or open the focused element
VO + Shift + Down:      Interact with group :: Enter a container such as a toolbar, table, or web area
VO + Shift + Up:        Stop interacting :: Exit the current container and return to the parent level
VO + A:                 Read all from current position :: Reads continuously from the focused item forward
VO + H:                 VoiceOver Help :: Opens the VoiceOver Help menu with navigation commands
VO + F1:                Announce application :: Says the name of the active application
VO + F2:                Announce window :: Says the title of the active window
VO + U:                 Open Rotor :: Opens the rotor for quick navigation by heading, link, table, etc.
VO + Q:                 Toggle Quick Nav (web) :: Enables single-key navigation in Safari web pages
Ctrl:                   Pause / resume reading :: Stops VoiceOver reading; press again to continue
>> See the dedicated VoiceOver guide for the complete command reference.
"""
    }

    private static var GetCommandShortcutsContent: () -> String = {
        return """
-- Universal Cmd Shortcuts (Work in Most Apps) --
>> Apple assigns most letters of the alphabet a Cmd shortcut that works consistently across apps. Knowing this list lets you navigate any new Mac app faster with minimal guessing.

Cmd + A:                Select All :: Selects all text, files, or items in the current view
Cmd + B:                Bold :: Toggles bold formatting on selected text
Cmd + C:                Copy :: Copies the selection to the clipboard without removing it
Cmd + D:                Duplicate / Bookmark :: Duplicates a file in Finder; bookmarks a page in browsers
Cmd + E:                Use selection for Find :: Loads selected text into the Find field without opening the toolbar
Cmd + F:                Find :: Opens the in-app search bar
Cmd + G:                Find Next :: Advances to the next search result
Cmd + H:                Hide app :: Hides all windows of the current app
Cmd + I:                Italic / Get Info :: Italicises selected text; shows file info in Finder
Cmd + J:                Show View Options / Show Downloads :: Opens View Options in Finder; shows Downloads in browsers
Cmd + K:                Insert link / Connect to server :: Inserts a hyperlink; connects to a network server in Finder
Cmd + L:                Open Location / Address bar :: Opens a URL entry field; jumps to address bar in browsers
Cmd + M:                Minimize window :: Sends the front window to the Dock
Cmd + N:                New window / document :: Creates a new window or blank document
Cmd + O:                Open file :: Shows the Open dialog to choose a file to open
Cmd + P:                Print :: Opens the Print dialog for the current document
Cmd + Q:                Quit app :: Exits the application entirely
Cmd + R:                Reload / Refresh :: Reloads the current page or view
Cmd + S:                Save :: Saves the current document to disk
Cmd + T:                New tab / Show fonts :: Opens a new tab; shows the Fonts panel in text apps
Cmd + U:                Underline :: Toggles underline formatting on selected text
Cmd + V:                Paste :: Inserts clipboard contents at the cursor
Cmd + W:                Close window / tab :: Closes the frontmost window or active tab
Cmd + X:                Cut :: Removes the selection and places it on the clipboard
Cmd + Y:                Quick Look / Redo :: Previews selected file in Finder; Redo in some apps
Cmd + Z:                Undo :: Reverses the most recent action

-- With Shift --
>> Cmd + Shift shortcuts are mostly Finder navigation shortcuts or reversed versions of their Cmd counterparts.

Cmd + Shift + A:        Applications folder :: Opens the Applications folder in Finder
Cmd + Shift + D:        Desktop folder :: Opens the Desktop folder in Finder
Cmd + Shift + F:        Recents :: Shows recently accessed files in Finder
Cmd + Shift + G:        Go to folder / Find Previous :: Opens Go To Folder dialog; navigates to previous search result
Cmd + Shift + H:        Home folder :: Opens your user Home folder in Finder
Cmd + Shift + I:        iCloud Drive :: Opens iCloud Drive in Finder
Cmd + Shift + K:        Network :: Shows available network locations in Finder
Cmd + Shift + N:        New folder :: Creates a new folder in the current Finder location
Cmd + Shift + O:        Documents folder :: Opens the Documents folder in Finder
Cmd + Shift + P:        Show / hide Preview pane :: Toggles the file preview panel in Finder
Cmd + Shift + R:        AirDrop :: Opens the AirDrop window in Finder
Cmd + Shift + S:        Save As :: Saves a copy of the document under a new name or location
Cmd + Shift + T:        Show / hide tab bar :: Toggles the tab bar in Finder (reopens last tab in browsers)
Cmd + Shift + U:        Utilities folder :: Opens the Utilities folder in Finder
Cmd + Shift + Z:        Redo :: Re-applies the last undone action

-- With Option --
>> Cmd + Option shortcuts tend to be system-level or alternate versions of their Cmd equivalents — most useful for window and Dock management.

Cmd + Option + D:       Show / hide Dock :: Toggles the Dock's visibility on screen
Cmd + Option + Esc:     Force Quit :: Opens the Force Quit dialog to close unresponsive apps
Cmd + Option + H:       Hide all other apps :: Clears the screen to only the current app's windows
Cmd + Option + M:       Minimize all windows :: Sends every window of the current app to the Dock
Cmd + Option + N:       New Smart Folder :: Creates a Smart Folder with saved search criteria in Finder
Cmd + Option + P:       Show / hide Path bar :: Toggles the folder path bar at the bottom of Finder
Cmd + Option + S:       Show / hide Sidebar :: Toggles the left sidebar in Finder windows
Cmd + Option + T:       Show / hide toolbar :: Toggles the top toolbar in Finder windows
Cmd + Option + V:       Move pasted item :: Moves (rather than copies) a file you cut in Finder
"""
    }

    private static var GetClipboardContent: () -> String = {
        return """
-- Clipboard Shortcuts --
>> The Mac clipboard holds one item at a time — copying something new replaces whatever was there before. Use Paste and Match Style when copying text between apps with different fonts or colours, so your pasted text adopts the destination's formatting.

Cmd + C:                Copy :: Copies the selection; original stays in place
Cmd + X:                Cut :: Copies and removes the selection in one step
Cmd + V:                Paste :: Inserts the clipboard contents at the current cursor position
Cmd + Shift + V:        Paste and Match Style :: Strips formatting and pastes as plain text
Cmd + Option + Shift + V: Paste and Match Style (extended) :: Same as above; works in additional apps
Cmd + Z:                Undo paste :: Reverses the paste if you made a mistake
Cmd + A, then Cmd + C:  Copy entire document :: Select-all then copy to grab everything at once

-- Universal Clipboard (Handoff) --
>> If your Mac and iPhone/iPad are signed into the same Apple ID and have Bluetooth and Wi-Fi on, the clipboard is shared between them automatically. Copy on one device, paste on another.

Cmd + C (on Mac):       Copy to Universal Clipboard :: Also available to paste on nearby iPhone / iPad
Cmd + V (on Mac):       Paste from Universal Clipboard :: Can paste items you copied on iPhone / iPad

-- Screenshots to Clipboard --
>> Adding Ctrl to any screenshot shortcut sends the image to the clipboard instead of saving a file. This is useful when you want to paste a screenshot directly into a document or message.

Ctrl + Cmd + Shift + 3: Entire screen to clipboard :: Captures full screen, no file saved
Ctrl + Cmd + Shift + 4: Selected area to clipboard :: Drag to capture a region directly to clipboard
Ctrl + Cmd + Shift + 4, Space: Window to clipboard :: Click a window to capture it to clipboard
>> Cmd + Shift + 5 opens the screenshot toolbar; choose "Clipboard" as the save destination under Options.

-- Clipboard History --
>> macOS does not include built-in clipboard history, but third-party tools fill this gap. They let you access dozens of previously copied items.

Paste app:              Commercial clipboard manager :: Stores clipboard history with search
Alfred:                 Free launcher with clipboard history :: Cmd + Option + C to open history
"""
    }

    private static var GetTextNavigationContent: () -> String = {
        return """
-- Cursor Movement --
>> Add Option to move by word, or Cmd to jump to the line or document boundary. These work in almost every Mac text field — emails, documents, code editors, and web forms.

Arrow keys:             Move one character / line :: Moves the cursor one step in any direction
Option + Left / Right:  Move by word :: Jumps over a full word at a time
Cmd + Left / Right:     Move to line start / end :: Jumps to the very beginning or end of the current line
Option + Up / Down:     Move by paragraph :: Jumps to the start of the previous or next paragraph
Cmd + Up / Down:        Move to document start / end :: Jumps to the very first or last character
fn + Left:              Home :: Moves to the beginning of the document
fn + Right:             End :: Moves to the end of the document
fn + Up:                Page Up :: Scrolls up by one full visible page
fn + Down:              Page Down :: Scrolls down by one full visible page

-- Selecting Text --
>> Add Shift to any movement shortcut to extend the selection rather than just move the cursor. This works with all cursor movement shortcuts above.

Shift + Arrow:          Extend selection by one character / line :: Grows or shrinks the current selection
Shift + Option + Left / Right: Extend selection by word :: Selects or deselects one word at a time
Shift + Cmd + Left / Right: Select to line start / end :: Extends selection to the beginning or end of the line
Shift + Cmd + Up / Down: Select to document start / end :: Selects from the cursor to the very top or bottom
Shift + Option + Up / Down: Extend selection by paragraph :: Expands the selection one paragraph at a time
Shift + fn + Left:      Select to beginning of document :: Selects everything from cursor to the start
Shift + fn + Right:     Select to end of document :: Selects everything from cursor to the end

-- Deleting Text --
>> Combine with Option to delete whole words, which is much faster than holding Delete.

Delete:                 Delete left (Backspace) :: Removes the character to the left of the cursor
fn + Delete:            Delete right (Fwd Delete) :: Removes the character to the right of the cursor
Option + Delete:        Delete word to the left :: Removes the entire word before the cursor
Option + fn + Delete:   Delete word to the right :: Removes the entire word after the cursor
Cmd + Delete:           Delete to line start :: Deletes everything from the cursor back to the start of the line

-- Text Formatting --
>> These formatting shortcuts work in most rich-text editors, word processors, and email clients. They typically have no effect in plain-text fields.

Cmd + B:                Bold :: Toggles bold on the selected text
Cmd + I:                Italic :: Toggles italic on the selected text
Cmd + U:                Underline :: Toggles underline on the selected text
Cmd + T:                Show / hide Fonts panel :: Opens the system font picker
Cmd + K:                Add hyperlink :: Opens the Insert Link dialog in most apps

-- Find & Replace --
>> Cmd + E is underused but very handy — it loads selected text into the Find field without you having to type it in.

Cmd + F:                Find :: Opens the search bar in the current document
Cmd + G:                Find Next :: Jumps to the next occurrence of the search term
Cmd + Shift + G:        Find Previous :: Jumps back to the previous occurrence
Cmd + H:                Find and Replace :: Opens Find & Replace in apps that support it
Cmd + E:                Use selection as find string :: Loads selected text into the Find field without opening the toolbar
Cmd + J:                Scroll to selection :: Scrolls the view to reveal the current selection
"""
    }

    private static var GetAppSwitchingContent: () -> String = {
        return """
-- App Switching --
>> Hold Cmd and press Tab repeatedly to cycle through open apps. Release Cmd to switch to the highlighted app. You can also press Q or H while still holding Cmd to quit or hide an app without leaving the switcher.

Cmd + Tab:              Open App Switcher, cycle forward :: Hold Cmd and press Tab to move right through open apps
Cmd + Shift + Tab:      Cycle App Switcher backward :: Moves left through the app switcher list
Cmd + Tab, then Q:      Quit app in switcher :: Quits the highlighted app without switching to it
Cmd + Tab, then H:      Hide app in switcher :: Hides all windows of the highlighted app

-- Window Management --
>> These shortcuts manage windows of the currently active app. Cmd + ` (backtick) is especially useful when an app has multiple open documents.

Cmd + `:                Cycle windows forward :: Moves through open windows of the current app
Cmd + Shift + `:        Cycle windows backward :: Moves in reverse through open windows
Cmd + M:                Minimize window :: Sends the front window to the Dock
Cmd + H:                Hide current app :: Hides all windows; app stays running
Cmd + Option + H:       Hide all other apps :: Clears the screen to only the current app
Control + Cmd + F:      Enter / exit full screen :: Expands or restores the front window

-- Mission Control & Spaces --
>> Mission Control gives you a full overview of every open window and desktop Space. Spaces let you organise apps across virtual desktops.

Control + Up:           Mission Control :: Shows all open windows and desktop Spaces at once
Control + Down:         App Exposé :: Shows only the windows of the current app
Control + Left:         Move to Space on the left :: Switches to the previous desktop Space
Control + Right:        Move to Space on the right :: Switches to the next desktop Space
Control + 1–9:          Switch to specific Space :: Jumps directly to a numbered Space (set in System Settings)
F11:                    Show Desktop :: Moves all windows aside to reveal the Desktop

-- Dock --
>> You can navigate the Dock entirely by keyboard. Control + F3 is the entry point — use arrow keys to navigate once focused.

Cmd + Option + D:       Show / hide Dock :: Toggles the Dock's visibility
Control + F3:           Focus the Dock :: Moves keyboard focus into the Dock
Arrow keys (in Dock):   Navigate Dock items :: Move left and right through Dock icons
Return (in Dock):       Open selected item :: Launches or activates the focused Dock icon

-- Focus & Utilities --
>> These shortcuts open system-wide utilities that work from any app.

Cmd + Option + Esc:     Force Quit dialog :: Opens the Force Quit window to kill unresponsive apps
Control + Cmd + Space:  Character Viewer :: Opens the emoji and symbol picker
Cmd + Space:            Spotlight search :: Search for apps, files, contacts, and web results
"""
    }

    private static var GetScreenshotsContent: () -> String = {
        return """
-- Screenshot Shortcuts --
>> Screenshots are saved as PNG files on your Desktop by default. Add Ctrl to any shortcut to capture to the clipboard instead of saving a file — useful when you want to paste the screenshot directly into a document or message.

Cmd + Shift + 3:        Capture entire screen :: Saves a full-screen PNG to the Desktop
Cmd + Shift + 4:        Capture selected area :: Crosshair cursor appears — drag to choose a region
Cmd + Shift + 4, Space: Capture a specific window :: Move cursor over a window and click to capture just that window
Cmd + Shift + 5:        Screenshot toolbar :: Opens all screenshot and screen recording options
Cmd + Shift + 6:        Capture Touch Bar :: Captures the Touch Bar strip (MacBook Pro only)

-- Save to Clipboard Instead of Desktop --
>> Adding Ctrl to any screenshot shortcut sends the image directly to the clipboard. No file is created.

Ctrl + Cmd + Shift + 3: Full screen to clipboard :: Captures entire screen, ready to paste immediately
Ctrl + Cmd + Shift + 4: Selection to clipboard :: Drag to capture a region directly to the clipboard
Ctrl + Cmd + Shift + 4, Space: Window to clipboard :: Click a window to copy it to the clipboard

-- Screenshot Toolbar Options (Cmd + Shift + 5) --
>> The toolbar consolidates all capture modes in one place and adds screen recording. Use Options to change the save location or add a timer delay.

Entire Screen:          Capture full display :: Takes a screenshot of the entire screen
Selected Window:        Capture a window :: Click any window to capture just that window
Selected Portion:       Capture a region :: Drag to define the area to capture
Record Entire Screen:   Screen recording — full screen :: Records everything on screen until you click Stop
Record Selected Portion: Screen recording — region :: Records only the area you define

-- Screenshot Toolbar Controls --
Escape:                 Cancel / close toolbar :: Dismisses the toolbar without capturing
Return:                 Capture or start recording :: Confirms the current mode and takes the screenshot
Timer option:           Add a delay :: Choose 5 or 10 seconds in Options before capture starts

-- Screen Recording --
>> Screen recordings are saved as MOV files to the Desktop. Press Ctrl + Cmd + Esc to stop recording, or press the Stop button in the menu bar.

Cmd + Shift + 5:        Open screen recording options :: Choose full screen or region recording
Cmd + Ctrl + Esc:       Stop recording :: Ends a screen recording from any app
"""
    }

    private static var GetWordMacContent: () -> String = {
        return """
-- General --
>> Core file management and universal editing commands that work throughout Word.
Cmd + N: New document :: Creates a blank document from default template
Cmd + O: Open document :: Opens the file browser to choose an existing file
Cmd + S: Save :: Saves current document; prompts for filename if new
Cmd + Shift + S: Save As :: Saves a copy under a new name or location
Cmd + P: Print :: Opens print dialog with layout and printer options
Cmd + W: Close document :: Closes current document; prompts to save if unsaved
Cmd + Z: Undo :: Steps back through recent changes one at a time
Cmd + Y: Redo :: Re-applies the last undone change
Cmd + A: Select All :: Selects all text and objects in the document
Cmd + F: Find :: Opens the Navigation pane to search text in the document
Cmd + H: Find and Replace :: Opens Find & Replace dialog to substitute text

-- Text Formatting --
>> Shortcuts that apply character-level formatting to selected text.
Cmd + B: Bold :: Toggles bold weight on selected text
Cmd + I: Italic :: Toggles italic style on selected text
Cmd + U: Underline :: Toggles single underline on selected text
Cmd + Shift + D: Double underline :: Applies double underline to selected text
Cmd + Shift + W: Word underline only :: Underlines words but not spaces
Cmd + D: Font dialog :: Opens the full Font formatting dialog box
Cmd + Shift + >: Increase font size :: Grows font by the next standard size step
Cmd + Shift + <: Decrease font size :: Shrinks font by the next standard size step
Cmd + Shift + A: All Caps :: Toggles all-caps formatting on selected text
Cmd + Shift + K: Small Caps :: Applies small capitals to selected text
Cmd + =: Subscript :: Formats selected text as subscript (e.g. H₂O)
Cmd + Shift + =: Superscript :: Formats selected text as superscript (e.g. x²)
Cmd + Space: Clear character formatting :: Removes all manual character formatting

-- Paragraph Formatting --
>> Shortcuts for paragraph alignment, spacing, and indentation of selected paragraphs.
Cmd + E: Center align :: Centers the selected paragraph(s) horizontally
Cmd + L: Left align :: Left-justifies the selected paragraph(s)
Cmd + R: Right align :: Right-justifies the selected paragraph(s)
Cmd + J: Justify :: Stretches text to fill full line width on both sides
Cmd + 1: Single line spacing :: Sets paragraph line spacing to 1.0
Cmd + 2: Double line spacing :: Sets paragraph line spacing to 2.0
Cmd + 5: 1.5 line spacing :: Sets paragraph line spacing to 1.5
Cmd + Option + 1: Heading 1 style :: Applies Heading 1 paragraph style
Cmd + Option + 2: Heading 2 style :: Applies Heading 2 paragraph style
Cmd + Option + 3: Heading 3 style :: Applies Heading 3 paragraph style
Cmd + Shift + N: Normal style :: Applies the Normal (body text) paragraph style
Cmd + M: Indent paragraph :: Increases left indent by one tab stop
Cmd + Shift + M: Remove indent :: Decreases left indent by one tab stop
Cmd + T: Hanging indent :: Creates a hanging indent for the current paragraph
Cmd + Shift + T: Remove hanging indent :: Removes the hanging indent

-- Editing --
>> Cut, copy, paste, and deletion shortcuts for moving and inserting content.
Cmd + X: Cut :: Removes selection and places it on the clipboard
Cmd + C: Copy :: Copies selection to the clipboard without removing it
Cmd + V: Paste :: Inserts clipboard content at the cursor
Cmd + Shift + V: Paste Special :: Opens dialog for paste format options
Option + Shift + Cmd + V: Paste and Match Formatting :: Pastes text matching the destination style
Cmd + K: Insert hyperlink :: Opens the Insert Hyperlink dialog
Delete: Delete character left :: Deletes the character to the left of the cursor
fn + Delete: Delete character right :: Deletes the character to the right of the cursor
Option + Delete: Delete word left :: Deletes the entire word to the left of the cursor
Option + fn + Delete: Delete word right :: Deletes the entire word to the right of the cursor

-- Navigation --
>> Shortcuts to jump to specific positions within a document.
Cmd + Home (fn + Left): Beginning of document :: Moves cursor to the very start of the document
Cmd + End (fn + Right): End of document :: Moves cursor to the very end of the document
Cmd + G: Go To :: Opens Go To dialog (page, line, bookmark, footnote)
Cmd + F: Open Navigation Pane :: Opens pane for searching and browsing headings
Cmd + Option + G: Go To footnote / endnote :: Jumps to the next footnote or endnote
Option + Left/Right: Word by word :: Moves cursor one word at a time left or right
Cmd + Left/Right: Beginning / end of line :: Jumps to start or end of the current line

-- View --
>> Shortcuts for changing the document view, zoom level, and interface layout.
Cmd + Option + P: Print Layout view :: Switches to the standard page layout view
Cmd + Option + N: Draft view :: Shows plain text view without headers/footers
Cmd + Option + O: Outline view :: Opens the document outline structure
Cmd + F1: Expand/collapse Ribbon :: Shows or hides the Ribbon toolbar
Control + Cmd + F: Full screen :: Enters full-screen editing mode
Cmd + +: Zoom in :: Increases document zoom level
Cmd + -: Zoom out :: Decreases document zoom level

-- Tables --
>> Keyboard navigation and editing within Word tables.
Tab: Next cell in table :: Moves focus to the next cell to the right
Shift + Tab: Previous cell in table :: Moves focus to the previous cell
Option + Return: New paragraph within cell :: Inserts a line break inside the current cell
Tab at last cell: Add new row :: Pressing Tab in the last cell adds a new row below

-- Spelling, Comments & Review --
>> Shortcuts for spell check, comments, and reviewing tracked changes.
F7: Open Editor pane :: Opens the Editor pane for spelling, grammar, and style review
Option + Cmd + L: Open Editor pane :: Alternative shortcut to open the Editor pane
Cmd + Option + A: Insert new comment :: Adds a new comment anchored to the selection
Cmd + Shift + E: Track Changes on/off :: Enables or disables change tracking

-- VoiceOver & Accessibility (Word for Mac) --
>> Word for Mac works well with VoiceOver when Accessibility mode is active.
>> Run the Accessibility Checker: Review tab → Check Accessibility, to catch issues in documents you create.
Cmd + F1: Expand/collapse Ribbon :: Use to show the Ribbon; Tab through ribbon tabs with arrow keys
F6: Cycle focus between Ribbon, document, status bar :: Move focus between major areas of the Word window
Tab: Move between controls in dialogs :: Navigate buttons, checkboxes, and fields in any dialog
Cmd + Option + 1/2/3: Apply Heading styles :: Add structure for VoiceOver H-key navigation when exported to HTML/PDF
>> Headings (Cmd+Option+1/2/3) create document structure VoiceOver users navigate with H in web or Word.
>> In the document, VO reads the cursor position; use Ctrl+G to jump to specific pages.
>> For tables: use Tab/Shift+Tab to move between cells; VO announces cell content and position.
>> Use the Navigation Pane (Cmd+F) to jump between headings — VO reads each heading as you navigate.
>> Turn on "Speak selected text" in System Settings > Accessibility > Spoken Content for quick reads.
"""
    }

    private static var GetExcelMacContent: () -> String = {
        return """
-- General --
>> Core file and application commands for managing Excel workbooks.
Cmd + N: New workbook :: Opens a new blank workbook
Cmd + O: Open workbook :: Opens the file browser to select an existing workbook
Cmd + S: Save :: Saves the current workbook
Cmd + Shift + S: Save As :: Saves a copy with a new name or location
Cmd + P: Print :: Opens print settings for the active sheet
Cmd + W: Close workbook :: Closes the current workbook; prompts to save
Cmd + Z: Undo :: Reverses the last action
Cmd + Y: Redo :: Re-applies the last undone action
Cmd + A: Select All :: Selects all cells in the worksheet
Cmd + F: Find :: Opens the Find toolbar to search cell contents
Cmd + H: Find and Replace :: Opens dialog to search and substitute values

-- Navigation --
>> Moving the active cell around the worksheet.
Arrow keys: Move one cell :: Moves the active cell one step in any direction
Cmd + Arrow: Jump to edge of data region :: Jumps to the last non-empty cell in that direction
Ctrl + Home (fn + Ctrl + Left): Go to cell A1 :: Moves to the very first cell of the sheet
Ctrl + End: Go to last used cell :: Moves to the bottom-right corner of used data
Page Up / Page Down: Move up / down one screen :: Scrolls the view one visible page at a time
Option + Page Up/Down: Move left / right one screen :: Scrolls horizontally by one visible page
Cmd + G (F5): Go To dialog :: Opens Go To dialog for jumping to a named cell or range
Tab: Move right one cell :: Moves to the next cell to the right after confirming entry
Shift + Tab: Move left one cell :: Moves to the previous cell to the left
Return: Move down one cell / confirm entry :: Confirms entry and moves down one row
Shift + Return: Move up one cell :: Confirms entry and moves up one row

-- Selecting --
>> Extending the selection to cover multiple cells or entire rows/columns.
Shift + Arrow: Extend selection :: Adds one cell at a time to the current selection
Cmd + Shift + Arrow: Extend to last non-empty cell :: Extends selection to the edge of a data block
Shift + Space: Select entire row :: Selects the full row of the active cell
Cmd + Space: Select entire column :: Selects the full column of the active cell
Cmd + A: Select entire worksheet :: Selects every cell in the sheet
Cmd + Shift + *: Select current region :: Selects the contiguous block of data around the cursor

-- Entering & Editing Data --
>> Shortcuts for entering, editing, and filling cell content.
Return: Confirm and move down :: Finishes entry in the current cell and moves down
Tab: Confirm and move right :: Finishes entry and moves to the next cell on the right
Escape: Cancel entry :: Discards changes to the current cell and leaves it unchanged
F2 (Mac: Ctrl + U): Edit active cell :: Puts the active cell into edit mode
Delete: Clear cell contents :: Removes data from selected cells without affecting formatting
Cmd + D: Fill Down :: Copies the top cell's content down to all selected cells below
Cmd + R: Fill Right :: Copies the leftmost cell's content to all selected cells on the right
Cmd + ': Copy formula from cell above :: Duplicates the formula from the cell directly above
Cmd + ;: Insert current date :: Types today's date into the active cell
Cmd + Shift + ;: Insert current time :: Types the current time into the active cell
Option + Return: Start new line in same cell :: Inserts a line break within the cell (wraps text)

-- Formatting --
>> Applying number formats and text styles to selected cells.
Cmd + 1: Format Cells dialog :: Opens the full Format Cells dialog with all tabs
Cmd + B: Bold :: Toggles bold formatting on selected cells
Cmd + I: Italic :: Toggles italic formatting on selected cells
Cmd + U: Underline :: Toggles underline formatting on selected cells
Cmd + Shift + ~: General number format :: Applies the default General format
Cmd + Shift + $: Currency format :: Applies currency format with two decimal places
Cmd + Shift + %: Percentage format :: Converts the value to a percentage display
Cmd + Shift + ^: Scientific notation format :: Displays the number in scientific notation
Cmd + Shift + #: Date format :: Applies the standard date format
Cmd + Shift + @: Time format :: Applies the standard time format
Cmd + Shift + !: Number format :: Applies number format with comma separator and 2 decimals
Option + Cmd + 0: Outline border :: Adds a border around the selected cell range
Option + Cmd + Shift + -: Remove border :: Removes all borders from selected cells

-- Formulas --
>> Creating and inspecting formulas and cell references.
= (equals): Start a formula :: Typing = in a cell begins formula entry mode
Cmd + T: Toggle absolute/relative reference :: Cycles through $A$1, A$1, $A1, A1 reference styles (while editing a formula); fn + F4 also works in Excel 365
Cmd + Shift + U: Expand / collapse formula bar :: Resizes the formula bar for long formulas
Cmd + `: Toggle formula display :: Switches between showing values and showing formulas
fn + F11: Insert chart sheet :: Creates a new chart sheet from the selected data range

-- Rows, Columns & Sheets --
>> Managing the structure of the workbook: rows, columns, and sheet tabs.
Cmd + Shift + + (Plus): Insert row or column dialog :: Opens Insert dialog to add a row or column at the selection
Cmd + -: Delete row or column dialog :: Opens Delete dialog to remove selected rows or columns
fn + Shift + F2: Insert / edit comment :: Adds or edits the comment on the active cell
Control + Shift + Right: Select to last column in row :: Extends selection to the last used column
Cmd + Page Down: Next worksheet tab :: Moves to the next sheet tab on the right
Cmd + Page Up: Previous worksheet tab :: Moves to the previous sheet tab on the left
fn + Shift + F11: Insert new worksheet :: Adds a new blank sheet to the workbook

-- Views --
>> Changing how the worksheet is displayed on screen.
Control + Cmd + F: Full screen :: Toggles full-screen mode for more editing space
Cmd + F1: Show/hide Ribbon :: Collapses or expands the Excel Ribbon toolbar
"""
    }

    private static var GetPowerPointMacContent: () -> String = {
        return """
-- General --
>> File management and universal commands for PowerPoint presentations.
Cmd + N: New presentation :: Creates a blank presentation from the default theme
Cmd + O: Open presentation :: Opens the file browser to select an existing file
Cmd + S: Save :: Saves the current presentation
Cmd + Shift + S: Save As :: Saves a copy with a new name or format
Cmd + P: Print :: Opens print dialog for printing slides or handouts
Cmd + W: Close presentation :: Closes the current file; prompts to save if needed
Cmd + Z: Undo :: Reverses the last change
Cmd + Y: Redo :: Re-applies the last undone change

-- Editing Slides --
>> Adding, selecting, and managing objects on slides in Normal view.
Cmd + D: Duplicate slide :: Creates an exact copy of the selected slide
Cmd + Shift + N: New slide :: Inserts a new blank slide after the current one
Cmd + X: Cut :: Removes the selection and places it on the clipboard
Cmd + C: Copy :: Copies the selected object or slide to the clipboard
Cmd + V: Paste :: Inserts the clipboard content onto the current slide
Delete: Delete selected object / slide :: Removes the selected item
Cmd + A: Select all objects on slide :: Selects every object on the current slide
Tab: Select next object on slide :: Moves focus to the next object in the tab order
Shift + Tab: Select previous object on slide :: Moves focus to the previous object
Escape: Deselect / exit text box :: Exits text editing mode or deselects the current object
Return: Enter edit mode for selected text box :: Enters text editing inside the selected shape

-- Text Formatting --
>> Applying character and paragraph formatting inside text boxes.
Cmd + B: Bold :: Toggles bold on selected text
Cmd + I: Italic :: Toggles italic on selected text
Cmd + U: Underline :: Toggles underline on selected text
Cmd + Shift + >: Increase font size :: Grows the font to the next standard size
Cmd + Shift + <: Decrease font size :: Shrinks the font to the previous standard size
Cmd + E: Center align :: Centers the paragraph horizontally in the text box
Cmd + L: Left align :: Left-aligns the paragraph
Cmd + R: Right align :: Right-aligns the paragraph
Cmd + K: Insert hyperlink :: Opens the Insert Hyperlink dialog

-- Slide Navigation --
>> Moving between slides in Normal or Slide Sorter view.
Up / Down arrow: Previous / next slide :: Navigates slides in the slide panel
Page Up / Page Down: Previous / next slide :: Alternative navigation between slides
Cmd + Home (fn+Cmd+Left): First slide :: Jumps to slide 1 of the presentation
Cmd + End (fn+Cmd+Right): Last slide :: Jumps to the last slide

-- Slide Show --
>> Controls for running and navigating a live slide show.
F5: Start slide show from beginning :: Begins the presentation from slide 1
Cmd + Return: Start slide show from current slide :: Begins from the currently selected slide
Escape: End slide show :: Exits the presentation and returns to Normal view
N or Right Arrow: Next slide / animation step :: Advances to the next slide or animation
P or Left Arrow: Previous slide / animation step :: Goes back to the previous slide or animation
B: Black screen toggle :: Blacks out the screen; press again to resume
W: White screen toggle :: Whites out the screen; press again to resume
S: Stop / resume automatic show :: Pauses or resumes a timed auto-advance presentation
Number + Return: Go to specific slide number :: Types a slide number then Enter to jump there

-- Objects & Drawing --
>> Arranging, grouping, and precisely positioning drawn objects.
Option + Arrow: Nudge object one pixel :: Moves the selected object by a single pixel
Shift + Arrow: Resize object :: Resizes the selected shape in the arrow direction
Cmd + G: Group objects :: Combines selected objects into a single group
Cmd + Shift + G: Ungroup objects :: Breaks a group back into individual objects
Cmd + Option + G: Regroup :: Re-groups objects that were previously ungrouped
Cmd + Shift + F: Send to front :: Brings selected object to the top of the layer stack
Cmd + Shift + B: Send to back :: Sends selected object to the bottom of the layer stack
Cmd + Shift + Option + F: Bring forward one level :: Moves the object up one position in the stack
Cmd + Shift + Option + B: Send backward one level :: Moves the object down one position in the stack

-- Views --
>> Switching between editing views and interface modes.
Cmd + 1: Normal view :: Standard editing view with slide canvas and panel
Cmd + 2: Slide Sorter view :: Grid view of all slides for reordering
Cmd + 3: Notes Page view :: Shows the speaker notes page for each slide
Cmd + 4: Outline view :: Shows the text outline of all slides
Option + Return: Start in Presenter view :: Begins the show in Presenter view from current slide
Control + Cmd + F: Full screen :: Maximises the PowerPoint window to fill the screen
"""
    }

    private static var GetOutlookMacContent: () -> String = {
        return """
-- General Navigation --
>> Shortcuts for moving between Outlook's main modules and panes.
Cmd + 1: Mail :: Switches to the Mail module
Cmd + 2: Calendar :: Switches to the Calendar module
Cmd + 3: Contacts :: Switches to the Contacts module
Cmd + 4: Tasks :: Switches to the Tasks module
Cmd + 5: Notes :: Switches to the Notes module
Cmd + /: Show keyboard shortcuts :: Displays a list of all available shortcuts
F6: Move between panes :: Cycles keyboard focus between the sidebar, list, and reading pane

-- Mail --
>> Reading, replying to, and organising email messages in the Mail module.
Cmd + N: New message :: Composes a new email message
Cmd + Shift + M: New message (from any view) :: Opens a new compose window from any module
Cmd + R: Reply :: Opens a reply addressed to the sender only
Cmd + Shift + R: Reply All :: Opens a reply addressed to all recipients
Cmd + J: Forward message :: Forwards the selected message to a new recipient
Cmd + Delete: Delete message :: Moves the selected message to the Deleted Items folder
Cmd + Y: Move to folder / Archive :: Opens the move-to-folder dialog
Cmd + Shift + T: Mark as Unread :: Marks the selected message as unread
Option + Cmd + T: Mark as Read :: Marks the selected message as read
Cmd + L: Flag message :: Adds a follow-up flag to the selected message
Cmd + Shift + L: Clear flag :: Removes the follow-up flag from the message
Cmd + F: Find / Search :: Opens the search box in the Mail list
Cmd + Shift + F: Advanced search :: Opens the advanced search filters panel
Cmd + Option + F: Filter mail :: Applies a filter to show only certain messages
Return: Open selected message :: Opens the focused message in a new window
Space: Scroll message / Preview :: Scrolls through the message body in the reading pane
Cmd + [: Previous message :: Moves to the message above in the list
Cmd + ]: Next message :: Moves to the message below in the list
Cmd + Option + U: Sync all accounts :: Forces a manual send/receive for all accounts

-- Composing Messages --
>> Shortcuts active while writing or formatting a new message or reply.
Cmd + Return: Send message :: Sends the composed message immediately
Option + Cmd + F: Insert file attachment :: Opens the file browser to attach a file
Cmd + K: Insert hyperlink :: Opens the Insert Hyperlink dialog in the message body
Cmd + B: Bold :: Toggles bold on selected text in the message body
Cmd + I: Italic :: Toggles italic on selected text in the message body
Cmd + U: Underline :: Toggles underline on selected text
Cmd + A: Select all text :: Selects all text in the current field
Cmd + Z: Undo :: Reverses the last action while composing
Tab: Move between To / Cc / Bcc / Subject / Body :: Advances focus through the address and subject fields

-- Calendar --
>> Navigating and managing events in the Calendar module.
Cmd + N: New event :: Creates a new calendar event
Cmd + E: Edit selected event :: Opens the selected event for editing
Delete: Delete selected event :: Removes the selected event from the calendar
Cmd + T: Go to today :: Scrolls the calendar view to today's date
Control + Cmd + 1: Day view :: Shows a single-day calendar view
Control + Cmd + 2: Work week view :: Shows a 5-day work week view
Control + Cmd + 3: Week view :: Shows a full 7-day week view
Control + Cmd + 4: Month view :: Shows the full month calendar grid
Left/Right arrow: Previous / next day, week, or month :: Navigates forward or backward in the current view

-- Contacts --
>> Finding and managing contact cards in the Contacts module.
Cmd + N: New contact :: Creates a new contact card
Cmd + E: Edit contact :: Opens the selected contact for editing
Cmd + F: Find contacts :: Moves focus to the search field
Delete: Delete selected contact :: Moves the selected contact to Deleted Items
"""
    }

    private static var GetOneNoteMacContent: () -> String = {
        return """
-- General --
>> File and notebook management commands for OneNote on Mac.
Cmd + N: New page :: Adds a new page in the current section
Cmd + Shift + N: New section :: Adds a new section in the current notebook
Cmd + T: New notebook :: Creates a new notebook (from the Notebooks pane)
Cmd + S: Sync notebook :: Manually syncs the notebook with OneDrive
Cmd + Z: Undo :: Reverses the last editing action
Cmd + Y: Redo :: Re-applies the last undone action
Cmd + F: Find on page :: Searches for text within the current page
Cmd + Option + F: Search all notebooks :: Searches across all notebooks
Cmd + P: Print page :: Prints the current page
Cmd + A: Select all on page :: Selects all content on the current page
Cmd + W: Close notebook :: Closes the currently open notebook

-- Text Formatting --
>> Applying character-level text styles and inserting links.
Cmd + B: Bold :: Toggles bold on the selected text
Cmd + I: Italic :: Toggles italic on the selected text
Cmd + U: Underline :: Toggles underline on the selected text
Cmd + Shift + H: Highlight text :: Highlights selected text in yellow
Cmd + K: Insert hyperlink :: Opens the Insert Link dialog
Cmd + Shift + >: Increase font size :: Grows font to the next standard size
Cmd + Shift + <: Decrease font size :: Shrinks font to the previous standard size

-- Note Taking --
>> Formatting lists, indentation, and heading styles while writing notes.
Return: New line / new list item :: Starts a new line or adds a new bullet/number
Shift + Return: Insert line break :: Inserts a line break without starting a new list item
Tab: Increase list indent :: Indents the current list item one level deeper
Shift + Tab: Decrease list indent :: Outdents the current list item one level
Cmd + Shift + L: Bullet list :: Converts the current or selected lines to a bulleted list
Cmd + /: Numbered list :: Converts the current or selected lines to a numbered list
Cmd + Option + 1: Heading 1 :: Applies Heading 1 style to the current paragraph
Cmd + Option + 2: Heading 2 :: Applies Heading 2 style to the current paragraph
Cmd + Option + 3: Heading 3 :: Applies Heading 3 style to the current paragraph
Cmd + Shift + 0: Clear formatting :: Removes all manual formatting from selected text

-- Tags & To-Do --
>> Tagging notes for follow-up, review, or categorisation.
Cmd + 1: To-Do tag (checkbox) :: Adds a checkbox to mark items as complete or pending
Cmd + 2: Important tag (star) :: Marks the note with a yellow star for importance
Cmd + 3: Question tag :: Marks the note with a question mark for follow-up
Cmd + 4: Remember for later tag :: Marks the note for later follow-up
Cmd + 5: Definition tag :: Tags the note as a definition for study or reference

-- Navigation --
>> Moving between pages and sections within notebooks.
Cmd + ]: Forward in navigation history :: Goes forward to the previously viewed page
Cmd + [: Backward in navigation history :: Goes back to the page viewed before
Cmd + Option + G: Move page to section :: Opens dialog to move the current page to another section
F6: Move focus between sections and pages :: Cycles keyboard focus between the section list and page list

-- Tables --
>> Keyboard navigation and editing within OneNote tables.
Tab: Next cell :: Moves focus to the next cell to the right
Shift + Tab: Previous cell :: Moves focus to the previous cell
Return: New row at bottom :: Adds a new row when in the last row of the table
Tab at last cell: Create new row :: Pressing Tab in the bottom-right cell adds a new row
Cmd + Return: Add row below current row :: Inserts a new row directly below the current row
"""
    }

    private static var GetWordOnlineContent: () -> String = {
        return """
-- General --
>> File management and app-level commands for Word in a web browser.
Cmd + N: New document :: Opens a new blank document in a new browser tab
Cmd + O: Open document :: Opens the file picker to select an existing document
Cmd + S: Save :: Forces a manual sync; Word Online auto-saves continuously
Cmd + P: Print :: Opens the browser print dialog for the current document
Cmd + Z: Undo :: Reverses the last editing action
Cmd + Y: Redo :: Re-applies the last undone action
Cmd + A: Select All :: Selects all content in the document
Cmd + F: Find :: Opens the browser's find bar (limited functionality in the editor)
Cmd + /: Show keyboard shortcuts help :: Displays the full keyboard shortcut reference

-- Text Formatting --
>> Applying character styles to selected text in the online editor.
Cmd + B: Bold :: Toggles bold on selected text
Cmd + I: Italic :: Toggles italic on selected text
Cmd + U: Underline :: Toggles underline on selected text
Cmd + Shift + >: Increase font size :: Grows the font to the next standard size
Cmd + Shift + <: Decrease font size :: Shrinks the font to the previous standard size
Cmd + Shift + A: All caps :: Toggles all-capitals formatting on selected text
Cmd + =: Subscript :: Formats selected text as subscript (e.g. H₂O)
Cmd + Shift + =: Superscript :: Formats selected text as superscript (e.g. x²)
Cmd + Space: Clear character formatting :: Removes manual formatting from selected text

-- Paragraph Formatting --
>> Applying paragraph alignment and spacing in the online editor.
Cmd + L: Align left :: Left-aligns the current paragraph
Cmd + E: Center :: Centers the current paragraph
Cmd + R: Align right :: Right-aligns the current paragraph
Cmd + J: Justify :: Justifies both sides of the current paragraph
Cmd + 1: Single line spacing :: Sets line spacing to 1.0 for the paragraph
Cmd + 2: Double line spacing :: Sets line spacing to 2.0 for the paragraph
Cmd + 5: 1.5 line spacing :: Sets line spacing to 1.5 for the paragraph
Cmd + Shift + L: Add bullet list :: Formats the current paragraph as a bulleted list item

-- Editing --
>> Cut, copy, paste, and insertion shortcuts in the online editor.
Cmd + X: Cut :: Removes selected content and places it on the clipboard
Cmd + C: Copy :: Copies selected content to the clipboard
Cmd + V: Paste :: Inserts clipboard content at the cursor
Cmd + Shift + V: Paste as plain text :: Pastes clipboard content without any formatting
Cmd + K: Insert hyperlink :: Opens the Insert Hyperlink dialog
Cmd + Return: Page break :: Inserts a manual page break at the cursor
Shift + Return: Line break :: Inserts a line break (soft return) without a new paragraph

-- Navigation --
>> Moving the cursor within the document in the online editor.
Cmd + Home (fn+Cmd+Left): Beginning of document :: Jumps to the very start of the document
Cmd + End (fn+Cmd+Right): End of document :: Jumps to the very end of the document
Option + Left/Right: Word by word :: Moves the cursor one word at a time
Cmd + Left/Right: Beginning / end of line :: Jumps to the start or end of the current line
"""
    }

    private static var GetExcelOnlineContent: () -> String = {
        return """
-- General --
>> File and app-level commands for Excel in a web browser (Excel Online).
Cmd + N: New workbook :: Opens a new blank workbook in a new browser tab
Cmd + S: Save / Sync :: Forces a sync; Excel Online saves automatically
Cmd + P: Print :: Opens the browser print dialog for the active sheet
Cmd + Z: Undo :: Reverses the last action in the spreadsheet
Cmd + Y: Redo :: Re-applies the last undone action
Cmd + F: Find :: Opens the browser's native find toolbar for cell content search
Cmd + H: Find and Replace :: Opens the Find and Replace dialog
Cmd + A: Select all :: Selects all cells in the current worksheet
Cmd + /: Keyboard shortcuts help :: Shows the Excel Online keyboard shortcut reference

-- Navigation --
>> Moving the active cell around the worksheet in the browser.
Arrow keys: Move one cell :: Moves the active cell one step in any direction
Tab: Next cell (right) :: Moves to the next cell on the right; confirms entry
Shift + Tab: Previous cell (left) :: Moves to the previous cell on the left
Return: Move down / confirm :: Confirms entry in the current cell and moves down
Escape: Cancel entry :: Discards the current cell edit without saving changes
Cmd + Home: Go to A1 :: Jumps to cell A1 at the beginning of the sheet
Cmd + End: Last used cell :: Jumps to the last cell containing data
Cmd + Arrow: Jump to edge of data :: Jumps to the last non-empty cell in that direction

-- Selecting --
>> Extending the selection to cover multiple cells, rows, or columns.
Shift + Arrow: Extend selection :: Adds one cell at a time to the current selection
Cmd + Shift + Arrow: Extend to end of data :: Extends selection to the edge of the data block
Shift + Space: Select row :: Selects the entire row of the active cell
Cmd + Space: Select column :: Selects the entire column of the active cell

-- Editing --
>> Entering, editing, and filling data in worksheet cells.
F2 (or Ctrl+U): Edit cell :: Puts the active cell into inline edit mode
Delete: Clear cell :: Removes the content of the selected cell(s)
Cmd + D: Fill Down :: Copies the top cell of the selection to all cells below
Cmd + R: Fill Right :: Copies the leftmost cell to all selected cells on the right
Cmd + ;: Insert date :: Inserts today's date into the active cell
Option + Return: New line in cell :: Inserts a line break within the cell to wrap text

-- Formatting --
>> Applying number formats and text styles to selected cells online.
Cmd + B: Bold :: Toggles bold formatting on selected cells
Cmd + I: Italic :: Toggles italic formatting on selected cells
Cmd + U: Underline :: Toggles underline formatting on selected cells
Cmd + 1: Format Cells dialog :: Opens the Format Cells dialog with all formatting options
Cmd + Shift + $: Currency format :: Applies the currency number format
Cmd + Shift + %: Percentage format :: Converts values to percentage display
Cmd + Shift + #: Date format :: Applies the standard short date format
Cmd + Shift + !: Number format :: Applies comma-separated number format with 2 decimals

-- Sheets --
>> Navigating between worksheet tabs in Excel Online.
(Right-click tab to rename, insert, delete sheets)
Cmd + Page Down: Next sheet :: Moves to the next sheet tab to the right
Cmd + Page Up: Previous sheet :: Moves to the previous sheet tab to the left
"""
    }

    private static var GetPowerPointOnlineContent: () -> String = {
        return """
-- General --
>> File management and app-level commands for PowerPoint in a browser.
Cmd + N: New presentation :: Opens a new blank presentation in a new browser tab
Cmd + O: Open presentation :: Opens the file picker to select an existing file
Cmd + S: Save / Sync :: Forces a manual sync; PowerPoint Online auto-saves
Cmd + P: Print :: Opens the browser print dialog for slides or handouts
Cmd + Z: Undo :: Reverses the last change in the presentation
Cmd + Y: Redo :: Re-applies the last undone change
Cmd + /: Keyboard shortcuts help :: Displays the full shortcut reference for PowerPoint Online

-- Editing Slides --
>> Adding, duplicating, and selecting objects on slides in the browser editor.
Cmd + D: Duplicate slide :: Creates an exact copy of the selected slide
Cmd + M: Insert new slide :: Adds a new slide after the current one
Delete: Delete selected slide or object :: Removes the selected item from the presentation
Cmd + A: Select all :: Selects all objects on the current slide
Tab: Select next object :: Moves focus to the next object on the slide
Shift + Tab: Select previous object :: Moves focus to the previous object on the slide
Escape: Deselect / exit text edit :: Exits text editing mode or deselects the current object
Return: Enter text edit mode :: Enters text editing inside the selected shape or placeholder

-- Text Formatting --
>> Applying text styles inside placeholders and text boxes in the browser.
Cmd + B: Bold :: Toggles bold on selected text
Cmd + I: Italic :: Toggles italic on selected text
Cmd + U: Underline :: Toggles underline on selected text
Cmd + Shift + >: Increase font size :: Grows the font to the next standard size
Cmd + Shift + <: Decrease font size :: Shrinks the font to the previous standard size

-- Slide Navigation --
>> Navigating between slides in the slide panel and editor.
Page Up / Down: Previous / next slide :: Moves through slides in the Normal view
Home (fn + Left): First slide :: Jumps to the first slide in the presentation
End (fn + Right): Last slide :: Jumps to the last slide in the presentation

-- Slide Show --
>> Controls for presenting slides in full-screen Slide Show mode.
F5: Start from beginning :: Starts the full-screen slide show from slide 1
Cmd + Return: Start from current slide :: Starts the show from the currently selected slide
Escape: End slide show :: Exits the presentation and returns to the editor
Right / N: Next slide / animation :: Advances to the next slide or animation step
Left / P: Previous slide / animation :: Returns to the previous slide or step
B: Black screen :: Temporarily blacks out the screen during the presentation
W: White screen :: Temporarily whites out the screen during the presentation
Number + Return: Jump to slide number :: Type a number then Enter to jump to that slide
"""
    }

    private static var GetOutlookOnlineContent: () -> String = {
        return """
-- General --
>> App-level search and navigation in Outlook on the web.
? or Shift + /: Show keyboard shortcuts :: Displays the complete keyboard shortcut reference
Cmd + F: Search :: Moves focus to the search box to find emails or contacts
Cmd + N: New message :: Opens a new compose window from any view
Cmd + Shift + M: New message (any view) :: Opens a new compose window regardless of current view

-- Mail --
>> Reading, managing, and acting on email messages in the inbox.
>> Keyboard shortcuts must be enabled in Outlook Settings > General > Accessibility first.
R: Reply to message :: Opens a reply addressed to the sender only
Shift + R (or A): Reply All :: Opens a reply addressed to all recipients
F: Forward message :: Forwards the selected message to a new recipient
Delete or Backspace: Delete message :: Moves the selected message to the Deleted Items folder
U: Mark as Read/Unread :: Toggles the read status of the selected message
E: Archive message :: Archives the message to the Archive folder
I: Move to Inbox :: Moves the selected message back to the Inbox
K: Flag message / Remove flag :: Toggles a follow-up flag on the selected message
Period (.): Mark as Junk :: Reports the selected message as junk and moves it
J: Mark as Not Junk :: Moves the message from Junk back to the Inbox
Cmd + Return: Send (when composing) :: Sends the message being composed
O or Return: Open message :: Opens the selected message in the reading pane or new window
N: Next message :: Moves focus to the next message below in the list
P: Previous message :: Moves focus to the previous message above in the list
]: Newer message :: Moves to a more recent message
[: Older message :: Moves to an older message

-- Composing --
>> Shortcuts available when writing or formatting a message in the compose window.
Cmd + Return: Send :: Sends the composed message
Cmd + B: Bold :: Toggles bold on selected text in the message body
Cmd + I: Italic :: Toggles italic on selected text in the message body
Cmd + U: Underline :: Toggles underline on selected text
Cmd + K: Insert hyperlink :: Opens the Insert Hyperlink dialog
Tab: Move to next field (To/Cc/Subject/Body) :: Advances focus through the message header fields

-- Calendar --
>> Navigating events and views in the Outlook web calendar.
Cmd + N: New event (in Calendar view) :: Opens a new event form
Cmd + Shift + A: New appointment (from anywhere) :: Opens a new event form from any module
T: Go to today :: Scrolls the calendar to today's date
D: Day view :: Switches to the single-day calendar view
W: Week view :: Switches to the full 7-day week view
X: Work week view :: Switches to the 5-day work week view
M: Month view :: Switches to the full month grid view
Left/Right: Previous / next time period :: Navigates forward or backward in the current view
"""
    }

    private static var GetOneNoteOnlineContent: () -> String = {
        return """
-- General --
>> File management and note-taking commands in OneNote Online.
Cmd + S: Save / Sync :: Forces a sync; OneNote Online saves changes automatically
Cmd + Z: Undo :: Reverses the last editing action
Cmd + Y: Redo :: Re-applies the last undone action
Cmd + F: Search current page :: Searches for text within the current page
Cmd + A: Select all :: Selects all content on the current page
Cmd + P: Print :: Prints the current OneNote page

-- Text Formatting --
>> Applying character formatting to selected text in the browser editor.
Cmd + B: Bold :: Toggles bold on selected text
Cmd + I: Italic :: Toggles italic on selected text
Cmd + U: Underline :: Toggles underline on selected text
Cmd + Shift + H: Highlight :: Highlights selected text in yellow
Cmd + K: Insert hyperlink :: Opens the Insert Link dialog
Cmd + Shift + >: Increase font size :: Grows the font to the next standard size
Cmd + Shift + <: Decrease font size :: Shrinks the font to the previous standard size

-- Lists & Structure --
>> Creating and indenting bulleted and numbered lists in the browser.
Return: New paragraph / list item :: Starts a new line or adds the next list item
Tab: Indent (increase level) :: Indents the current list item one level deeper
Shift + Tab: Outdent (decrease level) :: Outdents the current list item one level
Cmd + Shift + L: Bullet list :: Converts the selected text to a bulleted list
Cmd + Shift + O: Numbered list :: Converts the selected text to a numbered list

-- Navigation --
>> Moving between pages and positions within OneNote Online.
Cmd + ]: Go forward :: Navigates forward in the page history
Cmd + [: Go back :: Navigates back in the page history
Cmd + Home: Top of page :: Jumps to the beginning of the current page
Cmd + End: Bottom of page :: Jumps to the end of the current page
"""
    }

    private static var GetTeamsWebContent: () -> String = {
        return """
Note: Teams in a browser shares most shortcuts with the desktop app, but some browser-reserved combinations may conflict. If a shortcut does not work, try the equivalent from the Teams desktop guide or press Cmd + . to open Teams' built-in keyboard shortcut list.

-- General --
>> App-level commands and search in Microsoft Teams in a browser.
Cmd + /: Search or type a command :: Opens the command bar for searching or running commands
Cmd + E: Search :: Moves focus to the search bar
Cmd + . (period): Open keyboard shortcuts :: Shows the full keyboard shortcut reference inside Teams
Escape: Close / go back :: Dismisses the current panel or navigates back

-- Navigation --
>> Jumping between major sections of the Teams app.
Cmd + 1: Go to Activity :: Opens the Activity feed showing recent notifications
Cmd + 2: Go to Chat :: Opens the Chat section for direct messages
Cmd + 3: Go to Teams :: Opens the Teams and channels list
Cmd + 4: Go to Calendar :: Opens the Calendar and meetings view
Cmd + 5: Go to Calls :: Opens the Calls section (position may vary if you've reordered the app bar)
Cmd + 6: Go to Files :: Opens the Files section (position may vary if you've reordered the app bar)
Ctrl + Tab: Next recent item :: Cycles forward through recent chats, channels, and apps
Ctrl + Shift + Tab: Previous recent item :: Cycles backward through recent chats, channels, and apps
Cmd + N: Start a new chat :: Opens a new direct message to any contact

-- Messaging --
>> Composing and sending messages in Teams chats and channels.
Return: Send message (if Enter to send is on) :: Sends the message when the setting is enabled
Shift + Return: New line in message :: Inserts a line break without sending the message
Cmd + Return: Send message (always) :: Sends the message regardless of Enter-to-send setting
Cmd + F: Search within conversation :: Searches messages in the current chat or channel
Up arrow: Edit last message :: Opens your last sent message for editing when the compose box is empty
Cmd + Shift + X: Expand compose box :: Toggles the compose box to full-screen mode

-- Meetings & Calls --
>> Controls for managing audio, video, and screen sharing during a Teams meeting.
Cmd + Shift + M: Toggle mute / unmute :: Mutes or unmutes your microphone in the meeting
Cmd + Shift + Space: Push-to-talk :: Hold to temporarily unmute while muted
Cmd + Shift + O: Toggle camera on / off :: Turns your webcam on or off
Cmd + Shift + K: Raise / lower hand :: Toggles the raised hand indicator in the meeting
Cmd + Shift + E: Share screen :: Opens the screen sharing options
Cmd + Shift + P: Toggle background blur :: Turns background blur on or off
Cmd + Shift + B: Hang up / leave call :: Ends the current call
Cmd + Shift + A: Accept incoming video call :: Answers an incoming call with video
Cmd + Shift + S: Accept incoming audio call :: Answers an incoming call as audio-only
Cmd + Shift + D: Decline incoming call :: Rejects an incoming call

-- Channels & Teams --
>> Navigating the channel and team list in Teams.
Cmd + Shift + Up: Move team / channel up :: Moves the selected team or channel up in the sidebar
Cmd + Shift + Down: Move team / channel down :: Moves the selected team or channel down in the sidebar
"""
    }

    private static var GetOneDriveWebContent: () -> String = {
        return """
-- General --
>> App-level commands for OneDrive in a web browser.
?: Show keyboard shortcuts :: Displays the full keyboard shortcut reference for OneDrive
Cmd + F: Search files :: Moves focus to the search bar to find files and folders
Delete / Backspace: Delete selected item(s) :: Moves the selected files to the Recycle Bin
Return / Space: Open selected item :: Opens the focused file or folder
F2: Rename selected item :: Activates rename mode for the selected file (double-click on Mac)

-- Navigation --
>> Moving between files and folders in the OneDrive file browser.
Arrow keys: Navigate files :: Moves focus between file and folder items
Tab: Next item / area :: Moves focus to the next interactive element or area
Shift + Tab: Previous item / area :: Moves focus back to the previous element
Escape: Cancel current action :: Cancels an in-progress rename or selection
Page Up / Down: Scroll up / down :: Scrolls the file list up or down

-- Selecting Files --
>> Selecting single or multiple files for bulk operations.
Cmd + A: Select all files in current view :: Selects every item visible in the current folder
Shift + Click: Select range of files :: Selects all files between the first and last clicked
Cmd + Click: Add / remove item from selection :: Toggles a single item in or out of the selection
Escape: Deselect all :: Clears the current file selection

-- File Operations --
>> Moving, copying, and deleting files in OneDrive.
Cmd + C: Copy selected file link :: Copies a sharing link for the selected file to the clipboard
Cmd + V: Paste :: Uploads clipboard content to the current folder
Cmd + X: Cut (move) :: Cuts files for moving; paste in destination to complete the move
Delete: Move to Recycle Bin (Trash) :: Moves selected files to the OneDrive Recycle Bin
Return: Open file or folder :: Opens the selected item

-- Views --
>> Changing how files are displayed in OneDrive.
V: Switch view mode (list/tiles) :: Toggles between list view and tile/grid view
>> To upload files or folders, use the Upload button on the toolbar (no default keyboard shortcut), or drag-and-drop into the file list.
"""
    }

    private static var GetSharePointOnlineContent: () -> String = {
        return """
-- General --
>> App-level commands for navigating SharePoint Online in a browser.
?: Show keyboard shortcuts :: Displays available shortcuts (on most pages)
Cmd + F: Find on page :: Activates the browser's native find bar to search page text
Escape: Cancel action / close dialog :: Cancels the current operation or closes an open panel
Tab: Next control / link :: Moves focus to the next interactive element on the page
Shift + Tab: Previous control / link :: Moves focus to the previous interactive element

-- Document Library Navigation --
>> Navigating and opening files in a SharePoint document library.
Arrow keys: Navigate between items :: Moves focus between files and folders in the list
Return / Space: Open selected file or folder :: Opens the focused item
Delete / Backspace: Delete selected item :: Moves selected item to Recycle Bin if permissions allow
F2 or double-click: Rename item (in list view) :: Activates inline rename for the focused item

-- Selecting Items --
>> Selecting files in SharePoint document libraries for bulk actions.
Cmd + A: Select all items (in list view) :: Selects every item visible in the current view
Shift + Click: Select range :: Selects a contiguous range of items
Cmd + Click: Add to selection :: Adds a single item to the current selection
Space: Select / deselect item (checkbox column) :: Toggles the selection checkbox for the focused item

-- List Views --
>> Editing items inline in SharePoint list view mode.
Tab: Navigate across cells in list view :: Moves focus between editable fields in a list row
Escape: Cancel edit in list view :: Discards the current inline edit without saving
Return: Confirm edit in list view :: Saves the current inline edit and exits edit mode
Cmd + Z: Undo last edit (list views) :: Reverses the most recent inline list edit

-- Page Editing (Modern Pages) --
>> Shortcuts for editing SharePoint modern pages with web parts.
/ (slash): Open web part picker when editing :: Displays the web part search and insert panel
Escape: Exit web part edit mode :: Deselects the current web part without deleting it
Cmd + S: Save page draft :: Saves the current state of the page as a draft

-- Quick Launch Navigation --
>> Moving through the SharePoint site navigation menu.
Tab: Navigate menu items :: Moves focus through the left-side navigation links
Return: Open menu item :: Activates the focused navigation link and loads the page
"""
    }

    private static var GetGoogleDocsContent: () -> String = {
        return """
-- General --
>> File management and universal editing commands for Google Docs.
Cmd + N: New document :: Opens a new blank document in a new browser tab
Cmd + O: Open document :: Opens the Google Drive file picker
Cmd + S: Save (auto-saves, forces sync) :: Triggers a manual save; Docs saves automatically
Cmd + P: Print :: Opens the print dialog for the current document
Cmd + Z: Undo :: Reverses the last editing action
Cmd + Y: Redo :: Re-applies the last undone action
Cmd + A: Select all :: Selects all content in the document
Cmd + F: Find :: Opens the Find toolbar to search document text
Cmd + H: Find and Replace :: Opens the Find and Replace dialog
Cmd + /: Show keyboard shortcuts :: Displays the full shortcut reference for Google Docs

-- Text Formatting --
>> Applying character-level styles to selected text in the document.
Cmd + B: Bold :: Toggles bold weight on selected text
Cmd + I: Italic :: Toggles italic style on selected text
Cmd + U: Underline :: Toggles single underline on selected text
Cmd + Shift + S: Strikethrough :: Draws a line through the selected text
Cmd + \\: Clear formatting :: Removes all manual formatting from selected text
Cmd + .: Superscript :: Formats selected text as superscript (e.g. x²)
Cmd + ,: Subscript :: Formats selected text as subscript (e.g. H₂O)
Cmd + Shift + >: Increase font size :: Grows the font to the next standard size
Cmd + Shift + <: Decrease font size :: Shrinks the font to the previous standard size

-- Paragraph & Lists --
>> Formatting paragraph alignment, list styles, and heading levels.
Cmd + L: Left align :: Left-aligns the current paragraph
Cmd + E: Center :: Centers the current paragraph
Cmd + R: Right align :: Right-aligns the current paragraph
Cmd + Shift + J: Justify :: Justifies both sides of the current paragraph
Cmd + Shift + 7: Numbered list :: Applies a numbered list to current or selected paragraphs
Cmd + Shift + 8: Bulleted list :: Applies a bulleted list to current or selected paragraphs
Cmd + Shift + 9: Checklist :: Creates a checklist with interactive checkboxes
Tab: Increase indent :: Indents the current list item one level deeper
Shift + Tab: Decrease indent :: Outdents the current list item one level
Cmd + Alt + 0: Normal paragraph style :: Applies the Normal body text style
Cmd + Alt + 1–6: Heading styles 1–6 :: Applies heading level 1 through 6

-- Navigation --
>> Moving the cursor and jumping to positions within the document.
Cmd + Home (fn+Cmd+Left): Top of document :: Moves cursor to the very beginning
Cmd + End (fn+Cmd+Right): Bottom of document :: Moves cursor to the very end
Option + Left/Right: Word by word :: Moves the cursor one word at a time
Cmd + Left/Right: Beginning / end of line :: Jumps to the start or end of the current line
Cmd + G: Find next :: Finds the next occurrence of the current search term
Cmd + Shift + G: Find previous :: Finds the previous occurrence of the search term

-- Comments & Collaboration --
>> Adding and navigating comments and suggestions with collaborators.
Cmd + Option + M: Add comment :: Opens the comment dialog for the selected text
Cmd + Option + Shift + A: Open comment thread :: Opens the comments panel to view all threads
Cmd + Enter: Submit comment :: Submits the typed comment to the thread
Escape: Close comment :: Closes the comment dialog without saving

-- Editing --
>> Cut, copy, paste, and hyperlink shortcuts for editing document content.
Cmd + X: Cut :: Removes the selection and places it on the clipboard
Cmd + C: Copy :: Copies the selection to the clipboard
Cmd + V: Paste :: Inserts clipboard content at the cursor
Cmd + Shift + V: Paste without formatting :: Pastes text only, without any styles
Cmd + K: Insert link :: Opens the Insert Link dialog for adding a hyperlink
Cmd + Option + K: Insert / edit link :: Opens the link edit dialog for selected text

-- VoiceOver & Accessibility (Google Docs) --
>> Enable screen reader support: Tools menu → Accessibility → check "Turn on screen reader support".
>> This enables ARIA live regions so VoiceOver announces formatting changes and editor state.
>> Without enabling accessibility mode, VoiceOver may miss important feedback in the editor.
Cmd + /: Open shortcut help :: Keyboard-accessible reference — use to discover more Docs shortcuts
Cmd + Option + M: Add comment :: Comments are read by VoiceOver when focus enters the comment
VO + U: Open Web Rotor in Safari :: Navigate by headings, links, or form fields within the Docs page
H (Quick Nav on): Next heading :: Jumps to headings set with Cmd+Option+1–6 for document navigation
>> Use Cmd+Option+1–6 to create heading structure — VoiceOver users navigate documents by heading level.
>> The document title and heading structure appear in the Web Rotor (VO+U) Headings list.
>> In Chrome, Docs works well with VoiceOver in "Browse" mode; press VO+Shift+F5 to enter the editor.
>> Use Cmd+F to search within the document; results are announced by VoiceOver.
>> Comments, suggestions, and revision history are accessible via the menus (Insert, Tools).
"""
    }

    private static var GetGoogleSheetsContent: () -> String = {
        return """
-- General --
>> File and app-level commands for managing Google Sheets spreadsheets.
Cmd + N: New spreadsheet :: Opens a new blank spreadsheet in a new browser tab
Cmd + O: Open spreadsheet :: Opens the Google Drive file picker
Cmd + S: Save / sync :: Forces a manual save; Sheets auto-saves continuously
Cmd + P: Print :: Opens the print settings for the current sheet
Cmd + Z: Undo :: Reverses the last action
Cmd + Y: Redo :: Re-applies the last undone action
Cmd + F: Find :: Opens the Find toolbar to search cell content
Cmd + H: Find and Replace :: Opens the Find and Replace dialog
Cmd + /: Keyboard shortcuts :: Displays the full shortcut reference

-- Navigation --
>> Moving the active cell around the spreadsheet.
Arrow keys: Move one cell :: Moves the active cell one step in any direction
Tab: Move right :: Moves to the next cell on the right; confirms entry
Shift + Tab: Move left :: Moves to the previous cell on the left
Return: Move down / confirm :: Confirms entry and moves the active cell down
Escape: Cancel entry :: Discards changes to the current cell
Cmd + Home: Go to A1 :: Jumps to cell A1 at the top-left of the sheet
Cmd + End: Last used cell :: Jumps to the last cell containing data
Cmd + Arrow: Jump to edge of data :: Jumps to the last non-empty cell in that direction
Cmd + Backspace: Scroll to show active cell :: Scrolls the view to make the active cell visible

-- Selecting --
>> Extending the selection to cover multiple cells, rows, or columns.
Shift + Arrow: Extend selection :: Adds one cell at a time to the current selection
Cmd + Shift + Arrow: Extend to end of data :: Extends selection to the edge of the data block
Shift + Space: Select row :: Selects the entire row of the active cell
Cmd + Space: Select column :: Selects the entire column of the active cell
Cmd + A: Select all :: Selects all cells in the spreadsheet

-- Editing --
>> Entering and modifying data within cells.
F2 (or Return): Edit cell :: Puts the active cell into edit mode
Delete / Backspace: Clear cell :: Clears the content of selected cells
Cmd + D: Fill down :: Copies the top cell's value down to selected cells below
Cmd + R: Fill right :: Copies the leftmost cell to selected cells on the right
Cmd + ;: Insert date :: Inserts today's date into the active cell
Cmd + Shift + ;: Insert time :: Inserts the current time into the active cell
Option + Return: New line in cell :: Inserts a line break inside the cell
Cmd + `: Show / hide formulas :: Toggles between showing values and formula text

-- Formatting --
>> Applying number formats and text styles to cells.
Cmd + B: Bold :: Toggles bold formatting on selected cells
Cmd + I: Italic :: Toggles italic formatting on selected cells
Cmd + U: Underline :: Toggles underline formatting on selected cells
Cmd + Shift + S: Strikethrough :: Draws a line through text in selected cells
Cmd + \\: Clear formatting :: Removes all manual formatting from selected cells
Cmd + Shift + $: Currency format :: Applies currency number format
Cmd + Shift + %: Percent format :: Converts values to percentage display
Cmd + Shift + #: Date format :: Applies the standard short date format
Cmd + Shift + @: Time format :: Applies the standard time format
Cmd + Shift + !: Number format (2 decimals) :: Applies comma-separated number format

-- Rows, Columns & Sheets --
>> Managing sheet structure and navigating between worksheet tabs.
Cmd + Shift + +: Insert rows / columns :: Inserts a row or column at the selection
Cmd + -: Delete rows / columns :: Removes selected rows or columns
Cmd + Option + M: Insert comment :: Adds a comment to the active cell
Option + Up: Previous sheet :: Moves to the sheet tab to the left
Option + Down: Next sheet :: Moves to the sheet tab to the right
Option + Shift + K: List all sheets :: Opens a popup listing every sheet tab
Cmd + Shift + Page Down: Next sheet :: Navigates to the next sheet (alternate)
Cmd + Shift + Page Up: Previous sheet :: Navigates to the previous sheet (alternate)
"""
    }

    private static var GetGoogleSlidesContent: () -> String = {
        return """
-- General --
>> File and app-level commands for Google Slides presentations.
Cmd + N: New presentation :: Opens a new blank presentation in a new tab
Cmd + O: Open presentation :: Opens the Google Drive file picker
Cmd + S: Save :: Forces a manual save; Slides auto-saves continuously
Cmd + P: Print :: Opens print settings for the presentation
Cmd + Z: Undo :: Reverses the last action
Cmd + Y: Redo :: Re-applies the last undone action
Cmd + /: Keyboard shortcuts :: Displays the full shortcut reference

-- Editing Slides --
>> Adding, duplicating, and managing slides and objects in Normal view.
Cmd + D: Duplicate slide :: Creates an exact copy of the selected slide
Cmd + M: New slide :: Inserts a new slide after the current one
Delete: Delete selected slide or object :: Removes the selected item
Cmd + A: Select all objects :: Selects every object on the current slide
Tab: Next object on slide :: Moves focus to the next object in tab order
Shift + Tab: Previous object on slide :: Moves focus to the previous object
Return: Edit text in selected object :: Enters text editing mode inside the selected shape
Escape: Deselect / exit text edit :: Exits text editing or deselects the current object

-- Text Formatting --
>> Applying character and paragraph styles inside text boxes.
Cmd + B: Bold :: Toggles bold on selected text
Cmd + I: Italic :: Toggles italic on selected text
Cmd + U: Underline :: Toggles underline on selected text
Cmd + Shift + S: Strikethrough :: Draws a line through the selected text
Cmd + \\: Clear formatting :: Removes all manual character formatting
Cmd + Shift + >: Increase font size :: Grows the font to the next standard size
Cmd + Shift + <: Decrease font size :: Shrinks the font to the previous standard size
Cmd + E: Center :: Centers the paragraph in the text box
Cmd + L: Left align :: Left-aligns the paragraph
Cmd + R: Right align :: Right-aligns the paragraph
Cmd + Shift + J: Justify :: Justifies both sides of the paragraph

-- Slide Navigation --
>> Moving between slides in the slide panel and Normal view.
Page Up / Down: Previous / next slide :: Navigates through slides in Normal view
Home (fn + Left): First slide :: Jumps to the first slide in the presentation
End (fn + Right): Last slide :: Jumps to the last slide in the presentation
Arrow keys (slide panel): Navigate slide list :: Moves focus through the slide thumbnail panel

-- Present Mode --
>> Controls for running the presentation in full-screen Present mode.
Cmd + Shift + Return: Start presentation from beginning :: Launches the full-screen presentation
Cmd + Return: Start presentation from current slide :: Begins presenting from the selected slide
(when presenting): Arrow keys or N/P: Next/prev slide :: Advances or goes back one slide or animation
(when presenting): Escape: Exit presentation :: Exits Present mode and returns to the editor
(when presenting): B: Black screen :: Momentarily blacks out the display during presentation

-- Objects --
>> Grouping, arranging, and nudging objects on slides.
Cmd + G: Group objects :: Combines selected objects into a single group
Cmd + Shift + G: Ungroup :: Breaks the selected group into individual objects
Cmd + Option + G: Regroup :: Re-applies the last grouping operation
Option + Arrow: Nudge object :: Moves the selected object in small increments
"""
    }

    private static var GetGmailContent: () -> String = {
        return """
-- Navigation --
>> Jumping between Gmail mailboxes and views using keyboard shortcuts.
>> Enable keyboard shortcuts in Gmail Settings > General > Keyboard Shortcuts first.
G then I: Go to Inbox :: Navigates to the primary Inbox mailbox
G then S: Go to Starred :: Navigates to messages you have starred
G then T: Go to Sent :: Navigates to the Sent mail folder
G then D: Go to Drafts :: Navigates to the Drafts folder
G then A: Go to All Mail :: Shows all messages regardless of label
G then C: Go to Contacts :: Opens the Google Contacts page
? (Shift + /): Show keyboard shortcuts help :: Displays the full Gmail shortcut reference

-- Mail List --
>> Navigating and selecting conversations in the inbox list.
J: Older conversation / next email :: Moves focus down to the older conversation below
K: Newer conversation / previous email :: Moves focus up to the newer conversation above
O or Return: Open conversation :: Opens the focused conversation to read messages
U: Return to inbox / conversation list :: Goes back to the message list from an open email
X: Select conversation (checkbox) :: Toggles the selection checkbox for the focused conversation
* then A: Select all conversations :: Selects all conversations currently visible
* then N: Deselect all :: Clears all selected conversations
* then U: Select unread :: Selects all unread conversations
* then S: Select starred :: Selects all starred conversations

-- Actions on Messages --
>> Acting on selected or open messages: archive, delete, label, flag.
E: Archive :: Archives the selected message(s) to remove from Inbox
Delete / Backspace: Delete :: Moves selected message(s) to Trash
Shift + I: Mark as Read :: Marks the selected conversation as read
Shift + U: Mark as Unread :: Marks the selected conversation as unread
L: Apply / remove label :: Opens the label picker to tag the message
R: Reply :: Opens an inline reply to the sender
A: Reply All :: Opens a reply addressed to all recipients
F: Forward :: Forwards the message to a new recipient
Shift + F: Forward as attachment :: Attaches the message as an .eml file and forwards it
.: More actions menu :: Opens the overflow actions menu for the selected message
S: Star / unstar :: Toggles the star on the selected conversation
I: Mark as important :: Toggles the important marker on the message
!: Mark as spam :: Reports the message as spam and removes it from Inbox
Z: Undo last action :: Reverses the most recent action (archive, delete, etc.)

-- Composing --
>> Shortcuts for starting, formatting, and sending new email messages.
C: Compose new email :: Opens the compose window at the bottom of the screen
Shift + C: Compose in new window :: Opens the compose window as a full separate window
D: Compose in new tab :: Opens the compose window in its own browser tab
Cmd + Return: Send message :: Sends the composed message immediately
Cmd + Shift + C: Add Cc recipients :: Moves focus to the Cc field in the compose window
Cmd + Shift + B: Add Bcc recipients :: Moves focus to the Bcc field (hidden recipients)
Cmd + Shift + F: Access From field :: Moves focus to the From field for sender selection
Cmd + K: Insert link :: Opens the Insert Link dialog in the compose body
Cmd + Z: Undo :: Reverses the last compose action
Tab then Return: Send (move focus to Send button) :: Moves focus to Send, then Return sends
"""
    }

    private static var GetGoogleMeetContent: () -> String = {
        return """
-- During a Meeting --
>> Core audio and video controls during a Google Meet call.
Cmd + D: Mute / unmute microphone :: Toggles your microphone on or off during the call
Cmd + E: Turn camera on / off :: Toggles your webcam on or off during the call
Ctrl + Cmd + H: Raise / lower hand :: Toggles the raised hand reaction
Shift + ?: Show keyboard shortcuts :: Displays the full shortcut reference during a meeting

-- Panels & Participants --
>> Opening side panels for people, chat, and activities.
Ctrl + Cmd + P: Show / hide participants panel :: Opens or closes the People panel
Ctrl + Cmd + C: Show / hide in-call messages (chat) :: Toggles the in-meeting chat panel
Ctrl + Cmd + A: Show / hide activities panel :: Opens or closes the Activities panel (host tools)

-- Captions & Video --
>> Captions, gestures, and visual effects.
Shift + C: Turn captions on / off :: Toggles live auto-captions in the meeting
Shift + M: Picture-in-picture :: Pops the meeting into a small floating window
Shift + 1–6 (number row): Reactions :: Sends an emoji reaction (varies by reaction layout)

-- Presenting / Screen Share --
>> Starting and stopping a presentation.
Ctrl + Cmd + E: Present now / stop presenting :: Starts or stops a screen share (select what to share in the dialog)

-- Chat --
>> Sending messages in the in-meeting chat panel.
Return: Send chat message (when in chat) :: Sends the typed message to all participants
Shift + Return: New line in chat :: Inserts a line break without sending

-- Accessibility --
>> Keyboard navigation for the meeting grid.
Ctrl + Option + Arrow: Navigate meeting grid :: Moves focus through participant video tiles
Ctrl + Option + Space: Select participant tile :: Activates the focused participant's tile
"""
    }

    private static var GetFinderContent: () -> String = {
        return """
-- Navigation --
>> Opening windows, tabs, and navigating to folder locations in Finder.
Cmd + N: New Finder window :: Opens a new Finder window at the default location
Cmd + T: New tab :: Opens a new tab in the current Finder window
Cmd + W: Close window / tab :: Closes the current window or tab
Cmd + Shift + N: New folder :: Creates a new untitled folder in the current location
Cmd + Option + N: New Smart Folder :: Creates a Smart Folder with search criteria
Cmd + Up: Go to parent folder (enclosing folder) :: Navigates up to the containing folder
Cmd + Down: Open selected folder or file :: Opens the selected item
Cmd + [: Go back :: Navigates to the previous folder in the history
Cmd + ]: Go forward :: Navigates forward in the folder history
Cmd + Shift + A: Go to Applications :: Jumps directly to the Applications folder
Cmd + Shift + D: Go to Desktop :: Jumps to the Desktop folder
Cmd + Shift + F: Go to Recent Files :: Opens the Recents view
Cmd + Shift + H: Go to Home folder :: Jumps to your user Home folder
Cmd + Shift + I: Go to iCloud Drive :: Opens the iCloud Drive folder
Cmd + Shift + K: Go to Network :: Opens the Network browser
Cmd + Shift + O: Go to Documents :: Jumps to your Documents folder
Cmd + Shift + R: Go to AirDrop :: Opens the AirDrop sharing window
Cmd + Shift + U: Go to Utilities :: Navigates to the Utilities folder inside Applications
Cmd + G: Go to Folder dialog :: Opens a dialog to type any folder path directly
Cmd + F: Find / Search :: Opens the search bar for a Spotlight-powered search

-- Selecting & Opening --
>> Selecting, previewing, and opening files in Finder.
Return: Rename selected item :: Enters rename mode for the focused file or folder
Cmd + Down: Open selected item :: Opens the file with the default application
Space: Quick Look preview :: Instantly previews the selected file without opening an app
Cmd + O: Open with default app :: Same as double-clicking; opens with the associated app
Cmd + Option + O: Open and close window :: Opens the item and closes the current Finder window
Arrow keys: Navigate files :: Moves focus between items in the current view
Cmd + A: Select All :: Selects every item in the current folder
Cmd + Click: Add item to selection :: Adds a single file to the current selection
Shift + Click: Select range :: Selects all files between the clicked items

-- File Operations --
>> Copying, moving, duplicating, and deleting files and folders.
Cmd + C: Copy :: Copies the selected item(s) to the clipboard
Cmd + X: Cut (move — paste with Cmd+V) :: Marks items to be moved; Cmd+V completes the move
Cmd + V: Paste (move or copy) :: Pastes or moves the clipboard items to the current folder
Cmd + Option + V: Move (paste as move) :: Moves items from the clipboard without duplicating
Cmd + D: Duplicate :: Creates a copy of the selected item in the same folder
Cmd + Delete: Move to Trash :: Moves selected items to the Trash
Cmd + Shift + Delete: Empty Trash :: Permanently deletes all items in the Trash
Cmd + I: Get Info (file properties) :: Opens the Info panel showing file details and permissions
Cmd + R: Show original (of alias) :: Reveals the original file that an alias points to
Cmd + L: Make alias :: Creates an alias shortcut pointing to the selected item
Option + drag: Copy file to new location :: Holds Option while dragging to copy instead of move
Cmd + drag: Move file :: Holds Cmd while dragging to move a file to a new location

-- Views --
>> Switching Finder display modes and showing or hiding interface elements.
Cmd + 1: Icon view :: Displays items as large icons in a grid
Cmd + 2: List view :: Displays items in a sortable list with details
Cmd + 3: Column view :: Shows the folder hierarchy across multiple columns
Cmd + 4: Gallery view (macOS Mojave+) :: Shows a large preview with a thumbnail strip
Cmd + J: View options :: Opens the view options panel for the current view
Cmd + Option + T: Show / hide toolbar :: Toggles the Finder toolbar and sidebar
Cmd + Option + S: Show / hide sidebar :: Toggles the sidebar panel on the left
Cmd + Option + P: Show / hide Path bar :: Toggles the path bar at the bottom of the window
Cmd + /: Show / hide Status bar :: Toggles the status bar showing item count and disk space
Cmd + Shift + P: Show / hide Preview pane :: Toggles the file preview panel on the right

-- VoiceOver Tips (Finder) --
>> Column view (Cmd+3) is strongly recommended when using Finder with VoiceOver — it provides the clearest file hierarchy navigation.
Cmd + 3: Column view :: Best view for VoiceOver — each column represents a folder level
VO + Shift + Down: Interact with file list :: Enters the file list so VoiceOver can navigate individual items
VO + Shift + Up: Stop interacting :: Returns to the Finder window level from inside a file list
VO + Right / Left: Navigate files in current column :: Moves the VoiceOver cursor between files and folders
VO + Spacebar: Select or activate item :: Selects the focused file or opens a focused folder
VO + Cmd + Down: Open selected item :: Opens a folder or launches a file
Cmd + Down: Open selected item (standard shortcut) :: Opens the focused item with the default application
Space: Quick Look preview :: Announces and shows file details without opening the file — VoiceOver reads the preview
Return: Begin renaming selected file :: Puts the filename into edit mode; press Return again to confirm
VO + Right (in sidebar): Navigate sidebar items :: Moves through Favorites, iCloud, Locations in the sidebar
Tab: Move between Finder panels :: Cycles between the toolbar, sidebar, file list, and preview pane
VO + F2: Announce window :: Speaks the current Finder window title and location
"""
    }

    private static var GetSafariContent: () -> String = {
        return """
-- General --
>> Core browser commands for opening, searching, and controlling Safari.
Cmd + N: New window :: Opens a new Safari browser window
Cmd + T: New tab :: Opens a new tab in the current window
Cmd + W: Close tab :: Closes the current tab
Cmd + Shift + W: Close window :: Closes the entire Safari window with all its tabs
Cmd + Q: Quit Safari :: Quits Safari and closes all windows
Cmd + L: Select address bar (open location) :: Highlights the URL bar for typing a new address
Cmd + R: Reload page :: Reloads the current page from the server
Cmd + Shift + R: Reload without cache (hard reload) :: Forces a full reload bypassing cached content
Escape: Stop loading :: Cancels a page that is currently loading
Cmd + F: Find on page :: Opens the in-page search bar to find text
Cmd + G: Find next :: Jumps to the next occurrence of the search term
Cmd + Shift + G: Find previous :: Jumps to the previous occurrence of the search term
Cmd + +: Zoom in :: Increases the page text and content size
Cmd + -: Zoom out :: Decreases the page text and content size
Cmd + 0: Actual size :: Resets the zoom to 100% default size

-- Tabs & Windows --
>> Managing multiple tabs and windows in Safari.
Cmd + T: New tab :: Opens a fresh tab to the start page
Cmd + W: Close current tab :: Closes the active tab
Cmd + Shift + T: Reopen last closed tab :: Reopens the most recently closed tab
Cmd + Option + Left: Previous tab :: Moves to the tab immediately to the left
Cmd + Option + Right: Next tab :: Moves to the tab immediately to the right
Cmd + 1–9: Switch to specific tab :: Activates the tab at that position number
Cmd + Shift + [: Previous tab (alternate) :: Moves to the previous tab
Cmd + Shift + ]: Next tab (alternate) :: Moves to the next tab
Cmd + Shift + \\: Show all tabs (Tab Overview) :: Opens the Tab Overview grid of all open tabs
Cmd + M: Minimize window :: Minimises the Safari window to the Dock

-- Navigation --
>> Moving backward/forward through page history and scrolling.
Cmd + [: Go back :: Returns to the previous page in the tab's history
Cmd + ]: Go forward :: Goes forward to the next page in the tab's history
Space: Scroll down one page :: Scrolls the page down by one visible screen
Shift + Space: Scroll up one page :: Scrolls the page up by one visible screen
Cmd + Up: Go to top of page :: Jumps to the very top of the current page
Cmd + Down: Go to bottom of page :: Jumps to the very bottom of the current page
Cmd + Home (fn+Left): Top of page :: Alternative shortcut to jump to the top
Cmd + End (fn+Right): Bottom of page :: Alternative shortcut to jump to the bottom
Tab: Highlight next interactive element :: Moves keyboard focus to the next link or form field

-- Reading & Bookmarks --
>> Saving pages and managing bookmarks and the reading list.
Cmd + D: Add bookmark :: Saves the current page to your bookmarks
Cmd + Shift + D: Add to Reading List :: Saves the page to your Safari Reading List for later
Cmd + Option + L: Open Reading List sidebar :: Shows or hides the Reading List panel
Cmd + Option + B: Open Bookmarks sidebar :: Shows or hides the Bookmarks panel
Cmd + Shift + B: Show/hide Bookmarks Bar :: Toggles the bookmarks toolbar under the address bar
Cmd + Option + R: Show/hide Reader View :: Toggles the distraction-free Reader article view
Cmd + Option + F: Move focus to search field :: Focuses the address bar for searching or navigation

-- Privacy & Dev --
>> Private browsing and developer tools in Safari.
Cmd + Shift + N: New Private window :: Opens a new Private Browsing window without saving history
Cmd + Option + I: Open Web Inspector (dev tools) :: Opens the Safari developer tools panel
Cmd + Option + C: Open Console :: Shows the JavaScript console in the developer tools
Cmd + Option + A: Open Resources panel :: Opens the Resources/Network panel in developer tools

-- VoiceOver Tips (Safari) --
>> Safari provides the richest VoiceOver web experience on macOS. These commands work with VoiceOver active.
Cmd + F5: Toggle VoiceOver :: Turn VoiceOver on or off before browsing
VO + U: Open Web Rotor :: Arrow left/right to choose type (Headings, Links, Form Controls, Landmarks, Tables); arrow up/down to navigate items; Return to jump
Left + Right arrows (simultaneously): Toggle Quick Nav :: Enables single-key web navigation — no VO modifier needed
H (Quick Nav on): Next heading :: Press H alone to jump heading by heading through the page
L (Quick Nav on): Next link :: Press L alone to jump link by link
F (Quick Nav on): Next form field :: Press F alone to jump to form inputs and buttons
T (Quick Nav on): Next table :: Press T alone to jump to tables
B (Quick Nav on): Next button :: Press B alone to jump between buttons
VO + Cmd + H: Next heading (without Quick Nav) :: Standard VO heading jump with modifier
VO + Cmd + L: Next link (without Quick Nav) :: Standard VO link jump with modifier
VO + Cmd + F: Next form control :: Jump to next text field or interactive control
VO + Shift + Down: Interact with web area :: Enter the webpage content area so VO can navigate inside it
VO + A: Read page continuously :: Reads the entire page from the current position
Cmd + Option + R: Enter Reader View :: Strips ads and menus for a clean reading experience — highly recommended with VoiceOver
Tab: Move between links and controls :: Standard Tab still works for interactive elements regardless of Quick Nav
VO + Spacebar: Activate link or button :: Clicks the currently focused link, button, or control
"""
    }

    private static var GetMailContent: () -> String = {
        return """
-- General --
>> Reading, managing, and responding to email in Apple Mail.
Cmd + N: New message :: Opens a new blank email compose window
Cmd + Shift + N: Get new mail :: Triggers a manual mail fetch from all accounts
Cmd + R: Reply :: Opens a reply addressed to the sender only
Cmd + Shift + R: Reply All :: Opens a reply addressed to all recipients
Cmd + Shift + F: Forward message :: Forwards the selected message to a new recipient
Cmd + Delete: Move to Trash :: Moves the selected message to the Trash mailbox
Cmd + Shift + U: Mark as Read / Unread :: Toggles the read status of the selected message
Cmd + F: Search mailboxes :: Focuses the search bar to search all mailboxes
Cmd + Option + F: Find in message :: Searches for text within the currently open message
Cmd + Shift + L: Flag message :: Adds or removes a flag on the selected message

-- Composing --
>> Writing, formatting, and sending email messages in the compose window.
Cmd + Return: Send message :: Sends the composed message immediately
Cmd + Shift + S: Save draft :: Saves the current message as a draft to continue later
Cmd + A: Select all text :: Selects all text in the current message field
Cmd + B: Bold :: Toggles bold on selected text in the message body
Cmd + I: Italic :: Toggles italic on selected text in the message body
Cmd + U: Underline :: Toggles underline on selected text
Cmd + K: Insert link :: Opens the Insert Link dialog in the message body
Tab: Move to next header field (To/Cc/Subject) :: Advances focus through the address and subject fields

-- Navigation --
>> Moving between mailboxes and messages in the Mail sidebar and list.
Cmd + 1: Inbox :: Switches view to the Inbox (all inboxes)
Cmd + 2: Sent :: Switches to the Sent mailbox
Cmd + 3: Drafts :: Switches to the Drafts mailbox
Cmd + 4: All Inboxes :: Shows the unified inbox with messages from all accounts
Cmd + [: Go back :: Navigates back in the mailbox view history
Cmd + ]: Go forward :: Navigates forward in the mailbox view history
Up / Down arrow: Previous / next message :: Moves focus to the message above or below
Return: Open selected message :: Opens the focused message for reading
Spacebar: Scroll message / mark read :: Scrolls the message body and marks it as read

-- Mailbox Management --
>> Organising and maintaining mailboxes and messages.
Cmd + Shift + M: Move selected messages to folder :: Opens the move-to-folder dialog
Cmd + Option + F: Filter messages :: Opens the filter options to narrow the message list
Cmd + Shift + Delete: Erase Deleted Messages :: Permanently deletes messages in Trash
Cmd + Shift + J: Mark as Junk :: Marks the selected message as junk and moves it
Cmd + Shift + O: Open message in separate window :: Opens the focused message in its own window
Cmd + Option + J: Move junk mail to Junk :: Marks the selected message as junk mail
Cmd + Shift + N: Get new mail from all accounts :: Manually fetches mail from every configured account

-- VoiceOver Tips (Mail) --
>> Mail works well with VoiceOver. Use the following patterns for efficient accessible email.
VO + Shift + Down: Enter the message list :: Interacts with the message list to navigate individual emails
VO + Right / Left: Move between messages in list :: Navigates up and down through the message list
VO + Spacebar: Open or select focused message :: Activates the highlighted message
VO + Shift + Up: Exit the message list :: Returns to the Finder/toolbar level from the message list
VO + A: Read current message :: Reads the entire message body from top to bottom when the reading pane is focused
Tab: Jump to next panel (toolbar / sidebar / list / reading pane) :: Cycles focus between Mail's main areas
VO + Cmd + H: Next heading in HTML email :: Jumps to the next heading in a rich-text email message
VO + Cmd + L: Next link in email :: Jumps to the next hyperlink in a rich-text email message
VO + F2: Announce current window :: Speaks which mailbox or view is currently active
Cmd + Shift + N: Get new mail :: Triggers a mail fetch — useful when checking if new mail has arrived
"""
    }

    private static var GetCalendarContent: () -> String = {
        return """
-- Navigation --
>> Moving between dates and time periods in Calendar views.
Cmd + N: New event :: Creates a new event in the current view
Cmd + T: Go to Today :: Scrolls or jumps the view to today's date
Cmd + 1: Day view :: Switches to the single-day view
Cmd + 2: Week view :: Switches to the 7-day week view
Cmd + 3: Month view :: Switches to the full month grid view
Cmd + 4: Year view (macOS) :: Switches to the year overview (macOS Calendar)
Left arrow: Previous day / week / month :: Goes back one period in the current view
Right arrow: Next day / week / month :: Goes forward one period in the current view
Cmd + Left: Previous week / month :: Jumps back by a larger time increment
Cmd + Right: Next week / month :: Jumps forward by a larger time increment
Cmd + F: Search calendars :: Opens the search bar to find events by keyword

-- Events --
>> Creating, editing, and managing calendar events.
Return: Open selected event :: Opens the focused event details popup
Delete: Delete selected event :: Removes the selected event from the calendar
Cmd + E: Edit selected event :: Opens the event for full editing
Cmd + I: Event Info (Inspector) :: Opens the event information panel
Escape: Cancel editing event :: Discards unsaved changes to an event being edited

-- Views & Display --
>> Customising how Calendar looks and what is shown on screen.
Cmd + Option + S: Show/hide Calendars sidebar :: Toggles the calendar list panel on the left
Cmd + Option + M: Show/hide mini calendar :: Toggles the small month navigator
Cmd + R: Refresh calendars :: Syncs all calendars with their servers
Cmd + ,  (comma): Calendar preferences :: Opens the Calendar preferences window

-- VoiceOver Tips (Calendar) --
>> Calendar's layout is straightforward for VoiceOver. These patterns help navigate efficiently.
Tab: Move between Calendar's main areas :: Cycles focus between the sidebar, mini calendar, and main calendar grid
VO + Shift + Down: Enter the calendar grid :: Interacts with the day/week/month grid to navigate individual events
VO + Right / Left: Move between days or events :: Navigates through dates and events within the calendar view
VO + Spacebar: Open focused event :: Activates the focused event to show details
VO + F2: Announce current view :: Speaks which calendar view (Day, Week, Month) is currently active
>> Day view (Cmd+1) is easiest for VoiceOver — events appear as a list in time order.
>> Use Cmd+T to jump to today, then Tab into the event list to hear today's schedule.
"""
    }

    private static var GetNotesContent: () -> String = {
        return """
-- General --
>> Creating, searching, and managing notes in the Apple Notes app.
Cmd + N: New note :: Creates a new blank note in the currently selected folder
Cmd + Shift + N: New note in a folder :: Creates a new note and prompts for a folder
Cmd + F: Search notes :: Opens the search bar to find notes by text
Cmd + Delete: Delete selected note :: Moves the selected note to Recently Deleted
Cmd + R: Show / hide recent notes :: Toggles the Recents smart folder in the sidebar
Cmd + S: Save :: Triggers a save; Notes auto-saves but this commits formatting

-- Editing --
>> Formatting text, creating lists, and inserting content into a note.
Cmd + B: Bold :: Toggles bold on selected text
Cmd + I: Italic :: Toggles italic on selected text
Cmd + U: Underline :: Toggles underline on selected text
Cmd + K: Add link :: Opens the Add Link dialog to insert a hyperlink
Cmd + Shift + T: Title style :: Applies the Title paragraph style to the current line
Cmd + Shift + H: Heading style :: Applies the Heading paragraph style
Cmd + Shift + J: Subheading style :: Applies the Subheading paragraph style
Cmd + Shift + B: Body style :: Applies the default Body text style
Cmd + Shift + M: Monospaced :: Applies monospaced character style to selected text
Cmd + Shift + 7: Bulleted list :: Converts the current or selected lines to a bulleted list
Cmd + Shift + 8: Dashed list :: Creates a dashed list style
Cmd + Shift + 9: Numbered list :: Converts the current or selected lines to a numbered list
Cmd + Shift + L: Checklist :: Converts the line(s) to a checklist with interactive checkboxes
Cmd + Shift + U: Check / uncheck item :: Toggles the checkbox on a checklist item
Tab: Indent list item :: Indents the current list item one level deeper
Shift + Tab: Outdent list item :: Outdents the current list item one level
Return: New list item :: Adds a new item to the current list
Cmd + Return: End list (start new paragraph) :: Exits the list and starts a regular paragraph
Cmd + Option + T: Add table :: Inserts a table into the note
Cmd + Shift + A: Add attachment :: Opens the file picker to attach a file to the note

-- Notes List Navigation --
>> Moving between notes in the notes list panel.
Up / Down arrow: Previous / next note :: Moves focus to the note above or below in the list
Return: Open selected note in editor :: Opens the focused note in the editing pane
Cmd + Up: Move to top of list :: Jumps focus to the first note in the list
Cmd + Down: Move to bottom of list :: Jumps focus to the last note in the list
Cmd + 1: Notes list view :: Switches to the standard notes list layout
Cmd + 2: Attachment browser :: Opens the attachments browser showing all attached files and images
Cmd + Shift + K: Lock note :: Locks the selected note with a password (requires password to be set)
Cmd + Shift + P: Pin note to top :: Pins the selected note to the top of the list
Cmd + Option + N: New folder :: Creates a new folder in the Notes sidebar

-- VoiceOver Tips (Notes) --
>> Notes is well-labeled for VoiceOver. These tips improve navigation efficiency.
Tab: Move between sidebar, note list, and editor :: Cycles keyboard focus between the three main panels
VO + Shift + Down: Interact with note list :: Enters the notes list so VoiceOver can navigate individual notes
VO + Right / Left: Navigate notes in the list :: Moves between note items in the sidebar list
VO + Spacebar: Open focused note :: Activates and opens the focused note
VO + A: Read entire note :: Reads the entire body of the currently open note
VO + Cmd + H: Jump to next heading in note :: Moves to the next Title or Heading-styled paragraph
>> Use Cmd+Shift+T (Title) and Cmd+Shift+H (Heading) to add structural headings — VoiceOver can jump between them.
>> Lock sensitive notes with Cmd+Shift+K — VoiceOver announces when a note is locked or unlocked.
"""
    }

    private static var GetPhotosContent: () -> String = {
        return """
-- Navigation --
>> Browsing the photo library and moving between images.
Left / Right arrow: Previous / next photo :: Moves to the adjacent photo in the current album
Cmd + Left / Right: First / last photo :: Jumps to the first or last photo in the view
Escape: Go back to library view :: Returns from a photo to the library grid
Return: Open photo for editing :: Opens the focused photo in the edit view
Cmd + [: Go back in navigation :: Navigates back to the previous view

-- Selection --
>> Selecting photos for sharing, editing, or deleting.
Cmd + A: Select All :: Selects all photos in the current view
Escape: Deselect all :: Clears the current selection
Shift + Click: Select range :: Selects all photos between the two clicked photos
Cmd + Click: Add to selection :: Adds or removes a single photo from the selection

-- Viewing --
>> Zooming and inspecting individual photos.
Cmd + +: Zoom in :: Increases the zoom level on the currently open photo
Cmd + -: Zoom out :: Decreases the zoom level
Cmd + 0: Zoom to fit :: Fits the entire photo within the window
Space (in edit mode): Scroll image :: Pans the zoomed image while in edit mode
Option + Left/Right: Zoom actual size (in edit mode) :: Toggles 100% actual pixel view
Cmd + 3: View on map :: Shows the photo location on a map if GPS data is present
Cmd + I: Show / hide info panel :: Toggles the photo information sidebar
Cmd + Option + I: Show / hide info panel (alternative) :: Alternative shortcut for the info panel

-- Editing --
>> Making adjustments and changes to individual photos.
Return: Enter Edit mode :: Switches to the photo editing view
Escape: Exit Edit mode / cancel :: Exits editing or cancels the current operation
Cmd + Z: Undo last edit :: Reverses the most recent edit adjustment
Cmd + Y: Redo :: Re-applies the last undone adjustment
Cmd + D: Duplicate photo :: Creates a duplicate copy of the photo in the library
Cmd + R: Rotate counterclockwise :: Rotates the photo 90° counterclockwise
Cmd + Option + R: Rotate clockwise :: Rotates the photo 90° clockwise
Cmd + Shift + C: Copy adjustments :: Copies all current editing adjustments
Cmd + Shift + V: Paste adjustments :: Applies copied adjustments to the selected photo
Cmd + F: Find (search) :: Opens the search bar to find photos
Delete: Delete selected photo (to Trash) :: Moves the photo to the Photos Trash
Cmd + Delete: Delete (with confirmation) :: Deletes the photo after a confirmation prompt

-- Albums & Library --
>> Organising photos into albums and navigating library views.
Cmd + N: New album :: Creates a new album in the sidebar
Cmd + Shift + N: New smart album :: Creates a Smart Album with automatic criteria
Cmd + 1: Years view :: Shows photos grouped by year
Cmd + 2: Months view :: Shows photos grouped by month
Cmd + 3: Days view :: Shows photos grouped by day
Cmd + 4: All Photos view :: Shows every photo in the library chronologically
"""
    }

    private static var GetPreviewContent: () -> String = {
        return """
-- PDF Navigation --
>> Moving through pages and finding text in PDF documents.
Cmd + F: Find text :: Opens the Find toolbar to search text in the PDF
Cmd + G: Find next :: Jumps to the next occurrence of the search term
Cmd + Shift + G: Find previous :: Jumps to the previous occurrence of the search term
Arrow keys: Scroll :: Scrolls the current page in the arrow direction
Space: Scroll down (next page) :: Scrolls down; advances to next page at the bottom
Shift + Space: Scroll up (previous page) :: Scrolls up; goes to previous page at the top
Cmd + Right / Down: Next page :: Advances to the next page in the document
Cmd + Left / Up: Previous page :: Returns to the previous page
Cmd + Option + Right: Next page (alternate) :: Alternative shortcut to advance a page
Option + Cmd + Left: Previous page (alternate) :: Alternative shortcut to go back a page
Cmd + Home (fn+Cmd+Left): First page :: Jumps to the very first page of the document
Cmd + End (fn+Cmd+Right): Last page :: Jumps to the very last page of the document
Cmd + G: Go to specific page (via dialog) :: Opens a dialog to type a page number

-- Zoom --
>> Adjusting the display size of pages in Preview.
Cmd + +: Zoom in :: Increases the page zoom level
Cmd + -: Zoom out :: Decreases the page zoom level
Cmd + 0: Zoom to fit window :: Fits the full page width within the Preview window
Cmd + Option + 0: Actual size (100%) :: Displays the page at its true physical size
Cmd + Shift + H: Fit page height :: Scales the page to fit the full window height
Cmd + Shift + W: Fit page width :: Scales the page to fill the full window width

-- Viewing & Tools --
>> Switching between view modes and selecting the active tool.
Cmd + Shift + H: Show/hide highlights and notes :: Toggles annotation overlays on the page
Cmd + 2: Continuous scroll :: Displays pages in a continuous scrolling layout
Cmd + 3: Two-page view :: Shows two pages side by side
Cmd + 1: Single page view :: Displays one page at a time
Cmd + Option + 2: Horizontal scroll (two pages) :: Two-page horizontal layout
Cmd + Shift + D: Crop tool :: Activates the crop selection tool
T: Text selection tool :: Switches to the text selection mode for copying text
V: Selection (rectangle) tool :: Switches to the rectangular selection mode
A: Text annotation tool :: Switches to the text annotation tool for adding notes

-- Markup & Annotation --
>> Adding comments, highlights, and links to PDF documents.
Cmd + Option + S: Show/hide Markup toolbar :: Toggles the annotation toolbar at the top
Cmd + K: Add link annotation :: Opens the Add Link dialog for creating a hyperlink annotation
Cmd + Option + H: Highlight selected text :: Highlights the currently selected text

-- Saving & Exporting --
>> Saving and exporting documents from Preview.
Cmd + S: Save (PDF / image) :: Saves the current file in its current format
Cmd + Shift + S: Save As :: Opens the Save As dialog to choose format and location
Cmd + E: Export :: Opens the export dialog with format conversion options
Cmd + P: Print :: Opens the print dialog for the current document
"""
    }

    private static var GetTerminalContent: () -> String = {
        return """
-- Session Management --
>> Managing tabs, windows, and split panes in Terminal and iTerm2.
Cmd + T: New tab :: Opens a new terminal tab in the current window
Cmd + N: New window :: Opens a new terminal window
Cmd + W: Close tab :: Closes the current tab
Cmd + Shift + W: Close window :: Closes the entire terminal window
Cmd + D: Split pane (right — if using iTerm2) :: Splits the current pane vertically (iTerm2)
Cmd + Shift + D: Split pane (down — iTerm2) :: Splits the current pane horizontally (iTerm2)
Cmd + Option + Arrow: Navigate panes (iTerm2) :: Moves focus between split panes (iTerm2)
Cmd + 1–9: Switch to specific tab :: Activates the tab at that number position
Cmd + Option + Left: Previous tab :: Moves to the previous terminal tab
Cmd + Option + Right: Next tab :: Moves to the next terminal tab
Cmd + Shift + [: Previous tab :: Alternate shortcut to move to the previous tab
Cmd + Shift + ]: Next tab :: Alternate shortcut to move to the next tab

-- Editing Command Line --
>> Moving the cursor and editing text on the command line.
Ctrl + A: Move cursor to beginning of line :: Jumps the cursor to the start of the current line
Ctrl + E: Move cursor to end of line :: Jumps the cursor to the end of the current line
Ctrl + B: Move cursor back one character :: Moves the cursor one character to the left
Ctrl + F: Move cursor forward one character :: Moves the cursor one character to the right
Option + Left: Move cursor back one word :: Jumps the cursor back by one word
Option + Right: Move cursor forward one word :: Jumps the cursor forward by one word
Ctrl + U: Delete from cursor to beginning of line :: Clears all text to the left of the cursor
Ctrl + K: Delete from cursor to end of line :: Clears all text to the right of the cursor
Ctrl + W: Delete word to the left :: Removes the word immediately to the left of the cursor
Ctrl + H: Delete character to the left (Backspace) :: Deletes the character before the cursor
Ctrl + D: Delete character to the right / EOF :: Deletes the character after the cursor or sends EOF
Ctrl + T: Transpose two characters :: Swaps the character at the cursor with the one before it

-- History & Control --
>> Navigating command history and controlling running processes.
Up / Down arrows: Previous / next command in history :: Cycles through previously entered commands
Ctrl + R: Reverse history search :: Searches backwards through command history interactively
Ctrl + C: Cancel / interrupt current command :: Stops the currently running command
Ctrl + Z: Suspend current process (bg) :: Pauses the running process and puts it in the background
Ctrl + D: End of input / logout (if line is empty) :: Logs out of the shell if the line is empty
Ctrl + L: Clear terminal screen :: Clears the visible terminal output (soft clear)
Cmd + K: Clear terminal screen (macOS Terminal) :: Clears and resets the scrollback buffer

-- Scrolling --
>> Scrolling through terminal output history.
Cmd + Up: Scroll up one line :: Scrolls the terminal output up by one line
Cmd + Down: Scroll down one line :: Scrolls the terminal output down by one line
Cmd + Page Up: Scroll up one page :: Scrolls up by one full visible page of output
Cmd + Page Down: Scroll down one page :: Scrolls down by one full visible page of output
Cmd + Home: Scroll to top :: Jumps to the very beginning of the terminal scrollback
Cmd + End: Scroll to bottom :: Jumps to the most recent terminal output

-- Selection & Copy/Paste --
>> Selecting text and using the clipboard in Terminal.
Cmd + A: Select all text in terminal :: Selects all visible and scrollback text in the session
Cmd + C: Copy selection :: Copies the selected text to the clipboard
Cmd + V: Paste :: Pastes clipboard content at the cursor position
Cmd + F: Find in terminal :: Opens the find bar to search terminal output

-- Tab Completion --
>> Using Tab to automatically complete commands and file paths.
Tab: Autocomplete command or path :: Completes the current command or path if unambiguous
Tab Tab: Show all possible completions :: Lists all possible matches when there are multiple options

-- VoiceOver Tips (Terminal) --
>> VoiceOver can read terminal output but requires specific settings to work well.
>> In Terminal: Preferences → Accessibility → check "Use VoiceOver API" for best compatibility.
>> Keep terminal sessions short or use clear (Ctrl+L) regularly — long scrollback buffers slow VO reading.
VO + A: Read all terminal output :: Reads the entire visible terminal buffer continuously
VO + Shift + Down: Interact with terminal area :: Enters the terminal scroll area for reading
VO + Shift + Up: Stop interacting :: Returns focus to the Terminal window chrome
Ctrl + C: Stop running command :: Cancels output and returns to the prompt; VO can then read it
>> After a command runs, press VO+End (fn+VO+Right) to jump to the most recent output.
>> Use "say" command (e.g. say done) at the end of long commands to get an audio cue on completion.
>> iTerm2 has better VoiceOver support than the built-in Terminal app — consider it for daily use.
>> In iTerm2: Preferences → Accessibility → enable "Accessibility" for improved screen reader output.
"""
    }

    private static var GetTextEditContent: () -> String = {
        return """
-- General --
>> File management and search commands in Apple TextEdit.
Cmd + N: New document :: Creates a new blank document
Cmd + O: Open document :: Opens the file browser to select an existing file
Cmd + S: Save :: Saves the current document
Cmd + Shift + S: Save As :: Saves a copy under a new name or location
Cmd + P: Print :: Opens the print dialog
Cmd + W: Close document :: Closes the current document; prompts to save if unsaved
Cmd + Z: Undo :: Reverses the last action
Cmd + Shift + Z: Redo :: Re-applies the last undone action
Cmd + A: Select all :: Selects all text in the document
Cmd + F: Find :: Opens the Find bar to search text in the document
Cmd + G: Find next :: Finds the next occurrence of the search term
Cmd + Shift + G: Find previous :: Finds the previous occurrence
Cmd + H: Find and Replace :: Opens the Find and Replace dialog

-- Text Formatting (Rich Text mode) --
>> Formatting shortcuts for styled documents in Rich Text mode.
Cmd + B: Bold :: Toggles bold on selected text
Cmd + I: Italic :: Toggles italic on selected text
Cmd + U: Underline :: Toggles underline on selected text
Cmd + T: Show/hide Fonts panel :: Opens or closes the Fonts panel
Cmd + Shift + C: Show/hide Colors panel :: Opens or closes the Colors picker
Cmd + E: Center align :: Centers the current paragraph
Cmd + L: Left align :: Left-aligns the current paragraph
Cmd + R: Right align :: Right-aligns the current paragraph
Cmd + [: Decrease indent :: Reduces the left indent of the current paragraph
Cmd + ]: Increase indent :: Increases the left indent of the current paragraph

-- Special --
>> Switching between document modes and inserting special content.
Cmd + Shift + T: Toggle Rich Text / Plain Text :: Converts the document format (requires confirmation)
Cmd + K: Insert hyperlink (Rich Text) :: Opens the Add Link dialog in rich text mode
"""
    }

    private static var GetBrowserContent: () -> String = {
        return """
-- Navigation --
>> Moving through web pages and browsing history in any browser.
Cmd + L: Select address bar (open location) :: Highlights the URL bar for typing a new address
Cmd + R: Reload page :: Reloads the current page
Cmd + Shift + R: Hard reload (bypass cache) :: Forces a full page reload ignoring cached content
Cmd + [: Go back :: Returns to the previous page in the tab's history
Cmd + ]: Go forward :: Goes forward to the next page in the tab's history
Escape: Stop loading page :: Cancels the current page load
Space: Scroll down one page :: Scrolls the page down by one visible screen
Shift + Space: Scroll up one page :: Scrolls the page up by one visible screen
Cmd + Up (fn+Cmd+Up): Go to top of page :: Jumps to the very top of the current page
Cmd + Down (fn+Cmd+Down): Go to bottom of page :: Jumps to the very bottom of the current page
Cmd + F: Find on page :: Opens the in-page search bar
Cmd + G: Find next :: Jumps to the next occurrence of the search term
Cmd + Shift + G: Find previous :: Jumps to the previous occurrence

-- Tabs & Windows --
>> Managing browser tabs and windows.
Cmd + T: New tab :: Opens a fresh tab to the new tab page
Cmd + W: Close tab :: Closes the current tab
Cmd + Shift + T: Reopen closed tab :: Reopens the most recently closed tab
Cmd + N: New window :: Opens a new browser window
Cmd + Shift + N: New Incognito window (Chrome / Safari) :: Opens a new private browsing window in Chrome or Safari
Cmd + Shift + P: New Private window (Firefox) :: Opens a new private browsing window in Firefox
Cmd + Option + Left: Previous tab :: Moves to the tab immediately to the left
Cmd + Option + Right: Next tab :: Moves to the tab immediately to the right
Cmd + 1–8: Switch to specific tab (1–8) :: Activates the tab at that position number
Cmd + 9: Switch to last tab :: Jumps to the rightmost open tab
Cmd + M: Minimize window :: Minimises the browser window to the Dock

-- Zoom & Display --
>> Adjusting page zoom and accessing developer tools.
Cmd + +: Zoom in :: Increases the page text and content size
Cmd + -: Zoom out :: Decreases the page text and content size
Cmd + 0: Reset zoom (100%) :: Resets page zoom to the default 100%
Control + Cmd + F: Full screen :: Toggles the browser full-screen mode
Cmd + Option + I: Developer Tools :: Opens the browser developer tools panel
Cmd + Option + J: Console (Chrome) :: Opens the JavaScript console in Chrome
Cmd + U: View page source :: Opens the raw HTML source code of the current page

-- Bookmarks --
>> Saving and managing bookmarks in the browser.
Cmd + D: Bookmark current page :: Saves the current page to your bookmarks
Cmd + Shift + D: Bookmark all open tabs (Chrome) :: Saves all tabs as a folder of bookmarks
Cmd + Option + B: Show Bookmarks Manager :: Opens the bookmarks management page
Cmd + Shift + B: Show / hide Bookmarks bar (Chrome) :: Toggles the bookmarks toolbar

-- History & Downloads --
>> Accessing browser history and downloaded files.
Cmd + Y: Open History (Chrome) / Downloads (Firefox) :: Opens the history or downloads page
Cmd + Shift + H: Open History (Chrome) :: Opens the browsing history page in Chrome
Cmd + Shift + J: Open Downloads (Chrome) :: Opens the downloads page in Chrome
Cmd + J: Open Downloads (Firefox) :: Opens the downloads panel in Firefox
"""
    }

    private static var GetZoomContent: () -> String = {
        return """
-- Audio & Video --
>> Controls for your microphone and camera during a Zoom call.
Cmd + Shift + A: Mute / unmute my audio :: Toggles your microphone on or off
Cmd + Ctrl + M: Mute audio for everyone except host :: Host-only — mutes all participants
Cmd + Ctrl + U: Unmute audio for everyone except host :: Host-only — requests all to unmute
Space (hold): Push-to-talk :: Temporarily unmutes while the spacebar is held (when muted)
Cmd + Shift + V: Start / stop my video :: Turns your webcam on or off
Cmd + Shift + N: Switch camera :: Cycles to the next available camera

-- Screen Share & Recording --
>> Sharing your screen and recording the meeting.
Cmd + Shift + S: Start / stop screen share :: Begins or ends screen sharing
Cmd + Shift + T: Pause / resume screen share :: Pauses or resumes an active screen share
Cmd + Ctrl + S: Direct share (outside a meeting) :: Starts a direct screen share from the Zoom home screen
Cmd + Shift + R: Start / stop local recording :: Begins or ends a local recording to your disk
Cmd + Shift + C: Start / stop cloud recording :: Begins or ends a cloud recording to Zoom
Cmd + Shift + P: Pause / resume recording :: Pauses or resumes an active recording

-- Meeting View & Controls --
>> Switching layouts and toggling meeting UI.
Cmd + Shift + F: Enter / exit full screen :: Toggles full-screen meeting view
Cmd + Shift + W: Switch to active speaker / gallery view :: Toggles between speaker and gallery layouts
Cmd + Shift + M: Switch to minimal window / exit minimal window :: Toggles Zoom's compact floating window
Ctrl + Option + Cmd + H: Show / hide meeting controls :: Toggles visibility of the meeting toolbar
Cmd + W: Prompt to end / leave meeting :: Shows the End/Leave Meeting dialog

-- Participants & Reactions --
>> Managing the participant list and raising your hand.
Cmd + U: Open / close Participants panel :: Toggles the participant list panel
Option + Y: Raise / lower hand :: Toggles the raised-hand reaction

-- Chat --
>> Using the in-meeting text chat feature.
Cmd + Shift + H: Show / hide in-meeting chat panel :: Toggles the chat panel open or closed
Return: Send chat message :: Sends the typed message
Shift + Return: New line in chat :: Inserts a line break without sending

-- Navigation --
>> Moving focus between Zoom windows.
F6: Navigate among Zoom popup windows :: Cycles keyboard focus between Zoom panels
Ctrl + T: Switch to next Zoom window :: Cycles forward through open Zoom windows

-- Before / Outside Meeting --
>> Starting, joining, and scheduling meetings from the Zoom home screen.
Cmd + J: Join a meeting :: Opens the Join Meeting dialog to enter a meeting ID
Cmd + Ctrl + V: Start an instant meeting :: Begins a new meeting immediately
Cmd + D: Schedule a meeting :: Opens the Schedule a Meeting form
Cmd + ,: Open Zoom preferences :: Opens the Zoom Settings window
"""
    }

    private static var GetTeamsDesktopMacContent: () -> String = {
        return """
-- General --
>> App-level search and module navigation in the new Microsoft Teams desktop app.
Cmd + E: Search / go to :: Moves focus to the search bar for searching messages, people, or channels
Cmd + /: Commands :: Opens the command bar for quick actions
Cmd + . (period): Open keyboard shortcuts :: Shows the full keyboard shortcut reference inside Teams
Cmd + 1: Go to Activity :: Opens the Activity feed with recent notifications
Cmd + 2: Go to Chat :: Opens the Chat section for direct messages
Cmd + 3: Go to Teams :: Opens the Teams and channels list
Cmd + 4: Go to Calendar :: Opens the Calendar and meetings view
Cmd + 5: Go to Calls :: Opens the Calls section (position may vary if you've reordered the app bar)
Cmd + 6: Go to Files :: Opens the Files section (position may vary if you've reordered the app bar)
Cmd + N: New chat :: Opens a new direct message compose window
Ctrl + Tab: Next recent item :: Cycles forward through recent chats, channels, and apps
Ctrl + Shift + Tab: Previous recent item :: Cycles backward through recent chats, channels, and apps
Escape: Close / go back :: Dismisses the current panel or navigates back

-- Messaging --
>> Composing and sending messages in Teams chats and channels.
Cmd + Shift + X: Expand compose box :: Toggles the compose box to full-size mode
Option + Shift + F10: Show formatting toolbar :: Reveals the rich text formatting toolbar
Return: New line (if "Enter sends message" is off) :: Inserts a line break when auto-send is off
Cmd + Return: Send message :: Always sends the message regardless of settings
Shift + Return: New line (always) :: Inserts a line break without sending the message
Cmd + Z: Undo :: Reverses the last action while composing
Up arrow (empty box): Edit last message :: Opens your last sent message for editing

-- Meetings / Calls --
>> Audio, video, and screen controls during a Teams call or meeting.
Cmd + Shift + M: Mute / unmute microphone :: Toggles your microphone on or off
Cmd + Shift + Space: Push-to-talk :: Hold to temporarily unmute while muted
Cmd + Shift + O: Toggle camera :: Turns your webcam on or off
Cmd + Shift + K: Raise / lower hand :: Toggles the raised hand indicator
Cmd + Shift + E: Share screen :: Opens the screen sharing options
Cmd + Shift + P: Toggle background blur :: Turns background blur on or off
Cmd + Shift + B: Hang up / leave call :: Ends the current call
Cmd + Shift + A: Accept incoming video call :: Answers an incoming call with video
Cmd + Shift + S: Accept incoming audio call :: Answers an incoming call as audio-only
Cmd + Shift + D: Decline incoming call :: Rejects an incoming call

-- Navigation --
>> Moving through the Teams interface and panels.
Cmd + ]: Go forward :: Navigates forward in the navigation history
Cmd + [: Go back :: Navigates back in the navigation history
Tab: Move forward in focus :: Moves keyboard focus to the next interactive element
Shift + Tab: Move backward in focus :: Moves keyboard focus to the previous element
"""
    }

    private static var GetAdobeReaderContent: () -> String = {
        return """
-- Navigation --
>> Moving through pages and searching text in Adobe Acrobat Reader.
Cmd + F: Find / Search :: Opens the Find toolbar to search text in the PDF
Cmd + G: Find next :: Jumps to the next occurrence of the search term
Cmd + Shift + G: Find previous :: Jumps to the previous occurrence of the search term
Right Arrow / Page Down: Next page :: Advances to the next page in the document
Left Arrow / Page Up: Previous page :: Returns to the previous page
Cmd + Home (fn+Cmd+Left): First page :: Jumps to the very first page
Cmd + End (fn+Cmd+Right): Last page :: Jumps to the very last page
Cmd + Shift + N: Go to specific page number :: Opens the Go To Page dialog to enter a number

-- Zoom --
>> Adjusting the display size and fit of pages.
Cmd + +: Zoom in :: Increases the page zoom level
Cmd + -: Zoom out :: Decreases the page zoom level
Cmd + 0: Fit page to window :: Scales the page to fit entirely in the window
Cmd + 1: Actual size (100%) :: Displays the page at its true physical size (100%)
Cmd + 2: Fit width :: Scales the page to fill the full window width
Cmd + 3: Fit visible area :: Zooms to show only the content area of the page

-- Viewing --
>> Changing the display mode and panel visibility.
Cmd + L: Full screen (presentation mode) :: Enters full-screen reading mode
Escape: Exit full screen :: Exits full-screen or presentation mode
Cmd + H: Hide application :: Hides the Acrobat Reader window
F4: Show/hide Navigation panel (bookmarks) :: Toggles the bookmarks sidebar
Control + Cmd + F: Full screen mode :: Alternative shortcut for full-screen mode

-- Editing & Tools --
>> Selecting text and using Reader tools.
Cmd + A: Select all text (in selection tool) :: Selects all text on the current page
Cmd + C: Copy selected text :: Copies the selected text to the clipboard
V: Hand (scroll) tool :: Activates the hand tool for scrolling by dragging
I: Select tool :: Switches to the selection tool for choosing text or objects
Cmd + Shift + S: Save As / Export :: Opens Save As to export in a different format
Cmd + S: Save :: Saves the current PDF file
Cmd + P: Print :: Opens the print dialog
Cmd + W: Close document :: Closes the currently open PDF

-- Comments --
>> Adding annotations and highlights to PDF documents.
U: Highlight tool (single-key accelerators on) :: Activates the text highlighting tool (requires "Use single-key accelerators" enabled in Preferences)
Cmd + Option + A: Add note / sticky note :: Inserts a sticky note annotation at the cursor
"""
    }

    private static var GetYouTubeContent: () -> String = {
        return """
-- Playback --
>> Controlling playback speed and pausing YouTube videos.
Space or K: Play / Pause :: Toggles playback of the current video
F: Toggle full screen :: Enters or exits full-screen video mode
M: Mute / unmute :: Silences or restores the video audio
C: Toggle captions / subtitles :: Turns closed captions on or off
.: Increase playback speed :: Raises the playback speed by one step
,: Decrease playback speed :: Lowers the playback speed by one step
Number keys (1–9): Jump to 10%–90% of video :: Skips to that percentage point of the video
0: Jump to beginning of video :: Restarts the video from the very beginning
Home: Jump to beginning :: Alternative shortcut to go back to the start
End: Jump to last loaded frame :: Skips to the farthest point that has buffered

-- Seeking --
>> Jumping to specific positions in the currently playing video.
Right arrow: Seek forward 5 seconds :: Skips 5 seconds ahead in the video
Left arrow: Seek back 5 seconds :: Rewinds 5 seconds in the video
J: Seek back 10 seconds :: Jumps back 10 seconds in the video
L: Seek forward 10 seconds :: Jumps forward 10 seconds in the video
Shift + N: Next video (playlist) :: Advances to the next video in a playlist
Shift + P: Previous video (playlist) :: Goes back to the previous playlist video

-- Volume --
>> Adjusting the audio volume with keyboard shortcuts.
Up arrow: Increase volume 5% :: Raises the YouTube player volume by 5%
Down arrow: Decrease volume 5% :: Lowers the YouTube player volume by 5%
M: Mute / unmute :: Toggles between muted and the current volume level

-- Interface --
>> Changing the player layout and interface mode.
T: Toggle theater mode :: Switches between theater and normal player layout
I: Toggle miniplayer :: Collapses the video into a floating miniplayer
Escape: Exit full screen / miniplayer :: Exits full-screen mode or dismisses the miniplayer
/: Move focus to search bar :: Moves keyboard focus to the YouTube search input
"""
    }

    private static var GetVLCContent: () -> String = {
        return """
-- Playback Controls --
>> Starting, stopping, and navigating between media files in VLC.
Space: Play / Pause :: Toggles playback of the current file
Cmd + .: Stop :: Stops playback and resets the position to the beginning
Cmd + Right: Next in playlist :: Skips to the next item in the playlist
Cmd + Left: Previous in playlist :: Goes back to the previous item in the playlist
Cmd + F: Toggle full screen :: Enters or exits full-screen playback mode
Escape: Exit full screen :: Exits full-screen mode without stopping playback

-- Seeking --
>> Jumping to specific positions within the current media file.
Cmd + Shift + Right: Seek forward 1 minute :: Jumps 1 minute ahead in the file
Cmd + Shift + Left: Seek backward 1 minute :: Rewinds 1 minute in the file
Cmd + Option + Right: Seek forward 10 seconds :: Skips 10 seconds ahead
Cmd + Option + Left: Seek backward 10 seconds :: Rewinds 10 seconds
Cmd + Ctrl + Right: Seek forward 3 seconds :: Skips 3 seconds ahead (fine control)
Cmd + Ctrl + Left: Seek backward 3 seconds :: Rewinds 3 seconds (fine control)
Cmd + T: Go to specific time :: Opens a dialog to enter a precise playback position

-- Volume --
>> Adjusting audio output volume in VLC.
Cmd + Up: Increase volume :: Raises the VLC playback volume
Cmd + Down: Decrease volume :: Lowers the VLC playback volume
M: Mute / unmute :: Silences or restores the audio output

-- Speed --
>> Changing the playback speed of the current media.
=: Faster (increase playback speed) :: Speeds up playback by one step
-: Slower (decrease playback speed) :: Slows down playback by one step
Backspace: Reset to normal speed (1x) :: Returns playback to the standard 1x speed

-- Audio & Subtitles --
>> Switching between audio tracks and subtitle streams.
A: Cycle audio tracks :: Switches to the next available audio language track
V: Cycle subtitle tracks :: Switches to the next available subtitle track
H: Cycle chapters :: Skips to the next chapter marker in the file
B: Cycle bookmark :: Jumps to the next saved bookmark position

-- Window --
>> Resizing and managing the VLC player window.
Cmd + H: Hide VLC :: Hides the VLC application window
Control + 0: Fit window to video :: Resizes the window to match the video's native resolution
Control + 1: Quarter size :: Scales the window to 25% of the video resolution
Control + 2: Half size :: Scales the window to 50% of the video resolution
Control + 3: Normal size (100%) :: Scales the window to 100% of the video resolution
Control + 4: Double size :: Scales the window to 200% of the video resolution
Cmd + W: Close window :: Closes the current VLC window
"""
    }

    private static var GetSpotifyContent: () -> String = {
        return """
-- Playback --
>> Controlling music playback in the Spotify desktop app.
Space: Play / Pause :: Toggles playback of the current track
Cmd + Right: Next track :: Skips to the next track in the queue
Cmd + Left: Previous track (or restart current) :: Goes back to the previous track or restarts the current one
Cmd + Up: Volume up :: Increases the Spotify playback volume
Cmd + Down: Volume down :: Decreases the Spotify playback volume
Cmd + Shift + Right: Seek forward :: Fast-forwards within the current track
Cmd + Shift + Left: Seek backward :: Rewinds within the current track
Cmd + Shift + R: Toggle Repeat :: Cycles through Off, Repeat All, and Repeat One modes
Cmd + Shift + S: Toggle Shuffle :: Turns shuffle playback on or off
M: Toggle Mute :: Mutes or unmutes the audio output

-- Navigation --
>> Searching and moving through the Spotify interface.
Cmd + L: Select search field :: Moves keyboard focus to the search bar
Cmd + F: Find (search) :: Alternative shortcut to focus the search bar
Delete / Backspace: Remove selected item from playlist :: Removes the selected track from a playlist
Cmd + Option + Left: Go back in navigation :: Navigates back in the app history
Cmd + Option + Right: Go forward in navigation :: Navigates forward in the app history
Return: Play selected track :: Starts playing the focused track
Cmd + Option + F: Filter current list :: Filters the visible list by keyword

-- Library --
>> Accessing different sections of your Spotify library.
Cmd + 1: Now Playing :: Switches to the Now Playing view
Cmd + 2: Search :: Opens the Search section
Cmd + 3: Your Library :: Opens the Your Library section
Cmd + Shift + 1: Home :: Navigates to the Spotify Home feed
Cmd + Option + P: Show currently playing track :: Scrolls to reveal the currently playing track

-- Window --
>> Managing the Spotify application window.
Cmd + H: Hide Spotify :: Hides the Spotify window
Cmd + M: Minimize :: Minimises the Spotify window to the Dock
Control + Cmd + F: Full screen :: Toggles Spotify in full-screen mode
"""
    }

    private static var GetQuickTimeContent: () -> String = {
        return """
-- Playback --
>> Controlling video playback in QuickTime Player.
Space: Play / Pause :: Toggles playback of the current movie or audio file
Left arrow: Step back one frame (paused) :: Steps one frame backward while the video is paused
Right arrow: Step forward one frame (paused) :: Steps one frame forward while the video is paused
Option + Cmd + Left: Beginning of movie :: Jumps to the very start of the movie
Option + Cmd + Right: End of movie :: Jumps to the very end of the movie

-- Seeking --
>> Jumping to chapters and specific positions in the movie.
Cmd + Right: Skip to next chapter :: Advances to the next chapter marker
Cmd + Left: Skip to previous chapter / restart :: Goes back to the previous chapter or restarts
Option + Right: Seek forward :: Fast-forwards within the current movie
Option + Left: Seek backward :: Rewinds within the current movie

-- Volume --
>> Adjusting audio volume in QuickTime Player.
Cmd + Up: Increase volume :: Raises the QuickTime playback volume
Cmd + Down: Decrease volume :: Lowers the QuickTime playback volume
Option + Cmd + Down: Mute :: Silences the audio output

-- Window & View --
>> Changing the player window size and display mode.
Cmd + F: Enter full screen :: Switches to full-screen playback mode
Escape: Exit full screen :: Returns to windowed mode from full screen
Cmd + 1: Actual size :: Resizes the window to the video's native resolution
Cmd + 2: Double size :: Resizes the window to twice the video's native resolution
Cmd + 3: Fit screen :: Scales the movie to fill the entire screen
Cmd + Option + F: Fit to screen (alternate) :: Alternative shortcut for fit-to-screen mode
Cmd + [: Rotate left :: Rotates the video 90° counterclockwise
Cmd + ]: Rotate right :: Rotates the video 90° clockwise

-- Recording --
>> Starting new recordings using QuickTime's capture features.
Cmd + Option + N: New Movie Recording :: Opens a new movie recording session using the camera
Cmd + Option + A: New Audio Recording :: Opens a new audio-only recording session
Cmd + Ctrl + N: New Screen Recording :: Opens a new screen recording capture session

-- Editing --
>> Trimming and exporting clips in QuickTime.
Cmd + T: Trim (show trim handles) :: Activates the trim bar to set in and out points
Cmd + Y: Split clip at playhead :: Splits the movie at the current playhead position
Cmd + I: Movie Inspector (info) :: Opens the Movie Inspector showing codec and file details
Cmd + E: Export (Save for...) :: Opens the Export dialog to save in a different format
"""
    }

    private static var GetAccessibilityOverviewContent: () -> String = {
        return """
-- Enabling Accessibility Features --
>> System shortcuts for turning macOS accessibility features on and off.
Cmd + F5: Toggle VoiceOver on/off :: Turns VoiceOver screen reader on or off system-wide
Control + Option + F5: VoiceOver Utility :: Opens the VoiceOver Utility configuration panel
Cmd + Option + F5: Accessibility Shortcut Panel :: Shows the customisable accessibility shortcuts panel
(Go to System Settings > Accessibility to configure)

-- Common Accessibility Shortcuts --
>> Frequently used macOS accessibility shortcuts for vision and motor assistance.
Cmd + Option + 8: Toggle Zoom on/off :: Turns screen magnification zoom on or off
Cmd + Option + =: Zoom in :: Increases the screen magnification level
Cmd + Option + -: Zoom out :: Decreases the screen magnification level
Cmd + Option + F11: Invert colors (Classic Invert) :: Inverts all screen colours
Control + Option + Cmd + 8: Toggle Color Invert :: Toggles smart colour inversion
Cmd + F5: Toggle VoiceOver :: Turns VoiceOver on or off (same as above)
Control + F1: Toggle keyboard access to windows and dialogs :: Enables full keyboard navigation
Cmd + Option + A: Open Accessibility Inspector (Xcode) :: Opens the Xcode Accessibility Inspector tool

-- Zoom Settings (System Settings > Accessibility > Zoom) --
>> Configuring and using the built-in screen zoom feature.
Zoom shortcut (configured):  Cmd + Option + 8 by default
Zoom in: Cmd + Option + = :: Increases zoom level when Zoom is active
Zoom out: Cmd + Option + - :: Decreases zoom level when Zoom is active
Zoom to selected area: Cmd + Option + Shift + 8 :: Zooms in on the currently selected region

-- Display Accessibility --
>> Shortcuts for the Accessibility features panel and display adjustments.
Cmd + Option + F5: Accessibility Shortcut Panel (configure shortcuts) :: Opens the shortcuts panel to toggle features
Control + F7: Override for full keyboard access :: Forces full keyboard navigation mode on

-- Spoken Content --
>> Using macOS's built-in text-to-speech features.
Option + Escape: Speak selected text (if Speech > Speak Selection is on) :: Reads selected text aloud
(Configure in System Settings > Accessibility > Spoken Content)

-- Sticky Keys, Slow Keys --
>> Alternative keyboard input features for motor accessibility.
(Configure in System Settings > Accessibility > Keyboard)
"""
    }

    private static var GetVoiceOverContent: () -> String = {
        return """
-- VoiceOver Basics --
>> Fundamental commands for enabling and controlling the VoiceOver screen reader.
Cmd + F5: Turn VoiceOver on / off :: Toggles the VoiceOver screen reader system-wide
Control + Option: VoiceOver modifier keys (VO) :: Hold these together as the VO modifier for all VO commands
VO + H: VoiceOver Help :: Opens the VoiceOver Help menu with command categories
VO + H + H: VoiceOver Commands menu (full list) :: Opens the full browsable commands list
VO + F8: VoiceOver Utility :: Opens the VoiceOver configuration and settings panel
VO + Escape: Escape / stop speaking :: Stops VoiceOver speech and dismisses menus
Control: Stop speaking immediately :: Instantly silences VoiceOver without losing focus
VO + Q: Toggle Quick Nav on / off :: Enables or disables Quick Nav for single-key web navigation

-- Navigation --
>> Moving the VoiceOver cursor through the screen and web content.
VO + Right: Move to next item :: Moves VoiceOver cursor to the next element
VO + Left: Move to previous item :: Moves VoiceOver cursor to the previous element
VO + Shift + Down: Interact with group :: Enters and interacts with the focused container or group
VO + Shift + Up: Stop interacting with group :: Exits the current group and returns to the parent container
VO + F1: Announce application :: Speaks the name of the current application
VO + F2: Announce window :: Speaks the name of the current window
VO + F3: Describe current item :: Reads a full description of the focused element
VO + F4: Describe selected text :: Reads details about the currently selected text
VO + T: Read status bar :: Reads the current application's status bar
VO + Home (fn+VO+Left): Beginning of page :: Moves the VoiceOver cursor to the very top of the page
VO + End (fn+VO+Right): End of page :: Moves the VoiceOver cursor to the very bottom of the page

-- Reading --
>> Having VoiceOver read content aloud automatically.
VO + A: Read all from current position :: Reads continuously from the current element onwards
VO + W: Read current word :: Reads the word at the current VoiceOver cursor position
VO + S: Read current sentence :: Reads the sentence at the current cursor position
VO + P: Read current paragraph :: Reads the paragraph at the current cursor position
VO + B: Read from beginning :: Reads from the very start of the document or web page
VO + [: Read previous sentence :: Reads the sentence before the current cursor position
VO + ]: Read next sentence :: Reads the sentence after the current cursor position

-- Actions --
>> Clicking, activating, and interacting with UI elements.
VO + Space: Click / activate item :: Clicks or activates the focused element
VO + Return: Open / confirm item :: Opens or confirms the focused item (equivalent to double-click)
VO + Shift + Space: Right-click / context menu :: Opens the context menu for the focused element
VO + Option + Shift + M: Open context / application menu :: Opens the app menu or context menu
VO + Cmd + Return: Perform default action :: Triggers the primary action on the focused element

-- Focus & Application Navigation --
>> Moving between applications and switching focus.
VO + F1 + F1: Application Chooser :: Opens the VoiceOver application chooser panel
VO + F2 + F2: Window Chooser :: Opens a list of all windows for the current app
Cmd + F5 (hold): VoiceOver quick settings :: Hold Cmd+F5 for the quick settings popover
VO + Cmd + Space: VoiceOver menu :: Opens the VoiceOver main menu

-- Web Navigation (Safari) --
>> VoiceOver commands for efficient navigation on web pages in Safari.
VO + U: Open Web Rotor :: Opens the Rotor — arrow left/right to choose element type, up/down to navigate
VO + Cmd + H: Next heading :: Jumps to the next heading on the page
VO + Cmd + Shift + H: Previous heading :: Jumps to the previous heading on the page
VO + Cmd + L: Next link :: Jumps to the next hyperlink
VO + Cmd + Shift + L: Previous link :: Jumps to the previous hyperlink
VO + Cmd + F: Next form field :: Jumps to the next text input, button, or interactive control
VO + Cmd + Shift + F: Previous form field :: Jumps to the previous form control
VO + Cmd + T: Next table :: Jumps to the next data table on the page
VO + Cmd + Shift + T: Previous table :: Jumps to the previous table
VO + Cmd + G: Next image :: Jumps to the next image or graphic element
VO + Cmd + X: Next list :: Jumps to the next bulleted or numbered list
VO + Cmd + J: Next frame :: Jumps to the next iframe or embedded frame
VO + Cmd + R: Next landmark :: Jumps to the next ARIA landmark region

-- Quick Nav (Web Browsing) --
>> Quick Nav enables single-key navigation in Safari — press VO+Q to toggle on/off.
>> When Quick Nav is ON, hold no modifier — just press the key alone.
H: Next heading :: Jump to next heading (when Quick Nav is active)
Shift + H: Previous heading :: Jump to previous heading
L: Next link :: Jump to next link
Shift + L: Previous link :: Jump to previous link
F: Next form control :: Jump to next form field or button
T: Next table :: Jump to next table
B: Next button :: Jump to next button element
Left + Right arrows (together): Toggle Quick Nav on/off :: Hold both Left and Right arrow simultaneously

-- Table Navigation --
>> Navigating rows, columns, and cells within HTML data tables.
VO + Cmd + T: Jump to next table :: Moves VoiceOver cursor to the next table on the page
VO + Shift + Down: Enter the table :: Begins interacting with the focused table
VO + Cmd + Right: Next cell in row :: Moves one cell to the right within a table row
VO + Cmd + Left: Previous cell in row :: Moves one cell to the left within a table row
VO + Cmd + Down: Next row (same column) :: Moves one row down in the same column
VO + Cmd + Up: Previous row (same column) :: Moves one row up in the same column
VO + C: Read column header :: Speaks the header of the current column
VO + R: Read row header :: Speaks the header of the current row

(VO = Control + Option)
"""
    }

    private static var GetZoomAccessibilityContent: () -> String = {
        return """
-- Zoom (Accessibility Feature) --
>> Enabling and controlling the macOS built-in screen magnification feature.
Enable Zoom: System Settings > Accessibility > Zoom
Cmd + Option + 8: Toggle Zoom on / off :: Turns the screen zoom magnification on or off
Cmd + Option + =: Zoom in :: Increases the current magnification level
Cmd + Option + -: Zoom out :: Decreases the current magnification level
Cmd + Option + Backslash: Toggle smooth images :: Enables or disables image smoothing while zoomed

-- Zoom Styles --
>> Choosing between different zoom display modes in System Settings.
Full Screen Zoom: Magnifies entire screen :: The whole display is magnified uniformly
Split Screen Zoom: Panel at bottom shows zoomed area :: Zoomed view appears in a panel at the screen bottom
Picture-in-Picture: Floating zoomed window near cursor :: A floating window shows the magnified area near the pointer

-- Hover Text (macOS 10.15+) --
>> Using the Hover Text feature to enlarge small text under the pointer.
Enable: System Settings > Accessibility > Zoom > Hover Text
Trigger: Hold Cmd key — text under pointer is enlarged in a panel :: Hold Cmd to show a large-text panel for whatever the pointer touches

-- Display Adjustments --
>> Display accessibility settings that improve visibility for all users.
Cmd + Option + F5: Accessibility Shortcut Panel :: Opens the panel to quickly toggle features
(System Settings > Accessibility > Display for options:)
Reduce Motion: Minimizes animations throughout macOS :: Reduces movement effects in the UI
Increase Contrast: Stronger UI borders :: Adds stronger borders to buttons, menus, and controls
Reduce Transparency: Solid backgrounds instead of blur :: Removes frosted glass effects in the UI
Differentiate Without Color: Adds shapes/patterns alongside color :: Uses shapes not just colour to convey status
"""
    }

    private static var GetVoiceControlContent: () -> String = {
        return """
-- Enabling Voice Control --
>> Setting up and activating Voice Control on your Mac.
System Settings > Accessibility > Voice Control > Enable
(Microphone icon appears in menu bar when active)
Cmd + F5 or triple-click side button: Accessibility shortcuts :: Opens the Accessibility Shortcuts panel

-- Core Commands (say these aloud) --
>> Spoken commands for controlling your Mac entirely by voice.
\"Wake up\": Activate Voice Control :: Resumes Voice Control after it has been sleeping
\"Go to sleep\": Pause Voice Control :: Suspends Voice Control without disabling it
\"Show commands\": Show all available commands :: Displays a list of all Voice Control commands
\"Click [item name]\": Click named button, menu, link, etc. :: Clicks any labelled UI element by its name
\"Show numbers\": Overlay numbers on clickable items :: Overlays numbered labels on all clickable elements
\"Click [number]\": Click item by its overlay number :: Activates an element using its numbered overlay label
\"Hide numbers\": Remove number overlay :: Removes the numbered overlay labels from the screen
\"Open [app name]\": Open an application :: Launches the named application
\"Scroll up/down\": Scroll the current view :: Scrolls the focused area in the specified direction
\"Press [key]\": Press any keyboard key (e.g. \"Press Return\") :: Simulates pressing the named keyboard key
\"Type [text]\": Dictate and insert text :: Inserts the spoken text at the current cursor position
\"Select [text]\": Select specific text on screen :: Selects the named text in the current document
\"Replace [word] with [word]\": Replace text :: Substitutes the first word or phrase with the second
\"Undo that\": Undo last action :: Reverses the most recent voice or keyboard action
\"Copy that\": Copy selection :: Copies the current selection to the clipboard
\"Paste that\": Paste clipboard :: Pastes the clipboard content at the cursor

-- Navigation Commands --
>> Voice commands for moving around the screen and scrolling.
\"Move up/down/left/right\": Move cursor :: Moves the mouse cursor in the specified direction
\"Scroll to top\": Scroll to top of page :: Scrolls the current view to the very top
\"Scroll to bottom\": Scroll to bottom of page :: Scrolls the current view to the very bottom
\"Go back\": Navigate back :: Navigates back in the current app
\"Show grid\": Overlay grid for precise clicking :: Overlays a numbered grid on the screen
\"Click [grid section]\": Click grid by number/position :: Clicks the specified grid section number

-- Dictation --
>> Voice punctuation and formatting commands while dictating text.
\"New line\": Insert line break :: Inserts a single line break at the cursor
\"New paragraph\": Insert paragraph break :: Inserts a paragraph break (two line breaks)
\"Comma / Period / etc\": Insert punctuation :: Inserts the named punctuation character
\"Cap [word]\": Capitalize next word :: Capitalizes the first letter of the next spoken word
\"All caps on\": Switch to uppercase mode :: All subsequent dictated text is uppercase
\"All caps off\": Return to normal :: Returns dictation to normal mixed-case mode
"""
    }

    private static var GetDictationContent: () -> String = {
        return """
-- Enabling Dictation --
>> Setting up macOS Dictation in System Settings.
System Settings > Keyboard > Dictation > On
Default shortcut: Press Fn / Globe key twice
(Or set a custom shortcut in the same settings panel)

-- Using Dictation --
>> Starting, stopping, and confirming dictated text.
Double-press Fn (Globe): Start / stop dictation :: Activates or deactivates dictation (microphone appears at cursor)
(Microphone icon appears at cursor)
Escape: Cancel dictation without inserting text :: Stops dictation and discards the transcription
Return or Done button: Confirm and insert dictated text :: Accepts the transcription and inserts it at the cursor

-- Dictation Commands (Enhanced Dictation) --
>> Spoken commands for adding punctuation and formatting while dictating.
\"New line\": Insert a new line :: Inserts a single line break at the cursor position
\"New paragraph\": Insert a paragraph break :: Inserts a double line break to start a new paragraph
\"Period\": Insert \".\" :: Inserts a full stop without saying the word
\"Comma\": Insert \",\" :: Inserts a comma without saying the word
\"Question mark\": Insert \"?\" :: Inserts a question mark
\"Exclamation mark\": Insert \"!\" :: Inserts an exclamation mark
\"Open quote\": Insert opening quote (\") :: Inserts a left double quotation mark
\"Close quote\": Insert closing quote (\") :: Inserts a right double quotation mark
\"Colon\": Insert \":\" :: Inserts a colon character
\"Semicolon\": Insert \";\" :: Inserts a semicolon character
\"Hyphen\": Insert \"-\" :: Inserts a hyphen or dash character
\"Open parenthesis\": Insert \"(\" :: Inserts an opening parenthesis
\"Close parenthesis\": Insert \")\" :: Inserts a closing parenthesis

-- Text Formatting via Voice --
>> Voice commands for changing capitalisation while dictating.
\"Cap [word]\": Capitalize the next word :: Forces the next dictated word to start with a capital letter
\"All caps [word]\": Make word all uppercase :: Dictates the next word in all uppercase letters
\"Delete [word]\": Remove specific word (Enhanced Dictation) :: Removes the specified word from the dictation
\"No space\": No space before next word :: Joins the next word to the previous without a space

-- Notes --
>> Important information about using macOS Dictation.
Dictation works in any text field on Mac
Enhanced Dictation (offline) can be enabled in System Settings
For Voice Control (full hands-free), see Voice Control section
"""
    }

    // MARK: - Flo Tools

    private static var GetFloToolsContent: () -> String = {
        return """
-- What Is Flo Tools --
>> Flo Tools is a free accessibility plugin for Pro Tools providing enhanced VoiceOver and screen reader support on Mac.
>> It adds spoken feedback for meters, track states, and session info that Pro Tools does not expose natively to VoiceOver.
>> Download from: flotools.org

-- Installation --
>> Download the installer from flotools.org, run it with Pro Tools closed, then launch Pro Tools — VoiceOver will announce "Flo Tools loaded."

-- Flo Tools Modifier Key --
>> All Flo Tools commands use a dedicated modifier chord: hold Ctrl + Shift + Option, then press a command key.
Ctrl + Shift + Option (+ key): Flo Tools modifier :: Hold this chord, then press a command key to trigger any Flo Tools action

-- Track Navigation --
>> Navigate between tracks using arrow keys combined with the Flo Tools modifier.
Ctrl + Shift + Option + Up: Move focus to track above :: Moves keyboard focus to the track above in the session
Ctrl + Shift + Option + Down: Move focus to track below :: Moves keyboard focus to the track below in the session
Ctrl + Shift + Option + Home: Jump to first track :: Moves focus directly to the topmost track in the session
Ctrl + Shift + Option + End: Jump to last track :: Moves focus directly to the bottommost track in the session
Ctrl + Shift + Option + F: Find track by name :: Opens a prompt to type a track name and jump to it

-- Reading Track Information --
>> Read back track properties that VoiceOver cannot access natively in Pro Tools.
Ctrl + Shift + Option + T: Speak current track name and type :: Announces the track name and its type (audio, MIDI, aux, etc.)
Ctrl + Shift + Option + V: Speak track volume fader value :: Announces the current fader level in dB
Ctrl + Shift + Option + P: Speak track pan position :: Announces the stereo pan position of the track
Ctrl + Shift + Option + M: Speak track mute state :: Announces whether the track is muted or unmuted
Ctrl + Shift + Option + S: Speak track solo state :: Announces whether the track is currently soloed
Ctrl + Shift + Option + R: Speak track record arm state :: Announces whether the track is armed for recording
Ctrl + Shift + Option + I: Speak track input assignment :: Announces the hardware input routed to the track
Ctrl + Shift + Option + O: Speak track output assignment :: Announces the hardware output the track is routed to

-- Meter Reading --
>> Monitor audio levels on any track with spoken meter readouts.
Ctrl + Shift + Option + L: Speak current level on focused track :: Announces the live meter level in dB
Ctrl + Shift + Option + K: Speak peak level and hold value :: Announces the peak meter reading held since last clear
Ctrl + Shift + Option + C: Clear peak hold on focused track :: Resets the peak hold meter to prepare for a new reading

-- Playback & Transport --
>> Get spoken feedback on playback state and cursor position during a session.
Ctrl + Shift + Option + Space: Speak current transport state :: Announces whether Pro Tools is playing, stopped, or recording
Ctrl + Shift + Option + G: Speak current playhead position (timecode) :: Announces the playhead location as hours:minutes:seconds:frames
Ctrl + Shift + Option + E: Speak selection start and end points :: Announces the in and out points of the current selection
Ctrl + Shift + Option + D: Speak session duration :: Announces the total length of the open session

-- Inserts & Sends --
>> Check which plugins and sends are loaded on the focused track.
Ctrl + Shift + Option + 1–5: Speak insert slot 1–5 on focused track :: Announces the plugin name in each insert slot
Ctrl + Shift + Option + 6–9: Speak send slot 1–4 on focused track :: Announces the destination and level of each send

-- Session Info --
>> Read back global session properties with a single keystroke.
Ctrl + Shift + Option + W: Speak session sample rate and bit depth :: Announces the current audio format settings for the session
Ctrl + Shift + Option + B: Speak buffer size setting :: Announces the hardware buffer size in samples
Ctrl + Shift + Option + N: Speak total track count in session :: Announces how many tracks exist in the open session

-- Mix Window Focus --
>> Switch VoiceOver focus between the Mix and Edit windows.
Ctrl + Shift + Option + X: Move VoiceOver focus to Mix window :: Brings the VoiceOver cursor to the Mix window for fader access
Ctrl + Shift + Option + Z: Move VoiceOver focus to Edit window :: Brings the VoiceOver cursor to the Edit window for clip editing

-- Notes --
>> Flo Tools works alongside standard Pro Tools and VoiceOver shortcuts.
>> Always run Flo Tools with VoiceOver active — press Cmd + F5 to toggle VoiceOver on or off.
>> Visit flotools.org for the latest installer, changelog, and full documentation.
"""
    }

    // MARK: - PTAccess

    private static var GetPTAccessContent: () -> String = {
        return """
-- What Is PTAccess --
>> PTAccess is a free tutorial and resource site for blind and low-vision users learning Pro Tools with a screen reader on Mac.
>> It covers session setup, recording, editing, and mixing using VoiceOver and Flo Tools.
>> Visit: ptaccess.org

-- Recommended Setup --
>> Configure these tools and settings before starting a Pro Tools session with PTAccess workflows.
VoiceOver: Toggle on/off :: Cmd + F5
Flo Tools: Install from flotools.org :: Required for accessible track navigation and metering
VoiceOver Verbosity: Set to Medium :: Configure in VoiceOver Utility → Verbosity
VoiceOver Cursor: Enable keyboard focus tracking :: Turn on "Move VoiceOver cursor with keyboard focus" in VoiceOver Utility

-- PTAccess Core Workflow --
>> PTAccess recommends this five-step workflow for every session.
>> Step 1: Launch Pro Tools with VoiceOver active (Cmd + F5).
>> Step 2: Create or open a session (Cmd + N or Cmd + O).
>> Step 3: Use Flo Tools commands to navigate tracks and check states.
>> Step 4: Use standard Pro Tools shortcuts for transport and editing.
>> Step 5: Use Flo Tools meter reading commands to monitor levels while mixing.

-- Navigating Pro Tools Windows --
>> Switch between the Edit and Mix windows and move the VoiceOver cursor within them.
Cmd + =: Toggle Edit and Mix windows :: Switches between the Edit window (waveform view) and the Mix window (channel strips)
Cmd + 1: Transport window :: Shows or hides the Transport floating window
Tab: Move to next control in focused window :: Cycles through interactive UI elements
Shift + Tab: Move backward through controls :: Moves focus to the previous interactive element
VO + Right: Move VoiceOver cursor right :: Moves the VoiceOver cursor to the next item (VO = Ctrl + Option)
VO + Left: Move VoiceOver cursor left :: Moves the VoiceOver cursor to the previous item

-- Creating Tracks (PTAccess Method) --
>> Use the New Track dialog and navigate its fields with Tab and arrow keys.
Shift + Cmd + N: New Track dialog :: Opens the dialog to create new audio, MIDI, or aux tracks
Tab: Move between fields in dialog :: Cycles through track type, count, and format fields
Up / Down: Change track type or count :: Adjusts the value of the focused field in the dialog
Return: Confirm and create tracks :: Creates the tracks and closes the dialog

-- Recording (PTAccess Method) --
>> Arm tracks with Flo Tools feedback, then use standard Pro Tools record shortcuts.
Ctrl + Shift + Option + R: Check record arm state via Flo Tools :: Flo Tools speaks whether the track is armed
Cmd + Shift + K: Record arm / disarm focused track :: Toggles record arm on the currently focused track
3 (numpad): Play from selection :: Begins playback from the current selection start point
F12: Record :: Starts recording on all armed tracks
Space: Stop :: Stops playback or recording
Cmd + Z: Undo last take :: Removes the most recently recorded region

-- Editing With Screen Reader --
>> Use Tab and Flo Tools position readouts to navigate the timeline without the mouse.
Tab: Jump to next region boundary :: Moves the edit cursor to the next region start or end point
Ctrl + Shift + Option + G: Speak current cursor position :: Flo Tools announces the playhead timecode location
Cmd + E: Separate region at playhead :: Splits the selected region at the current edit cursor position
Cmd + H: Heal separation :: Merges two adjacent regions back together
Cmd + J: Consolidate selection :: Renders the current selection into a single new region
B (with Trim tool): Trim to selection :: Trims the region boundary to the edge of the current selection

-- Mixing (PTAccess Method) --
>> Use Flo Tools readouts to monitor faders and pans, and Option-click to reset them.
Ctrl + Shift + Option + V: Speak fader value (Flo Tools) :: Announces the current volume level of the focused track in dB
Ctrl + Shift + Option + P: Speak pan position (Flo Tools) :: Announces the stereo pan position of the focused track
Option + Click fader: Reset fader to unity gain :: Snaps the fader to 0.0 dB
Option + Click pan: Reset pan to center :: Snaps the pan knob to center
Ctrl + Shift + Option + L: Speak current meter level :: Announces the live input or output meter reading in dB

-- Keyboard Focus Tips --
>> The VoiceOver modifier key (VO) is Ctrl + Option by default on Mac.
>> Use VO + Shift + Down to enter (interact with) the focused UI element.
>> Use VO + Shift + Up to stop interacting and return to the parent container.
>> Use VO + Space to activate the focused button or control.

-- Learning Resources --
>> These sites provide full tutorials, audio demos, and community support for accessible Pro Tools use.
ptaccess.org: Full tutorials, audio demos, and accessible workflows :: Primary resource for blind Pro Tools users
flotools.org: Flo Tools download and documentation :: Required plugin for accessible Pro Tools on Mac
pro.audio/accessibility: Community forum for accessible audio production :: Connect with other blind and low-vision producers
"""
    }

    private static var GetContactContent: () -> String = {
        return """
-- About BeaconMac --
>> BeaconMac is a native macOS keyboard shortcuts reference tool built by EyeTech Analytics.
>> Press your hotkey from any app and a searchable guide panel appears instantly — no mouse required.

-- Contact & Support --
>> Reach EyeTech Analytics for questions, feedback, or support.
Company: EyeTech Analytics :: The team behind BeaconMac
Phone: (859) 212-3668 :: Call or text for support
Email: beacon@eyetechanalytics.com :: Email for bug reports and feature requests
Website: https://eyetechanalytics.com/projects/ :: Project page with updates and resources

-- Customizing --
>> Customize BeaconMac's hotkey or content by editing the source files and rebuilding.
Change hotkey: Ctrl + F8 → BeaconMac ⌨ icon → Cmd + , :: Ctrl + F8 focuses the menu bar; arrow to BeaconMac and press Cmd + , to open Preferences
Add a guide: Edit ShortcutContent.swift and rebuild :: Add a new GetXxxContent function and register it in the guide list
Add an app mapping: Edit AppDetector.swift and rebuild :: Map a bundle identifier to the appropriate guide

-- Building from Source --
>> Run the build script from the BeaconMac-Swift project directory.
cd BeaconMac-Swift && ./build-app.sh: Build the app :: Compiles and packages BeaconMac into a runnable .app bundle

-- System Requirements --
>> BeaconMac requires macOS Monterey or later and Accessibility permission to detect the active app.
macOS: 12.0 Monterey or later :: Minimum supported operating system version
Accessibility: Grant in System Settings → Privacy & Security → Accessibility :: Required to detect the frontmost app

-- License --
>> BeaconMac is distributed under the MIT License — free to use, modify, and distribute.
>> See the LICENSE file included with the source code for full terms.
>> Copyright (c) 2025 EyeTech Analytics
"""
    }

    // MARK: - Slack

    private static var GetSlackContent: () -> String = {
        return """
-- Navigation --
>> Jumping between channels, DMs, and views in Slack.
Cmd + K: Quick Switch — jump to any channel or DM :: Opens the quick switcher to find any conversation
Cmd + Shift + K: Browse all channels :: Opens the full channel directory
Cmd + N: New direct message :: Opens a new DM compose window
Cmd + F: Search :: Opens the Slack search bar
Cmd + G: Jump to date in current channel :: Opens a calendar to jump to a specific date
Cmd + [: Go back :: Navigates back in the channel/view history
Cmd + ]: Go forward :: Navigates forward in the channel/view history
Alt + Up: Previous channel / DM :: Moves focus to the channel or DM above in the sidebar
Alt + Down: Next channel / DM :: Moves focus to the channel or DM below in the sidebar
Cmd + Shift + M: Open Mentions & Reactions :: Shows all your mentions and emoji reactions
Cmd + Shift + E: Open All DMs :: Shows the list of all direct message conversations
Cmd + Shift + A: Open All Unreads :: Shows all unread messages across all channels
Cmd + Shift + T: Open Threads :: Opens the Threads panel with all thread replies

-- Messaging --
>> Composing and sending messages in Slack channels and DMs.
Cmd + Return: Send message (in multi-line compose) :: Sends the message when the compose box is expanded
Return: Send message (standard compose) :: Sends the message in the default compose mode
Shift + Return: Insert new line in message :: Inserts a line break without sending
Up arrow: Edit last message sent :: Opens your last sent message for editing
Cmd + Shift + /: Open keyboard shortcuts list :: Displays the full Slack shortcut reference

-- Text Formatting --
>> Applying formatting to text in Slack messages.
Cmd + B: Bold :: Wraps selected text in bold markdown
Cmd + I: Italic :: Wraps selected text in italic markdown
Cmd + Shift + X: Strikethrough :: Wraps selected text in strikethrough markdown
Cmd + Shift + C: Inline code :: Wraps selected text in backtick inline code formatting
Cmd + Option + Shift + C: Code block :: Wraps selected text in a triple-backtick code block
Cmd + Shift + 7: Ordered (numbered) list :: Formats the text as a numbered list
Cmd + Shift + 8: Bullet list :: Formats the text as a bulleted list
Cmd + Shift + 9: Blockquote :: Formats the text as a blockquote
>: Blockquote shorthand (type > at line start) :: Typing > at the start of a line creates a blockquote

-- Reactions & Actions --
>> Reacting to messages and starring content.
Cmd + Shift + \\: React to last message :: Opens the emoji picker to react to the last message
E: Open emoji picker for reaction (on hovered message) :: Adds an emoji reaction to a hovered message
Cmd + Shift + S: Star / save a message :: Saves the message to your Saved Items list

-- Calls & Huddles --
>> Starting and controlling Slack voice calls and Huddles.
Cmd + Shift + H: Start or join a Huddle :: Starts or joins an audio Huddle in the current channel
M: Mute / unmute microphone (in Huddle / call) :: Toggles your mic during a Huddle or call
V: Turn camera on / off (in Huddle / call) :: Toggles your camera during a Huddle or call

-- Other --
>> Miscellaneous app-level shortcuts for preferences and zoom.
Cmd + ,: Preferences :: Opens the Slack Preferences dialog
Cmd + +: Zoom in :: Increases the Slack interface text size
Cmd + -: Zoom out :: Decreases the Slack interface text size
Cmd + 0: Reset zoom :: Resets the Slack interface zoom to default
Escape: Close panel / dismiss dialog :: Closes the current panel or dismisses a dialog
Cmd + W: Close window :: Closes the current Slack window

-- VoiceOver Tips (Slack) --
>> Slack's desktop app has reasonable VoiceOver support; the web app (in Safari) also works well.
>> VoiceOver reads channel names, message content, and sender names when navigating the message list.
VO + Shift + Down: Interact with message list :: Enters the message area to read individual messages
VO + Right / Left: Move between messages in thread :: Navigate message by message in a channel
VO + Spacebar: Activate focused item :: Opens or activates a focused channel, link, or button
Cmd + K: Quick switcher :: Type a channel or person name; VO reads results as you type
Alt + Up / Down: Move between channels in sidebar :: VO announces channel name and unread count
>> Unread channels are announced with "unread" when navigated to in the sidebar.
>> To react to a message: focus the message, press Tab to reach the action buttons, then use emoji picker.
>> In Huddles, M mutes/unmutes — VO announces the toggle state.
>> The Slack web app in Safari can be used with the Web Rotor (VO+U) to navigate by headings/links.
"""
    }

    // MARK: - Visual Studio Code

    private static var GetVSCodeContent: () -> String = {
        return """
-- File & Window --
>> Managing files, editors, and the VS Code window.
Cmd + P: Quick Open (go to file) :: Opens the file picker to jump to any file in the workspace
Cmd + Shift + P: Command Palette :: Opens the command palette to run any VS Code action
Cmd + N: New untitled file :: Creates a new untitled editor tab
Cmd + W: Close active editor tab :: Closes the current editor tab
Cmd + S: Save :: Saves the active file
Cmd + Shift + S: Save As :: Saves the active file with a new name or location
Cmd + K  Cmd + W: Close all editors :: Closes every open editor tab
Cmd + Shift + T: Reopen last closed editor :: Reopens the most recently closed file
Cmd + ,: Open Settings :: Opens the VS Code Settings editor
Cmd + K  Cmd + S: Open Keyboard Shortcuts :: Opens the keyboard shortcuts editor
Ctrl + `: Toggle integrated terminal :: Shows or hides the built-in terminal panel
Cmd + B: Toggle sidebar visibility :: Shows or hides the left sidebar panel

-- Editing --
>> Writing and manipulating code and text in the editor.
Cmd + X: Cut line (no selection required) :: Cuts the entire current line if nothing is selected
Cmd + C: Copy line (no selection required) :: Copies the entire current line if nothing is selected
Cmd + Z: Undo :: Reverses the last editing action
Cmd + Shift + Z: Redo :: Re-applies the last undone action
Cmd + D: Add next occurrence of word to selection :: Adds the next matching word to the multi-selection
Cmd + Shift + L: Select all occurrences of current word :: Selects every occurrence of the word under the cursor
Cmd + L: Select current line :: Selects the entire current line
Cmd + Shift + K: Delete line :: Deletes the current line entirely
Cmd + Enter: Insert blank line below :: Inserts a new line below without moving the cursor up
Cmd + Shift + Enter: Insert blank line above :: Inserts a new line above the current line
Option + Down: Move line down :: Moves the current line or selection down by one line
Option + Up: Move line up :: Moves the current line or selection up by one line
Option + Shift + Down: Copy line down :: Duplicates the current line below
Option + Shift + Up: Copy line up :: Duplicates the current line above
Cmd + /: Toggle line comment :: Comments or uncomments the current line
Option + Shift + A: Toggle block comment :: Wraps or unwraps the selection in a block comment
Option + Click: Insert extra cursor at click point :: Adds an additional cursor at the clicked position
Cmd + Option + Down: Add cursor below :: Adds a cursor on the line below for multi-line editing
Cmd + Option + Up: Add cursor above :: Adds a cursor on the line above for multi-line editing
Cmd + U: Undo last cursor operation :: Removes the last added cursor in a multi-cursor session
Tab / Shift + Tab: Indent / outdent selected lines :: Increases or decreases indentation

-- Navigation --
>> Moving through code files, symbols, and the workspace.
Cmd + G: Go to line number :: Opens a prompt to jump to a specific line number
Cmd + Shift + O: Go to symbol in file :: Opens the symbol picker for the current file
Cmd + T: Go to symbol in workspace :: Opens the global symbol search across the project
F12: Go to definition :: Jumps to the definition of the symbol under the cursor
Option + F12: Peek definition (inline) :: Shows the definition inline without leaving the current file
Shift + F12: Find all references :: Lists all references to the symbol across the project
Ctrl + Shift + M: Toggle Problems panel :: Shows or hides the Errors and Warnings panel
Ctrl + Tab: Switch between open files :: Cycles through recently opened editor tabs
Cmd + 1 / 2 / 3: Focus editor group 1 / 2 / 3 :: Moves keyboard focus to the first, second, or third editor group
Cmd + \\: Split editor :: Opens a second editor panel beside the current one
Ctrl + Cmd + Left: Navigate back in history :: Goes back to the previous cursor location in history
Ctrl + Cmd + Right: Navigate forward in history :: Goes forward to the next cursor location in history

-- Search & Replace --
>> Finding and replacing text within files or across the project.
Cmd + F: Find in file :: Opens the Find bar to search within the current file
Cmd + H: Replace in file :: Opens the Replace bar in the current file
Cmd + Shift + F: Search across workspace :: Opens the global search panel for the whole project
Cmd + Shift + H: Replace across workspace :: Opens the global find and replace panel
Option + Return: Select all matches of search term :: Selects every occurrence of the search term

-- Code Intelligence --
>> Using IntelliSense, quick fixes, and automatic code actions.
Ctrl + Space: Trigger IntelliSense / autocomplete :: Manually shows the autocomplete suggestions popup
Cmd + .: Quick fix / code actions :: Shows available code actions and quick fixes for the cursor position
F2: Rename symbol :: Renames the symbol under the cursor across all files
Option + Shift + F: Format document :: Runs the formatter on the entire document
Cmd + K  Cmd + F: Format selection :: Runs the formatter on the selected code only

-- Debugging --
>> Running and stepping through code in the VS Code debugger.
F5: Start / Continue debugging :: Starts a debug session or continues execution to the next breakpoint
Shift + F5: Stop debugging :: Terminates the current debug session
F9: Toggle breakpoint :: Adds or removes a breakpoint on the current line
F10: Step over :: Executes the current line and stops at the next one
F11: Step into :: Steps into a function call on the current line
Shift + F11: Step out :: Executes the rest of the current function and stops at the caller

-- Git / Source Control --
>> Accessing the source control panel in VS Code.
Cmd + Shift + G: Open Source Control panel :: Opens the Git/source control view in the sidebar

-- VoiceOver & Accessibility (VS Code) --
>> VS Code has a dedicated screen reader / accessibility mode with enhanced announcements.
>> Enable accessibility mode: open Command Palette (Cmd+Shift+P) → type "Enable Accessibility Mode" → Enter.
>> Or set "editor.accessibilitySupport": "on" in settings.json to always use accessible mode.
F1 / Cmd + Shift + P: Command Palette :: Most features are keyboard-accessible via the Command Palette
Tab: Move between main UI regions :: Moves between editor, sidebar, panel, and status bar
Cmd + Shift + E: Explorer panel :: Navigate the file tree with arrow keys; Enter to open
Cmd + Shift + F: Search panel :: Accessible find panel; Tab through results
Ctrl + G: Go to line :: Jump to any line without needing to see the scroll position
>> In accessible mode, the editor announces line content, errors, and completions via VoiceOver.
>> Error announcements: VS Code reads inline diagnostics automatically when you move to an error line.
>> Use F8 / Shift+F8 to cycle through errors and warnings — VO announces each one.
F8: Go to next error or warning :: Moves cursor to the next problem; VO reads the message
Shift + F8: Go to previous error or warning :: Moves cursor to the previous problem
>> The integrated terminal may be hard for VO — consider using an external Terminal window instead.
>> Tab focus trapping: Ctrl+Shift+M toggles whether Tab indents code or moves focus out of the editor.
Ctrl + Shift + M: Toggle Tab key trap :: Switches Tab between indenting code and moving UI focus
"""
    }

    // MARK: - Xcode

    private static var GetXcodeContent: () -> String = {
        return """
-- Build & Run --
>> Building, running, and testing your app in Xcode.
Cmd + B: Build :: Compiles the current scheme without running it
Cmd + R: Run :: Builds and runs the app on the selected simulator or device
Cmd + .: Stop running / building :: Cancels the current build or stops the running app
Cmd + Shift + B: Analyze (static analyzer) :: Runs the Clang static analyzer on the code
Cmd + U: Run all tests :: Runs the entire test suite for the current scheme
Cmd + Ctrl + U: Run tests in current file :: Runs only the tests in the active test file
Cmd + Shift + K: Clean build folder :: Deletes all build artifacts and intermediate files
Cmd + K: Clear console output :: Clears the debug console output area

-- Navigation --
>> Jumping to files, symbols, and navigating the Xcode workspace.
Cmd + Shift + O: Open Quickly (file, symbol, or type) :: Opens the quick-open dialog for instant file/symbol access
Cmd + 0: Show / hide Navigator panel :: Toggles the left navigator sidebar
Cmd + Option + 0: Show / hide Inspector panel :: Toggles the right inspector sidebar
Cmd + Shift + Y: Show / hide Debug area :: Toggles the debug console panel at the bottom
Cmd + 1–9: Switch Navigator tab (Files, Search, etc.) :: Switches between navigator panel tabs
Ctrl + 6: Current file method / function list popup :: Shows a popup list of all functions in the current file
Ctrl + 1: Recent files in jump bar :: Shows recently opened files in the jump bar
Ctrl + Cmd + Left: Navigate back :: Goes back in the navigation history
Ctrl + Cmd + Right: Navigate forward :: Goes forward in the navigation history
Cmd + L: Go to line number :: Opens a dialog to jump to a specific line in the current file
Cmd + J: Jump to definition :: Navigates to the definition of the selected symbol
Cmd + Option + J: Filter in Navigator search field :: Moves focus to the Navigator search bar

-- Editing --
>> Writing, commenting, and refactoring code in the Xcode editor.
Cmd + /: Toggle comment :: Comments or uncomments the selected lines
Cmd + [: Indent left :: Decreases the indentation of selected lines
Cmd + ]: Indent right :: Increases the indentation of selected lines
Ctrl + I: Re-indent selected code :: Re-applies automatic indentation to the selected code
Cmd + Option + [: Move line up :: Moves the current line or selection up by one line
Cmd + Option + ]: Move line down :: Moves the current line or selection down by one line
Cmd + F: Find in file :: Opens the in-file search bar
Cmd + Shift + F: Find in workspace :: Opens the global project-wide search
Cmd + Option + F: Find and replace :: Opens find and replace in the current file
Cmd + Option + Shift + F: Find and replace in workspace :: Opens project-wide find and replace
Cmd + E: Use selection for find :: Loads the selected text into the find field
Cmd + G: Find next :: Finds the next occurrence of the search term
Cmd + Shift + G: Find previous :: Finds the previous occurrence
Escape: Show completions / close completion popup :: Shows code completions or closes the popup
Ctrl + Space: Force show completions :: Forces the autocomplete popup to appear

-- Debugging --
>> Setting breakpoints and controlling execution in the debugger.
Cmd + Y: Enable / disable breakpoint at cursor :: Toggles the breakpoint on the current line
Cmd + Shift + Y: Toggle all breakpoints on / off :: Enables or disables all project breakpoints
F6: Step over :: Executes the current line and stops at the next one
F7: Step into :: Steps inside a function call on the current line
F8: Step out :: Finishes the current function and stops at the caller
Ctrl + Cmd + Y: Continue execution :: Resumes execution until the next breakpoint
F5: Continue execution (alternate) :: Alternative shortcut to resume execution

-- Interface Builder --
>> Working with Storyboards and XIB files in Interface Builder.
Cmd + =: Size to fit content :: Resizes the selected view to fit its content
Option + Drag: Duplicate selected control :: Holds Option while dragging to create a copy
Cmd + Option + Return: Open Assistant editor :: Opens the assistant editor alongside the canvas
Cmd + Return: Return to Standard editor :: Closes the assistant editor and shows the standard view

-- Version Control --
>> Accessing Xcode's built-in source control features.
Cmd + Option + C: Commit changes :: Opens the commit dialog to commit staged changes
Cmd + Shift + A: Open Changes navigator :: Shows the Source Control Changes navigator
"""
    }

    // MARK: - Apple Pages

    private static var GetPagesContent: () -> String = {
        return """
-- Document --
>> File management commands for Apple Pages documents.
Cmd + N: New document :: Opens the template chooser to create a new document
Cmd + O: Open document :: Opens the file browser to select an existing document
Cmd + S: Save :: Saves the current document
Cmd + Shift + S: Save As / Duplicate :: Saves a copy under a new name or location
Cmd + P: Print :: Opens the print dialog for the current document
Cmd + W: Close document :: Closes the current document; prompts to save if unsaved
Cmd + Z: Undo :: Reverses the last action
Cmd + Shift + Z: Redo :: Re-applies the last undone action

-- Editing --
>> Cut, copy, paste, search, and deletion in Pages documents.
Cmd + X: Cut :: Removes the selection and places it on the clipboard
Cmd + C: Copy :: Copies the selection to the clipboard
Cmd + V: Paste :: Inserts clipboard content at the cursor
Cmd + Option + Shift + V: Paste and Match Style :: Pastes text matching the destination paragraph style
Cmd + A: Select all :: Selects all content in the document
Cmd + F: Find :: Opens the Find bar to search document text
Cmd + G: Find next :: Finds the next occurrence of the search term
Cmd + Shift + G: Find previous :: Finds the previous occurrence
Cmd + H: Find and replace :: Opens the Find and Replace dialog
Delete: Delete selection / character left :: Removes the selection or the character to the left
Fn + Delete: Delete character right :: Removes the character to the right of the cursor
Cmd + Delete: Delete to beginning of line :: Deletes from the cursor to the start of the line
Option + Return: Insert line break (soft return) :: Inserts a line break without starting a new paragraph
Cmd + Return: Insert page break :: Inserts a manual page break at the cursor

-- Text Formatting --
>> Applying character and paragraph styles in Pages.
Cmd + B: Bold :: Toggles bold on selected text
Cmd + I: Italic :: Toggles italic on selected text
Cmd + U: Underline :: Toggles underline on selected text
Cmd + Shift + D: Strikethrough :: Applies strikethrough to selected text
Cmd + Shift + {: Align left :: Left-aligns the current paragraph
Cmd + Shift + }: Align right :: Right-aligns the current paragraph
Cmd + |: Center align :: Centers the current paragraph
Cmd + Option + |: Justify align :: Justifies both sides of the current paragraph
Cmd + T: Show / hide Fonts panel :: Opens or closes the Font panel
Cmd + Shift + C: Show / hide Colors panel :: Opens or closes the Colors picker
Cmd + K: Add / edit hyperlink :: Opens the Add Link dialog
Tab: Indent list item :: Indents the current list item one level deeper
Shift + Tab: Outdent list item :: Outdents the current list item one level

-- Navigation --
>> Moving the cursor within a Pages document.
Cmd + Home: Go to beginning of document :: Moves the cursor to the very start
Cmd + End: Go to end of document :: Moves the cursor to the very end
Cmd + Up: Move to start of paragraph :: Jumps the cursor to the beginning of the paragraph
Cmd + Down: Move to end of paragraph :: Jumps the cursor to the end of the paragraph
Option + Left: Move one word left :: Moves the cursor one word to the left
Option + Right: Move one word right :: Moves the cursor one word to the right
Cmd + Left: Move to beginning of line :: Jumps to the start of the current line
Cmd + Right: Move to end of line :: Jumps to the end of the current line

-- View --
>> Adjusting the zoom and interface layout in Pages.
Cmd + +: Zoom in :: Increases the document zoom level
Cmd + -: Zoom out :: Decreases the document zoom level
Cmd + 0: Actual size (100%) :: Resets the zoom to 100%
Cmd + Shift + F: Enter / exit full-screen :: Toggles full-screen editing mode
Cmd + Option + I: Show / hide Format panel (sidebar) :: Toggles the right-side formatting sidebar
Cmd + Shift + L: Show / hide document sidebar :: Toggles the document structure sidebar

-- VoiceOver Tips (Pages) --
>> Pages works well with VoiceOver for text editing; sidebar panels may require Tab to navigate.
>> Use heading styles to create structure VoiceOver users can navigate by heading (Cmd+Option+1/2/3).
F6: Move focus between toolbar, sidebar, and document :: Cycles keyboard focus between major areas
Tab: Move between controls in sidebar :: Navigates buttons and fields in the Format inspector
>> VO will read the cursor position, current paragraph style, and character count as you type.
>> To navigate by heading in the document structure panel: open Cmd+Shift+L, then use arrow keys.
>> When inserting images or shapes, VoiceOver announces object type; use Escape to exit edit mode.
>> Export as PDF (File > Export) to produce a tagged, accessible PDF readable by screen readers.
"""
    }

    // MARK: - Apple Numbers

    private static var GetNumbersContent: () -> String = {
        return """
-- Spreadsheet --
>> File management commands for Apple Numbers spreadsheets.
Cmd + N: New spreadsheet :: Opens the template chooser to create a new spreadsheet
Cmd + O: Open :: Opens the file browser to select an existing spreadsheet
Cmd + S: Save :: Saves the current spreadsheet
Cmd + Shift + S: Save As / Duplicate :: Saves a copy under a new name or location
Cmd + P: Print :: Opens the print dialog
Cmd + W: Close :: Closes the current spreadsheet; prompts to save if unsaved
Cmd + Z: Undo :: Reverses the last action
Cmd + Shift + Z: Redo :: Re-applies the last undone action

-- Cell Navigation --
>> Moving between cells and sheets in Numbers.
Arrow keys: Move one cell in direction :: Moves the active cell one step in any direction
Return: Confirm entry, move down :: Confirms the entry and moves the active cell down
Shift + Return: Confirm entry, move up :: Confirms the entry and moves the active cell up
Tab: Confirm entry, move right :: Confirms the entry and moves the active cell right
Shift + Tab: Confirm entry, move left :: Confirms the entry and moves the active cell left
Cmd + Home: Go to first cell (A1) :: Jumps to the first cell in the spreadsheet
Cmd + End: Go to last used cell :: Jumps to the last cell containing data
Cmd + Arrow: Jump to edge of contiguous data :: Moves to the last non-empty cell in that direction
Option + Page Down: Move to next sheet :: Navigates to the next sheet tab
Option + Page Up: Move to previous sheet :: Navigates to the previous sheet tab

-- Cell Editing --
>> Entering and editing data in Numbers cells.
Return or F2: Begin editing selected cell :: Puts the active cell into edit mode
Escape: Cancel editing (revert cell) :: Discards changes to the current cell
Delete: Clear cell contents :: Removes the data from selected cells
Cmd + D: Fill down from cell above :: Copies the cell above into the selected cells below
Cmd + R: Fill right from cell to left :: Copies the leftmost cell into the selected cells on the right
Option + Return: Insert new line within a cell :: Inserts a line break inside the cell

-- Selection --
>> Selecting ranges, rows, columns, and all cells in Numbers.
Shift + Arrow: Extend selection by one cell :: Adds one cell at a time to the current selection
Cmd + Shift + Arrow: Extend to edge of data :: Extends selection to the edge of a data block
Shift + Space: Select entire row :: Selects the full row of the active cell
Ctrl + Space: Select entire column :: Selects the full column of the active cell
Cmd + A: Select all cells :: Selects every cell in the spreadsheet

-- Formatting --
>> Applying text styles and alignment to cells.
Cmd + B: Bold :: Toggles bold formatting on selected cells
Cmd + I: Italic :: Toggles italic formatting on selected cells
Cmd + U: Underline :: Toggles underline formatting on selected cells
Cmd + Shift + {: Align left :: Left-aligns content in selected cells
Cmd + Shift + }: Align right :: Right-aligns content in selected cells
Cmd + |: Center align :: Centers content in selected cells
Cmd + T: Show Fonts panel :: Opens the Font panel for font selection
Cmd + 1: Open Format panel :: Opens the right-side cell formatting panel

-- Rows, Columns & Sheets --
>> Inserting and managing rows, columns, and sheets.
Option + Up: Insert row above selected :: Adds a new row above the selected row
Option + Down: Insert row below selected :: Adds a new row below the selected row
Option + Left: Insert column to left :: Adds a new column to the left of the selected column
Option + Right: Insert column to right :: Adds a new column to the right of the selected column
Cmd + Option + R: Show / hide row and column headers :: Toggles the row/column header display
>> To add a new sheet: click the + button in the bottom-left corner (no default shortcut)

-- View --
>> Adjusting the zoom and interface panels in Numbers.
Cmd + +: Zoom in :: Increases the spreadsheet zoom level
Cmd + -: Zoom out :: Decreases the spreadsheet zoom level
Cmd + 0: Actual size :: Resets the zoom to 100%
Cmd + Shift + L: Show / hide sidebar :: Toggles the left navigator sidebar
Cmd + Option + I: Show / hide Format panel :: Toggles the right-side format panel

-- VoiceOver Tips (Numbers) --
>> VoiceOver can navigate Numbers cells and read cell content, including formulas.
>> Tab and arrow keys move between cells; VO announces cell address (e.g. "B3") and content.
Tab: Move right and confirm entry :: Use to move through cells; VO announces each cell address
Return: Move down and confirm entry :: Use to move through rows; VO announces the destination
VO + Shift + Down: Enter table area :: Enters the active table for cell-by-cell navigation
VO + Shift + Up: Stop interacting with table :: Exits table focus back to the sheet level
VO + Cmd + Right / Left: Move across row :: Moves cell by cell within the current row
VO + Cmd + Up / Down: Move down a column :: Moves through the current column
VO + C: Read column header :: Announces the header of the current column
VO + R: Read row header :: Announces the header of the current row
>> Use Cmd+1 to open the Format inspector; Tab through fields; VO reads labels and values.
>> Chart axes and labels are announced when focused — use Tab to navigate chart elements.
"""
    }

    // MARK: - Apple Keynote

    private static var GetKeynoteContent: () -> String = {
        return """
-- Slideshow Playback --
>> Controls for presenting a Keynote slideshow in full-screen mode.
Return or P: Play slideshow from current slide :: Starts the slideshow from the selected slide
Option + Return: Play slideshow from first slide :: Starts from slide 1 regardless of selection
Cmd + Shift + Return: Rehearsal mode (with presenter timer) :: Plays with a presenter timer for practice
Escape: End slideshow :: Exits the presentation and returns to the editor
Right arrow / Space: Advance to next slide or build :: Goes forward one slide or animation step
Left arrow / Delete: Go to previous slide or build :: Goes back one slide or animation step
Cmd + Right: Skip to next slide (bypass builds) :: Skips directly to the next slide, ignoring builds
Cmd + Left: Go to previous slide (bypass builds) :: Goes back to the previous slide, ignoring builds
B: Black screen (pause) :: Blacks out the display; press again to resume
W: White screen (pause) :: Whites out the display; press again to resume
F: Freeze on current slide :: Freezes the display on the current slide
C: Show / hide captions :: Toggles closed captions or live captions during presentation
X: Swap presenter and audience displays :: Swaps which screen shows the presenter view
Cmd + L: Laser pointer mode :: Activates the virtual laser pointer during a slideshow

-- Slide Navigator --
>> Navigating and organising slides in the left slide panel.
Up arrow: Select previous slide :: Moves selection to the slide above in the navigator
Down arrow: Select next slide :: Moves selection to the slide below in the navigator
Cmd + Up: Move selected slide up :: Moves the slide up one position in the presentation
Cmd + Down: Move selected slide down :: Moves the slide down one position in the presentation
Shift + Click: Select range of slides :: Selects all slides between the two clicked slides
Cmd + Click: Select non-adjacent slides :: Adds individual slides to the current selection
Cmd + A: Select all slides :: Selects every slide in the presentation
Delete: Delete selected slide(s) :: Removes the selected slide(s) from the presentation

-- Editing Slides --
>> Working with objects and text boxes on individual slides.
Return: Edit text in selected object :: Enters text editing mode inside the selected shape
Escape: Exit text editing :: Exits text editing and selects the object
Tab: Select next object on slide :: Moves focus to the next object in tab order
Shift + Tab: Select previous object on slide :: Moves focus to the previous object
Cmd + A: Select all objects on current slide :: Selects every object on the current slide
Cmd + D: Duplicate selected object :: Creates a copy of the selected object on the slide
Option + Drag: Duplicate and drag copy :: Holds Option while dragging to copy an object
Arrow keys: Nudge selected object (1 pt) :: Moves the object by 1 point in the arrow direction
Shift + Arrow: Nudge object (10 pt) :: Moves the object by 10 points for coarser positioning

-- Object Arrangement --
>> Layering and grouping objects on slides.
Cmd + Option + F: Bring to front :: Moves the selected object to the top of the layer stack
Cmd + Option + B: Send to back :: Moves the selected object to the bottom of the layer stack
Cmd + Option + G: Group selected objects :: Combines selected objects into a single group
Cmd + Option + Shift + G: Ungroup objects :: Breaks the group back into individual objects
Cmd + Option + L: Lock object (prevent movement) :: Prevents the object from being accidentally moved
Cmd + Option + Shift + L: Unlock object :: Removes the movement lock from the object
>> Flip Horizontal / Vertical: use Format sidebar > Arrange tab (no default shortcut assigned)

-- Text Formatting --
>> Applying text styles inside text boxes and placeholders.
Cmd + B: Bold :: Toggles bold on selected text
Cmd + I: Italic :: Toggles italic on selected text
Cmd + U: Underline :: Toggles underline on selected text
Cmd + Shift + D: Strikethrough :: Applies strikethrough to selected text
Cmd + Shift + {: Align left :: Left-aligns text in the text box
Cmd + Shift + }: Align right :: Right-aligns text in the text box
Cmd + |: Center align :: Centers text in the text box
Cmd + K: Add / edit hyperlink :: Opens the Add Link dialog
Cmd + T: Show Fonts panel :: Opens the Font selection panel

-- View & Window --
>> Changing the view mode and interface panels in Keynote.
Cmd + Shift + L: Show / hide Navigator sidebar :: Toggles the slide navigator on the left
Cmd + Option + I: Show / hide Inspector :: Toggles the Format/Animate inspector on the right
Cmd + Option + P: Show / hide Presenter Notes :: Toggles the presenter notes panel at the bottom
Cmd + +: Zoom in :: Increases the slide canvas zoom level
Cmd + -: Zoom out :: Decreases the slide canvas zoom level
Cmd + 0: Fit slide in window :: Scales the slide to fill the available window space
Cmd + 1: Actual size :: Shows the slide at its true 1:1 pixel size
Cmd + Shift + F: Enter / exit full-screen editing :: Toggles full-screen editing mode

-- File --
>> File management commands for Keynote presentations.
Cmd + N: New presentation :: Opens the template chooser to create a new presentation
Cmd + O: Open :: Opens the file browser to select an existing presentation
Cmd + S: Save :: Saves the current presentation
Cmd + Shift + S: Save As / Duplicate :: Saves a copy under a new name or location
Cmd + P: Print / Export PDF :: Opens the print/export dialog
Cmd + W: Close :: Closes the current presentation; prompts to save if unsaved
Cmd + Z: Undo :: Reverses the last action
Cmd + Shift + Z: Redo :: Re-applies the last undone action

-- VoiceOver Tips (Keynote) --
>> Keynote editing is accessible; slideshow presenter mode has limited VoiceOver feedback.
>> Navigate slides in the slide navigator using arrow keys; VO announces the slide title and number.
Tab: Move between objects on the current slide :: VO announces each object's type, position, and content
Return: Enter text editing mode on focused object :: Enters the text box; VO reads the text
Escape: Exit text editing / deselect object :: Returns to slide-level navigation
Cmd + Option + P: Show / hide Presenter Notes :: Toggle notes panel; VO can read and edit notes
>> When running a slideshow, VoiceOver reads the slide title and any text builds automatically.
>> Use Cmd+Shift+Return (Rehearsal mode) to practice — VO announces slide transitions and timing.
>> For accessible exported presentations: File > Export > PowerPoint or PDF with options for accessibility.
>> Slide transitions and animations are not announced by VO during editing, only during playback.
"""
    }

    // MARK: - Messages

    private static var GetMessagesContent: () -> String = {
        return """
-- Composing --
>> Writing and sending iMessage and SMS messages in Apple Messages.
Cmd + N: New message / conversation :: Opens a new compose window to start a conversation
Return: Send message :: Sends the typed message to the current conversation
Shift + Return: Add a new line without sending :: Inserts a line break without sending the message
Cmd + Delete: Delete selected conversation :: Removes the selected conversation from the list
Cmd + Option + Shift + T: Send with effect picker :: Opens the message effect selector (Slam, Loud, Gentle, etc.)

-- Formatting --
>> Applying text styles to message content.
Cmd + B: Bold :: Toggles bold on selected text in the message field
Cmd + I: Italic :: Toggles italic on selected text
Cmd + U: Underline :: Toggles underline on selected text
Cmd + Shift + S: Strikethrough :: Applies strikethrough formatting to selected text
Cmd + Shift + M: Monospace / inline code :: Applies monospace formatting to selected text

-- Navigation --
>> Finding messages and moving between conversations.
Cmd + F: Search messages :: Opens the search bar to find messages by text
Cmd + Up: Scroll to top of conversation :: Jumps to the oldest messages in the current conversation
Cmd + Down: Scroll to bottom (latest) :: Jumps to the most recent messages in the conversation
Option + Up: Move to previous conversation :: Moves focus to the conversation above in the list
Option + Down: Move to next conversation :: Moves focus to the conversation below in the list
Cmd + K: Mark conversation as read :: Marks the selected conversation as read
Cmd + Option + Up / Down: Navigate conversation list :: Moves between conversations in the sidebar
Escape: Dismiss notification banner :: Closes an incoming message notification banner

-- Actions on Conversations --
>> Managing conversations and notifications.
Cmd + Shift + N: New message (from any view) :: Opens a compose window regardless of current focus
Cmd + Shift + M: Mute / unmute notifications for conversation :: Toggles notification muting for the focused conversation
Cmd + I: Show details for conversation :: Opens the conversation details panel (participants, shared files, etc.)

-- VoiceOver Tips (Messages) --
>> Messages is navigable with VoiceOver using standard panel-switching and list navigation.
Tab: Move between conversation list and message area :: Cycles keyboard focus between the sidebar and message thread
VO + Shift + Down: Enter conversation list :: Interacts with the list to navigate individual conversations
VO + Right / Left: Navigate messages in the thread :: Moves through individual messages in the current conversation
VO + A: Read conversation continuously :: Reads all messages from the current position downward
VO + Spacebar: Activate focused conversation :: Opens the focused conversation
>> Messages announces sender name and message content for each message automatically.
>> Use Cmd+F to search — VoiceOver reads search results as you type.
"""
    }

    // MARK: - FaceTime

    private static var GetFaceTimeContent: () -> String = {
        return """
-- During a Call --
>> Controls for audio, video, and display during a FaceTime call.
Cmd + Shift + M: Mute / unmute microphone :: Toggles your microphone on or off during the call
Cmd + Shift + V: Turn camera on / off :: Toggles your webcam on or off during the call
Cmd + Shift + F: Enter / exit full screen :: Toggles full-screen mode for the call
Cmd + Plus: Increase tile size :: Makes the video tile of a participant larger
Cmd + Minus: Decrease tile size :: Makes the video tile of a participant smaller

-- Before / After a Call --
>> Starting and managing FaceTime calls.
Cmd + N: New FaceTime call :: Opens a new call window to start a FaceTime call
Return: Answer incoming call :: Accepts an incoming FaceTime call
Delete: Remove selected recent call from list :: Removes the focused call from the Recents list
Escape: Decline call / exit full screen :: Declines an incoming call or exits full-screen mode

-- In-Call Extras --
>> Additional features available during an active FaceTime call.
Cmd + Option + P: Take a Live Photo during call :: Captures a Live Photo of the current video call
Cmd + Shift + H: SharePlay — share content :: Opens the SharePlay menu to watch/listen together
Cmd + Option + F: Focus video tile :: Enlarges the selected participant's tile to full view

-- Call Management --
>> Managing FaceTime call history and audio settings.
Cmd + 1: FaceTime tab :: Switches to the main FaceTime view
Cmd + 2: Recents tab :: Switches to the Recents call list
Cmd + 3: Contacts tab :: Switches to the contacts list for starting a call
Cmd + Shift + A: Audio-only call :: Places a FaceTime audio call instead of video
Cmd + Ctrl + F: Enter / exit full screen :: Alternative full-screen toggle
"""
    }

    // MARK: - Reminders

    private static var GetRemindersContent: () -> String = {
        return """
-- Creating & Editing --
>> Adding, editing, and completing reminders in Apple Reminders.
Cmd + N: New reminder in current list :: Adds a new reminder to the currently selected list
Return: Save and add another reminder below :: Saves the current reminder and opens a new one below
Shift + Return: Add a note/detail to the selected reminder :: Opens the notes field for the reminder
Space: Mark selected reminder complete / incomplete :: Toggles the completion checkbox
Delete: Delete selected reminder :: Removes the selected reminder (confirmation may appear)
Cmd + E: Edit selected reminder :: Opens the reminder for detailed editing

-- Lists & Navigation --
>> Moving between reminder lists and searching.
Cmd + F: Search all reminders :: Opens the search bar to find reminders by text
Cmd + 1: Today smart list :: Switches to the Today smart list view
Cmd + 2: Scheduled smart list :: Switches to the Scheduled smart list view
Cmd + 3: All smart list :: Switches to the All reminders view
Cmd + 4: Flagged smart list :: Switches to the Flagged smart list view
Option + Cmd + N: New reminders list :: Creates a new custom reminder list

-- Viewing --
>> Navigating the app history in Reminders.
Cmd + [: Go back :: Navigates back in the app view history
Cmd + ]: Go forward :: Navigates forward in the app view history
"""
    }

    // MARK: - Music (Apple Music)

    private static var GetMusicAppContent: () -> String = {
        return """
-- Playback --
>> Controlling music playback in the Apple Music app.
Space: Play / pause :: Toggles playback of the current track
Cmd + Right: Next track :: Skips to the next track in the queue
Cmd + Left: Previous track (or restart current) :: Goes to the previous track or restarts the current one
Cmd + Up: Volume up :: Increases the Apple Music volume
Cmd + Down: Volume down :: Decreases the Apple Music volume
Option + Cmd + Down: Mute / unmute :: Toggles between muted and the current volume level
Cmd + L: Scroll to currently playing track :: Scrolls the library view to show the playing track

-- Library --
>> Searching, shuffling, and browsing the music library.
Cmd + F: Search library :: Opens the search bar to find songs, albums, or artists
Cmd + R: Toggle shuffle :: Turns shuffle playback on or off
Cmd + T: Toggle repeat :: Cycles through Off, Repeat All, and Repeat One
Cmd + Option + I: Get Info for selected track :: Opens the metadata info panel for the selected track
Cmd + 1: Show Music library :: Switches to the main Music library view
Cmd + Option + G: Reveal currently playing track in library :: Scrolls to show the playing track in the library

-- Mini Player --
>> Minimising Apple Music to a compact player.
Cmd + Shift + M: Switch to mini player :: Toggles the compact mini player view
Cmd + M: Minimize to Dock :: Minimises the Music window to the Dock
"""
    }

    // MARK: - Contacts

    private static var GetContactsAppContent: () -> String = {
        return """
-- Creating & Editing --
>> Adding, editing, and managing contact cards in Apple Contacts.
Cmd + N: New contact :: Creates a new blank contact card
Cmd + Return: Save and finish editing contact :: Saves the contact card and exits edit mode
Escape: Cancel editing :: Discards unsaved changes to the current contact card
Cmd + D: Duplicate selected contact :: Creates a copy of the selected contact
Delete: Delete selected contact (confirmation required) :: Removes the contact after a confirmation prompt

-- Navigation --
>> Searching and moving through the contacts list.
Cmd + F: Search contacts :: Opens the search bar to find contacts by name or field
Cmd + 1: Card view :: Shows contact cards in a single-column view
Cmd + 2: Card and column view :: Shows both the column list and card details side by side
Cmd + 3: List view :: Displays contacts in a compact list
Up / Down: Move through contact list :: Navigates to the contact above or below

-- Sharing & Printing --
>> Exporting and printing contact cards.
Cmd + Shift + P: Print selected contact card :: Prints the selected contact's information
Cmd + Shift + E: Export selected contacts as vCard (.vcf) :: Exports selected contacts as a .vcf file
"""
    }

    // MARK: - iMovie

    private static var GetiMovieContent: () -> String = {
        return """
-- Playback --
>> Controlling playback in the iMovie browser and timeline.
Space: Play / pause :: Toggles playback of the current clip or timeline
L: Play forward (press again to speed up) :: Starts forward playback; press again to increase speed
J: Play backward (press again to speed up) :: Starts reverse playback; press again to increase speed
K: Pause :: Stops playback and holds the current position
Home: Go to beginning of timeline :: Jumps the playhead to the start of the timeline
End: Go to end of timeline :: Jumps the playhead to the end of the timeline

-- Timeline Editing --
>> Cutting, splitting, and managing clips in the iMovie timeline.
Cmd + B: Split clip at playhead :: Cuts the selected clip at the current playhead position
Delete: Delete selected clip (close gap) :: Removes the clip and closes the gap automatically
Cmd + Delete: Delete selected clip (leave gap) :: Removes the clip but leaves the space in the timeline
V: Disable / enable selected clip :: Toggles the clip on or off without removing it
Cmd + Z: Undo :: Reverses the last editing action
Cmd + Shift + Z: Redo :: Re-applies the last undone action

-- Navigation --
>> Moving the playhead and setting selection in/out points.
Left / Right: Move playhead one frame :: Moves the playhead one frame at a time
Shift + Left / Right: Move playhead ten frames :: Moves the playhead ten frames at a time
Up / Down: Previous / next clip :: Jumps the playhead to the start of the previous or next clip
I: Set range start (in point) :: Sets the start of the selection range at the playhead
O: Set range end (out point) :: Sets the end of the selection range at the playhead

-- View --
>> Adjusting the timeline zoom and window layout.
Shift + Z: Fit timeline to window :: Scales the timeline to fit the entire project in view
Cmd + Plus: Zoom in on timeline :: Increases the timeline zoom for more detailed editing
Cmd + Minus: Zoom out on timeline :: Decreases the timeline zoom to see more of the project

-- Audio & Transitions --
>> Adjusting audio and applying transitions in iMovie.
Cmd + T: Add a theme transition :: Inserts a theme-based transition at the playhead
Cmd + Option + T: Add a cross-dissolve transition :: Inserts a cross-dissolve between clips
Ctrl + T: Add a title :: Opens the title browser to add a title to the selected clip
Cmd + Option + I: Inspector :: Opens the clip properties panel
Cmd + Shift + I: Import media :: Opens the media import dialog

-- Sharing & Export --
>> Exporting and sharing the finished movie.
Cmd + E: Export movie :: Opens the Export / Share dialog
Cmd + Shift + E: Share to YouTube / Vimeo :: Opens the web share options
"""
    }

    // MARK: - GarageBand

    private static var GetGarageBandContent: () -> String = {
        return """
-- Playback & Recording --
>> Controlling transport and starting recordings in GarageBand.
Space: Play / stop :: Toggles playback of the current project
Return: Return to beginning :: Moves the playhead back to the start of the project
R: Start / stop recording :: Begins or ends recording on armed tracks
Cmd + Option + N: New track :: Opens the New Track dialog to add a track

-- Timeline Navigation --
>> Moving the playhead and zooming the arrangement view.
Left / Right: Move playhead :: Steps the playhead left or right by the current grid
Cmd + Left: Go to beginning :: Jumps the playhead to the very start of the project
Cmd + Right: Go to end :: Jumps the playhead to the very end of the project
Plus: Zoom in on timeline :: Increases the timeline zoom for detailed editing
Minus: Zoom out on timeline :: Decreases the timeline zoom to see more of the project

-- Editing --
>> Selecting, duplicating, and modifying regions on the timeline.
Cmd + Z: Undo :: Reverses the last editing action
Cmd + Shift + Z: Redo :: Re-applies the last undone action
Cmd + A: Select all regions :: Selects every region on every track
Delete: Delete selected region :: Removes the selected region from the timeline
Cmd + D: Duplicate selected region :: Creates a copy of the selected region
Cmd + J: Join selected regions into one :: Merges selected regions into a single region

-- Views --
>> Switching between GarageBand editor views.
Cmd + 1: Tracks view :: Shows the main arrangement tracks view
Cmd + 3: Smart Controls :: Opens the smart controls panel for the selected track
Cmd + L: Apple Loops Browser :: Opens the Apple Loops browser (O also works)
Cmd + E: Editors :: Opens the editor (Piano Roll / audio) for the selected region
Cmd + 5: Note Pad :: Opens the built-in notepad for project notes
Cmd + 4: Show/hide Mixer :: Toggles the mixer panel

-- Track Management --
>> Creating, managing, and mixing tracks in GarageBand.
Cmd + Option + N: New track :: Opens the New Track dialog
Cmd + Option + Up / Down: Reorder selected track :: Moves the selected track up or down in the list
M: Mute / unmute selected track :: Toggles the mute state of the selected track
S: Solo / unsolo selected track :: Toggles solo mode on the selected track
R (arm): Record-enable selected track :: Arms or disarms the track for recording

-- Cycle & Markers --
>> Setting loop regions and using markers.
C: Toggle Cycle mode (loop region) :: Enables or disables the cycle/loop region for looped playback
Cmd + Option + X: Show/hide Markers track :: Toggles the global markers track at the top
Option + Cmd + M: Add marker at playhead :: Inserts a marker at the current playhead position

-- MIDI & Notes --
>> Working in the Piano Roll and Step Sequencer.
Cmd + A: Select all notes (Piano Roll) :: Selects all MIDI notes in the Piano Roll
Option + Cmd + A: Deselect all notes :: Deselects all currently selected notes
Shift + U: Quantize selected notes :: Applies quantization to fix timing of MIDI notes
"""
    }

    // MARK: - Discord

    private static var GetDiscordContent: () -> String = {
        return """
-- General --
>> App-level shortcuts for preferences, help, and search.
Cmd + /: Open keyboard shortcuts menu :: Displays Discord's built-in shortcut reference
Cmd + ,: Open User Settings :: Opens Discord preferences (set custom keybinds under Settings → Keybinds)
Cmd + K: Quick Switcher — jump to any server, channel, or DM :: Opens the quick switcher for instant navigation

-- Navigation --
>> Moving between servers, channels, and DMs in Discord.
Cmd + Option + Up: Previous channel or DM :: Moves to the channel or DM above in the sidebar
Cmd + Option + Down: Next channel or DM :: Moves to the channel or DM below in the sidebar
Option + Shift + Up: Previous unread channel or DM :: Jumps to the previous unread channel or DM
Option + Shift + Down: Next unread channel or DM :: Jumps to the next unread channel or DM
Cmd + Option + Shift + Up: Previous unread mention :: Jumps to the previous mention in the server
Cmd + Option + Shift + Down: Next unread mention :: Jumps to the next mention in the server

-- Voice & Video --
>> Controlling audio in Discord voice channels and calls.
Cmd + Shift + M: Toggle mute :: Mutes or unmutes your microphone (global — works even when Discord is in the background)
Cmd + Shift + D: Toggle deafen :: Deafens or undeafens your audio output
>> Camera toggle and disconnect-from-voice have no default Mac shortcut. Assign a custom keybind under Settings → Keybinds.

-- Messaging --
>> Composing and reading messages in Discord text channels.
Up Arrow: Edit your last sent message :: Opens your most recent message for editing
Shift + Return: New line without sending :: Inserts a line break without sending the message
Cmd + E: Open emoji picker :: Opens the emoji search and insert panel
Cmd + F: Search in current channel :: Searches messages in the current channel or DM
Cmd + B: Mark server as read :: Marks every channel in the current server as read
Escape: Mark current channel as read :: Marks all messages in the current channel as read
Cmd + Shift + T: Open GIF picker :: Opens the animated GIF search panel
"""
    }

    // MARK: - Figma

    private static var GetFigmaContent: () -> String = {
        return """
-- Tools --
>> Activating different drawing and selection tools in Figma.
V: Move / Select tool :: Activates the selection and move tool
F: Frame tool :: Activates the frame/artboard creation tool
R: Rectangle :: Activates the rectangle drawing tool
L: Line :: Activates the line drawing tool
T: Text :: Activates the text insertion tool
O: Ellipse :: Activates the ellipse/circle drawing tool
P: Pen tool :: Activates the vector pen tool for custom shapes
H: Hand (pan) :: Activates the pan/hand tool for scrolling the canvas
Z: Zoom :: Activates the zoom tool for clicking to zoom in
I: Eyedropper / colour picker :: Activates the colour picker tool
K: Scale tool :: Activates the scale tool for proportional resizing

-- View --
>> Zooming and toggling UI panels in Figma.
Cmd + Plus: Zoom in :: Increases the canvas zoom level
Cmd + Minus: Zoom out :: Decreases the canvas zoom level
Shift + 1: Fit all frames in view :: Scales the view to show all frames on the canvas
Shift + 2: Zoom to selection :: Scales the view to fit the selected objects
Cmd + \\: Toggle UI (hide / show all panels) :: Shows or hides all Figma panels and toolbars
Cmd + .: Toggle side panels :: Shows or hides the left and right panels only

-- Editing --
>> Manipulating and organising layers and objects in Figma.
Cmd + Z: Undo :: Reverses the last action
Cmd + Shift + Z: Redo :: Re-applies the last undone action
Cmd + D: Duplicate selected :: Creates a copy of the selected layer(s) in place
Cmd + G: Group selection :: Combines selected layers into a group
Cmd + Shift + G: Ungroup :: Breaks the selected group into individual layers
Cmd + Shift + [: Send to back :: Moves the selected layer to the bottom of the stack
Cmd + Shift + ]: Bring to front :: Moves the selected layer to the top of the stack
Option + Drag: Duplicate layer while dragging :: Holds Option while dragging to copy a layer
"""
    }

    // MARK: - Sketch

    private static var GetSketchContent: () -> String = {
        return """
-- Tools --
>> Activating drawing and selection tools in Sketch.
V: Vector tool :: Activates the vector drawing tool
T: Text tool :: Activates the text insertion tool
R: Rectangle :: Activates the rectangle shape tool
O: Oval / circle :: Activates the oval and circle shape tool
L: Line :: Activates the line drawing tool
P: Pencil :: Activates the freehand pencil tool
A: Artboard tool :: Activates the artboard creation tool
Hold Space: Pan canvas :: Temporarily activates the hand tool to drag the canvas
Z: Zoom :: Activates the zoom tool for clicking to zoom in
Ctrl + C: Colour picker :: Opens the inspector colour picker to sample a colour
S: Slice tool :: Activates the slice tool for defining export areas

-- View --
>> Adjusting the canvas zoom and display settings.
Cmd + Plus: Zoom in :: Increases the canvas zoom level
Cmd + Minus: Zoom out :: Decreases the canvas zoom level
Cmd + 0: Actual size (100%) :: Resets the canvas zoom to 100%
Cmd + 1: Fit canvas in window :: Scales the view to fit all artboards and content
Cmd + 2: Fit selection in view :: Zooms to fit the currently selected objects
Cmd + 3: Centre selection on canvas :: Centres the selected objects in the canvas view
Ctrl + R: Toggle rulers :: Shows or hides the horizontal and vertical rulers

-- Editing --
>> Duplicating, grouping, and arranging layers in Sketch.
Cmd + Z: Undo :: Reverses the last action
Cmd + D: Duplicate selected layer :: Creates a copy of the selected layer in place
Cmd + G: Group selected layers :: Combines selected layers into a new group
Cmd + Shift + G: Ungroup :: Breaks the selected group into individual layers
Option + Cmd + Up: Bring to front :: Moves the selected layer to the top of the layer stack
Option + Cmd + Down: Send to back :: Moves the selected layer to the bottom of the stack
Cmd + Return: Enter vector editing mode :: Enters the node editing mode for the selected vector path
Escape: Exit vector editing / deselect all :: Exits vector editing or deselects all layers
"""
    }

    // MARK: - 1Password

    private static var GetOnePasswordContent: () -> String = {
        return """
-- Global Shortcuts --
>> System-wide shortcuts that work from any application.
Cmd + \\ : Fill login on current web page :: Auto-fills the username and password on the current page
Cmd + Option + \\ : Open 1Password mini :: Opens the compact 1Password quick-access window
Cmd + Shift + L: Lock 1Password :: Immediately locks the vault and requires re-authentication

-- In the App --
>> Managing items within the main 1Password application window.
Cmd + N: New item :: Creates a new login, password, or secure note
Cmd + E: Edit selected item :: Opens the focused item for editing
Return: Open / view selected item :: Opens the focused item to view its details
Delete: Move item to trash :: Moves the selected item to the 1Password trash
Cmd + F: Search vault :: Focuses the search bar to find items by name or website
Cmd + 1: All items :: Switches to the All Items view
Cmd + 2: Favourites :: Switches to the Favourites view

-- Copying --
>> Quickly copying credentials from 1Password to the clipboard.
Cmd + C: Copy password :: Copies the password of the selected item to the clipboard
Cmd + Shift + C: Copy username :: Copies the username of the selected item
Cmd + Shift + U: Copy one-time password (TOTP) :: Copies the current TOTP code to the clipboard
Cmd + Shift + B: Open website in browser :: Opens the website associated with the selected item
"""
    }

    // MARK: - Obsidian

    private static var GetObsidianContent: () -> String = {
        return """
-- Navigation --
>> Opening notes, searching, and navigating the Obsidian vault.
Cmd + O: Open file switcher / search notes :: Opens the quick switcher to jump to any note
Cmd + N: Create new note :: Creates a new blank note in the vault
Cmd + P: Open command palette :: Opens the command palette to run any Obsidian action
Cmd + F: Search in current note :: Opens the in-file search bar
Cmd + Shift + F: Search across entire vault :: Opens the global search panel for all notes
Cmd + Option + Left: Go back to previous note :: Navigates back in the note history
Cmd + Option + Right: Go forward :: Navigates forward in the note history
Cmd + W: Close current tab :: Closes the current note tab

-- Editing --
>> Formatting content in Obsidian notes using Markdown shortcuts.
Cmd + B: Bold :: Wraps selected text in double asterisks for bold
Cmd + I: Italic :: Wraps selected text in single asterisks for italic
Cmd + K: Insert or edit hyperlink :: Opens the link insert dialog
Cmd + Z: Undo :: Reverses the last action
Tab: Indent list item :: Indents the current list item one level deeper
Shift + Tab: Outdent list item :: Outdents the current list item one level
Cmd + Return: Toggle checklist item complete :: Marks or unmarks the current checkbox task

-- View --
>> Switching between view modes and adjusting zoom.
Cmd + E: Toggle edit / reading view :: Switches between editing and preview reading mode
Cmd + Plus: Zoom in :: Increases the Obsidian interface text size
Cmd + Minus: Zoom out :: Decreases the Obsidian interface text size
"""
    }

    // MARK: - Notion

    private static var GetNotionContent: () -> String = {
        return """
-- Navigation --
>> Opening pages and moving through Notion.
Cmd + P: Quick Find — open any page instantly :: Opens the search dialog to jump to any page
Cmd + N: New page :: Creates a new page in the current workspace or sidebar section
Cmd + Shift + N: New Notion window :: Opens a new Notion application window
Cmd + F: Search within current page :: Searches for text within the current page
Cmd + [: Go back :: Navigates back in the page history
Cmd + ]: Go forward :: Navigates forward in the page history

-- Editing --
>> Creating, duplicating, and deleting content blocks in Notion.
Cmd + Z: Undo :: Reverses the last action
Cmd + Shift + Z: Redo :: Re-applies the last undone action
Cmd + D: Duplicate selected block :: Creates a copy of the selected block directly below
Cmd + Delete: Delete selected block :: Removes the selected block
Return: New block below current :: Starts a new content block on the next line
Shift + Return: Line break within current block :: Inserts a line break inside the current block
Tab: Indent block :: Indents the current block to become a child of the block above
Shift + Tab: Outdent block :: Outdents the current block one level up

-- Formatting --
>> Applying text styles and inserting special elements in Notion blocks.
Cmd + B: Bold :: Toggles bold on selected text
Cmd + I: Italic :: Toggles italic on selected text
Cmd + U: Underline :: Toggles underline on selected text
Cmd + Shift + S: Strikethrough :: Applies strikethrough to selected text
Cmd + E: Inline code :: Wraps selected text in inline code formatting
Cmd + K: Add or edit link :: Opens the link dialog to insert or edit a URL
"""
    }

    // MARK: - Bear

    private static var GetBearContent: () -> String = {
        return """
-- Notes --
>> Creating, duplicating, and managing notes in Bear.
Cmd + N: New note :: Creates a new blank note in the currently selected tag or section
Return: Open selected note from sidebar :: Opens the focused note in the editing view
Cmd + Delete: Move note to trash :: Moves the selected note to the Bear trash
Cmd + D: Duplicate note :: Creates an exact copy of the selected note

-- Editing --
>> Writing and formatting content in Bear notes.
Cmd + B: Bold :: Applies Markdown bold formatting to selected text
Cmd + I: Italic :: Applies Markdown italic formatting to selected text
Cmd + Shift + C: Inline code :: Wraps selected text in backtick inline code
Cmd + K: Insert hyperlink :: Opens the link insertion dialog
Cmd + Shift + H: Highlight text :: Applies yellow highlight formatting to selected text
Cmd + L: Create checklist item :: Converts the current line to a checkbox task item
Cmd + Shift + L: Create unordered list item :: Converts the current line to a bullet list item
Cmd + F: Find and replace in current note :: Opens the find and replace bar for the current note

-- Navigation --
>> Searching notes and navigating the Bear library.
Cmd + Shift + F: Search all notes in library :: Opens the global search across all notes
Cmd + 1: Notes list sidebar :: Shows the main notes list panel
Cmd + 0: Toggle sidebar :: Shows or hides the navigation sidebar
Cmd + [: Go back :: Navigates back in the note history
Cmd + ]: Go forward :: Navigates forward in the note history
"""
    }

    // MARK: - iTerm2

    private static var GetITerm2Content: () -> String = {
        return """
-- Tabs & Windows --
>> Managing tabs, windows, and layout in iTerm2.
Cmd + T: New tab :: Opens a new terminal tab in the current window
Cmd + N: New window :: Opens a new iTerm2 window
Cmd + W: Close current tab or pane :: Closes the active tab or split pane
Cmd + 1 through 9: Jump to tab by number :: Activates the tab at that position number
Cmd + Option + Left: Go to tab on the left :: Moves to the previous terminal tab
Cmd + Option + Right: Go to tab on the right :: Moves to the next terminal tab

-- Split Panes --
>> Splitting the iTerm2 window into multiple panes.
Cmd + D: Split pane vertically (side by side) :: Splits the current pane into two side-by-side columns
Cmd + Shift + D: Split pane horizontally (stacked) :: Splits the current pane into two stacked rows
Cmd + Option + Arrow: Navigate between split panes :: Moves keyboard focus to the adjacent pane
Cmd + Shift + Return: Maximize / restore current pane :: Expands the focused pane to fill the window

-- Session --
>> Searching and managing the terminal session content.
Cmd + F: Find text in current session :: Opens the search bar to find text in terminal output
Cmd + K: Clear scrollback buffer :: Clears all terminal output including the scrollback history
Cmd + C: Copy selection :: Copies the selected text to the clipboard
Cmd + V: Paste :: Pastes clipboard content at the cursor

-- Command Line Navigation --
>> Moving the cursor and editing text on the command line.
Ctrl + A: Move to beginning of line :: Jumps the cursor to the start of the current command
Ctrl + E: Move to end of line :: Jumps the cursor to the end of the current command
Ctrl + K: Delete from cursor to end of line :: Removes all text to the right of the cursor
Ctrl + U: Delete from cursor to beginning of line :: Removes all text to the left of the cursor
Option + Left: Jump one word left :: Moves the cursor back by one word
Option + Right: Jump one word right :: Moves the cursor forward by one word
Ctrl + R: Reverse search through command history :: Searches backwards through previous commands
"""
    }

    // MARK: - WhatsApp Desktop

    private static var GetWhatsAppContent: () -> String = {
        return """
-- Navigation --
>> Moving between chats and sections in the WhatsApp desktop app.
Cmd + F: Search chats :: Opens the search bar to find chats or messages
Cmd + N: New chat :: Opens a new chat compose window
Cmd + Shift + N: New group :: Opens the new group creation dialog
Cmd + Shift + [: Previous chat :: Moves to the previous chat in the list
Cmd + Shift + ]: Next chat :: Moves to the next chat in the list

-- Chat Actions --
>> Managing individual chats.
Cmd + E: Archive chat :: Archives the current chat to remove it from the main list
Cmd + Shift + M: Mute / unmute chat notifications :: Toggles notification muting for the chat
Cmd + Shift + U: Mark chat as unread :: Flags the current chat as unread
Cmd + Shift + P: Pin / unpin chat :: Pins or unpins the current chat at the top of the list
Cmd + Backspace: Delete chat (confirmation required) :: Deletes the current chat after confirmation

-- Messaging --
>> Composing and sending messages in WhatsApp chats.
Return: Send message :: Sends the typed message to the current chat
Shift + Return: New line without sending :: Inserts a line break without sending
Cmd + B: Bold selected text :: Applies bold formatting
Cmd + I: Italic selected text :: Applies italic formatting
Cmd + Shift + X: Strikethrough selected text :: Applies strikethrough formatting
Cmd + Shift + C: Inline code :: Applies monospace formatting
Escape: Close current chat / go back to list :: Returns focus to the chat list
"""
    }

    // MARK: - Final Cut Pro

    private static var GetFinalCutProContent: () -> String = {
        return """
-- Playback --
>> Controlling playback in the Final Cut Pro timeline and browser.
Space: Play / pause :: Toggles playback at the current playhead position
L: Play forward (press again to increase speed) :: Starts forward playback; press again to increase speed
J: Play backward (press again to increase speed) :: Starts reverse playback; press again to increase speed
K: Pause :: Stops playback at the current position
Option + Space: Play around playhead :: Plays a short section before and after the playhead

-- In / Out Points --
>> Setting the selection range for timeline operations.
I: Set range start (in point) :: Sets the start of the selection range at the playhead
O: Set range end (out point) :: Sets the end of the selection range at the playhead
Option + X: Clear in and out points :: Removes both the in and out point markers

-- Timeline Editing --
>> Cutting, deleting, and modifying clips in the Final Cut Pro timeline.
Cmd + B: Blade — split clip at playhead :: Cuts the selected clip at the current playhead position
Delete: Ripple delete (close gap automatically) :: Removes the clip and closes the timeline gap
Shift + Delete: Delete selected clip and leave gap :: Removes the clip but leaves the space in the timeline
V: Enable / disable selected clip :: Toggles the clip on or off without removing it
Cmd + Z: Undo :: Reverses the last editing action
Cmd + Shift + Z: Redo :: Re-applies the last undone action

-- Navigation --
>> Moving through the timeline and jumping to edit points.
Left / Right: Move playhead one frame :: Steps the playhead one frame at a time
Shift + Left / Right: Move playhead ten frames :: Steps the playhead ten frames at a time
Up / Down: Previous / next edit point :: Jumps the playhead to adjacent edit points
Cmd + Home: Go to beginning of timeline :: Jumps the playhead to the very start of the project
Cmd + End: Go to end of timeline :: Jumps the playhead to the very end of the project

-- View --
>> Adjusting the timeline zoom and window layout.
Shift + Z: Fit entire timeline in window :: Scales the timeline to show the full project
Cmd + Plus: Zoom in on timeline :: Increases the timeline zoom for detailed editing
Cmd + Minus: Zoom out on timeline :: Decreases the timeline zoom to see more of the project
Cmd + Shift + 8: Show/hide audio meters :: Toggles the audio channel meters panel
Cmd + 1: Show/hide Browser :: Toggles the media browser panel
Cmd + 4: Show/hide Inspector :: Toggles the Inspector panel on the right
Cmd + 6: Show/hide Color Inspector :: Opens the color correction inspector

-- Clip Connections & Roles --
>> Working with storylines, connected clips, and audio roles.
Q: Connect clip to primary storyline :: Attaches the selected browser clip as a connected clip
E: Append to end of timeline :: Appends the selected clip to the end of the primary storyline
D: Overwrite at playhead :: Replaces the timeline content with the selected clip at the playhead
Option + W: Insert gap :: Inserts an empty gap at the playhead in the timeline
Option + F: Insert freeze frame :: Creates a still from the current frame and inserts it

-- Audio --
>> Adjusting and managing audio in the Final Cut Pro timeline.
Ctrl + S: Expand audio / video :: Separates audio and video components of a clip
Option + Cmd + S: Collapse audio / video :: Re-joins the separated audio and video components
Ctrl + Option + L: Set audio level :: Opens the audio level adjustment for the selected clip
Shift + 1 / 2: Switch to different audio role :: Switches displayed role assignment

-- Markers --
>> Adding and navigating markers in the timeline.
M: Add marker at playhead :: Inserts a standard marker at the current playhead position
Option + M: Add chapter marker :: Adds a chapter marker for export/DVD use
Shift + M: Modify marker :: Opens the marker dialog to edit name and notes
Cmd + Option + Right / Left: Jump to next / previous marker :: Navigates between markers

>> Note: Final Cut Pro has limited VoiceOver support for editing operations.
>> Basic navigation and playback controls work, but timeline editing is largely mouse-dependent.
"""
    }

    // MARK: - Logic Pro

    private static var GetLogicProContent: () -> String = {
        return """
-- Playback & Recording --
>> Controlling transport and recording in Logic Pro.
Space: Start / stop playback :: Toggles playback of the current project
Return: Return to project start :: Moves the playhead back to bar 1
R: Start / stop recording :: Begins or ends recording on armed tracks
C: Toggle cycle (loop) region :: Enables or disables loop playback of the selected cycle area
Cmd + T: Split region at playhead :: Cuts the selected region at the current playhead position

-- Editing --
>> Selecting, duplicating, and modifying audio and MIDI regions.
Cmd + Z: Undo :: Reverses the last action
Cmd + Shift + Z: Redo :: Re-applies the last undone action
Cmd + A: Select all regions :: Selects every region on every track
Delete: Delete selected region or note :: Removes the selected item from the timeline
Cmd + D: Duplicate selected region :: Creates a copy of the selected region immediately after it
Cmd + J: Join selected regions :: Merges selected regions into a single continuous region

-- Navigation --
>> Moving the playhead and jumping between positions.
Left / Right Arrows: Move playhead :: Steps the playhead in the arrow direction
Cmd + Left: Go to beginning :: Jumps to bar 1 of the project
Cmd + Right: Go to end :: Jumps to the end of the last region in the project
Option + Left / Right: Jump to previous / next region :: Moves to the start of the adjacent region

-- Views & Windows --
>> Switching between Logic Pro's editing and mixing windows.
Cmd + 1: Tracks (Arrange) view :: Shows the main arrangement tracks view
Cmd + 2: Mixer :: Opens the Mixer window for channel strip control
Cmd + 3: Piano Roll editor :: Opens the MIDI piano roll for the selected region
Cmd + 4: Score editor :: Opens the music notation score editor
Cmd + 5: Step Sequencer :: Opens the step sequencer editor
Cmd + 6: Audio File editor :: Opens the audio waveform editor
Cmd + 7: Tempo track :: Shows the tempo curve editor
Cmd + 8: Loop Browser :: Opens the Apple Loops browser
Cmd + 9: Library panel :: Shows the patch/preset library
Cmd + Option + N: New track :: Opens the New Tracks dialog to add a track
X: Show/hide Mixer :: Toggles the Mixer panel in the main window
E: Show/hide Editor panel :: Toggles the bottom editor area (Piano Roll, Score, etc.)
Y: Show/hide Loop Browser :: Toggles the Loops browser panel
P: Show/hide Piano Keyboard :: Toggles the on-screen keyboard

-- Track Management --
>> Managing tracks and recording settings.
Option + Click on Mute: Mute all other tracks :: Solos the clicked track by muting all others
M: Mute selected track :: Toggles mute on the selected track
S: Solo selected track :: Toggles solo mode on the selected track
R: Record-enable selected track :: Arms or disarms the track for recording
Cmd + Option + Up / Down: Move track up / down :: Reorders the selected track in the list
Cmd + Option + I: Open Inspector :: Opens the region and track inspector panel

-- MIDI Notes (Piano Roll) --
>> Working with MIDI notes in the Piano Roll editor.
Cmd + A: Select all notes :: Selects every note in the Piano Roll
U: Quantize selected notes :: Applies quantization to fix note timing
Option + Q: Open Quantize settings :: Opens detailed quantize options
Shift + L: Select notes by pitch (lock) :: Restricts selection to the current pitch
Cmd + Shift + X: Crop region to selected notes :: Trims the region to the selection boundaries

>> Note: VoiceOver support in Logic Pro is limited. Logic does not provide full accessibility for all controls.
>> For a fully accessible DAW, consider REAPER with the SWS/Osara extension — designed for screen reader users.
"""
    }

    // MARK: - Adobe Photoshop

    private static var GetPhotoshopContent: () -> String = {
        return """
-- Tools --
>> Activating tools in the Photoshop Tools panel by pressing a single key.
V: Move tool :: Activates the Move tool for repositioning layers
M: Marquee selection tool :: Activates the rectangular or elliptical selection tool
L: Lasso tool :: Activates the freehand lasso selection tool
W: Quick Selection / Magic Wand :: Activates the quick selection or magic wand tool
C: Crop tool :: Activates the crop tool for trimming the canvas
I: Eyedropper :: Activates the colour picker eyedropper
J: Healing / Spot Healing Brush :: Activates the healing brush for blemish removal
B: Brush tool :: Activates the paintbrush tool
E: Eraser tool :: Activates the eraser tool
T: Type tool :: Activates the type tool for adding text layers
P: Pen tool :: Activates the pen tool for creating vector paths
U: Shape tool :: Activates the shape drawing tool
Z: Zoom tool :: Activates the zoom tool for clicking to zoom in
X: Swap foreground / background colours :: Swaps the foreground and background colour swatches
D: Reset to default colours (black / white) :: Resets foreground to black and background to white

-- Canvas & View --
>> Navigating and zooming the Photoshop canvas.
Cmd + Plus: Zoom in :: Increases the canvas zoom level
Cmd + Minus: Zoom out :: Decreases the canvas zoom level
Cmd + 0: Fit canvas on screen :: Scales the view to fit the entire canvas in the window
Cmd + Option + 0: Actual size (100%) :: Shows the canvas at 100% zoom (1:1 pixels)
Space + Drag: Pan canvas while using another tool :: Temporarily activates the Hand tool to pan

-- Editing --
>> Undoing, selecting, and moving content in Photoshop.
Cmd + Z: Undo (step back) :: Reverses the last action (use Cmd+Alt+Z for multiple steps)
Cmd + Shift + Z: Redo (step forward) :: Re-applies the last undone action
Cmd + D: Deselect all :: Removes the active selection marquee
Cmd + Shift + I: Invert selection :: Selects everything that was not previously selected
Cmd + C: Copy :: Copies the selected content to the clipboard
Cmd + V: Paste :: Pastes the clipboard content as a new layer
Cmd + X: Cut :: Cuts the selected content to the clipboard

-- Layers --
>> Managing layers in the Photoshop Layers panel.
Cmd + J: Duplicate selected layer :: Creates a copy of the selected layer above it
Cmd + G: Group selected layers :: Combines selected layers into a layer group
Cmd + Shift + G: Ungroup layers :: Removes the layer group, keeping the layers
Cmd + E: Merge down :: Merges the selected layer with the one directly below
Cmd + Shift + E: Merge all visible layers :: Flattens all visible layers into one
Cmd + [ : Move layer down in stack :: Moves the selected layer one position down in the panel
Cmd + ] : Move layer up in stack :: Moves the selected layer one position up in the panel
"""
    }

    // MARK: - Adobe Illustrator

    private static var GetIllustratorContent: () -> String = {
        return """
-- Tools --
>> Activating tools in the Adobe Illustrator Tools panel.
V: Selection tool :: Activates the Selection tool for moving and selecting objects
A: Direct Selection tool :: Activates the tool for selecting individual anchor points
P: Pen tool :: Activates the Pen tool for creating vector paths
T: Type tool :: Activates the Type tool for adding text
L: Ellipse tool :: Activates the ellipse drawing tool
M: Rectangle tool :: Activates the rectangle drawing tool
C: Scissors tool :: Activates the Scissors tool for cutting paths
E: Free Transform tool :: Activates the Free Transform tool for scaling and rotating
R: Rotate tool :: Activates the Rotate tool
S: Scale tool :: Activates the Scale tool
Z: Zoom tool :: Activates the Zoom tool for clicking to zoom in
X: Swap fill and stroke :: Swaps the current fill and stroke colour assignments
D: Reset to default fill and stroke :: Sets fill to white and stroke to black (default)

-- View --
>> Adjusting the canvas zoom and artboard visibility.
Cmd + Plus: Zoom in :: Increases the canvas zoom level
Cmd + Minus: Zoom out :: Decreases the canvas zoom level
Cmd + 0: Fit artboard in window :: Scales the view to show the current artboard
Cmd + Option + 0: Fit all artboards in window :: Scales to show all artboards in the workspace
Cmd + H: Show / hide edges :: Toggles the selection edge highlight on selected objects

-- Objects --
>> Grouping, locking, and hiding objects in Illustrator.
Cmd + G: Group selected objects :: Combines selected objects into a single group
Cmd + Shift + G: Ungroup :: Breaks the group back into individual objects
Cmd + 2: Lock selected objects :: Locks selected objects to prevent accidental editing
Cmd + Option + 2: Unlock all objects :: Unlocks all locked objects in the document
Cmd + 3: Hide selected objects :: Hides selected objects from the canvas view
Cmd + Option + 3: Show all hidden objects :: Reveals all hidden objects in the document

-- Editing --
>> Common editing and transform commands in Illustrator.
Cmd + Z: Undo :: Reverses the last action
Cmd + D: Transform again (repeat last transform) :: Repeats the last transform applied to an object
Cmd + C: Copy :: Copies the selected objects to the clipboard
Cmd + V: Paste :: Pastes clipboard content at the centre of the current view
Cmd + F: Paste in front :: Pastes clipboard content directly in front of the selected object
Cmd + B: Paste in back :: Pastes clipboard content directly behind the selected object
"""
    }

    // MARK: - Adobe Premiere Pro

    private static var GetPremiereProContent: () -> String = {
        return """
-- Playback --
>> Controlling playback in the Premiere Pro program and source monitors.
Space: Play / pause :: Toggles playback at the current playhead position
L: Shuttle forward (press again to increase speed) :: Plays forward; press again to increase speed
J: Shuttle backward (press again to increase speed) :: Plays in reverse; press again to increase speed
K: Pause :: Stops playback at the current position
Left / Right: Step one frame :: Steps the playhead one frame at a time
Shift + Left / Right: Step five frames :: Steps the playhead five frames at a time

-- In / Out Points --
>> Marking the selection range for editing and exporting clips.
I: Mark in point :: Sets the in point at the current playhead position
O: Mark out point :: Sets the out point at the current playhead position

-- Editing --
>> Cutting, deleting, and rearranging clips in the timeline.
Cmd + K: Add edit at playhead :: Cuts the targeted tracks at the current playhead position
Shift + Cmd + K: Add edit to all tracks :: Cuts all unlocked tracks at the playhead position
Delete: Clear selection (leaves gap) :: Removes the selected clip but keeps the timeline gap
Shift + Delete: Ripple delete :: Removes the selected clip and closes the gap automatically
Cmd + Z: Undo :: Reverses the last action
Cmd + Shift + Z: Redo :: Re-applies the last undone action
Cmd + C: Copy :: Copies the selected clip(s) to the clipboard
Cmd + V: Paste :: Pastes clipboard content at the playhead position

-- Tools --
>> Activating editing tools in the Premiere Pro toolbar.
V: Selection tool :: Activates the standard selection tool
C: Razor tool :: Activates the razor tool for cutting clips
B: Ripple Edit tool :: Activates the Ripple Edit tool for trimming with gap closure
N: Rolling Edit tool :: Activates the Rolling Edit tool for trimming adjacent clips

-- Timeline --
>> Navigating and zooming the Premiere Pro sequence timeline.
Plus: Zoom in on timeline :: Increases the timeline zoom for detailed editing
Minus: Zoom out on timeline :: Decreases the timeline zoom to see more of the sequence
Shift + Z: Fit timeline to window :: Scales the timeline to show the full sequence
Home: Go to beginning :: Moves the playhead to the very start of the sequence
End: Go to end :: Moves the playhead to the very end of the sequence
Up Arrow: Previous edit point :: Jumps the playhead to the nearest edit point to the left
Down Arrow: Next edit point :: Jumps the playhead to the nearest edit point to the right

-- Panels --
>> Switching keyboard focus between Premiere Pro's main panels.
Shift + 1: Project panel :: Moves focus to the Project panel
Shift + 2: Source monitor :: Moves focus to the Source Monitor
Shift + 3: Timeline panel :: Moves focus to the Timeline panel
Shift + 4: Program monitor :: Moves focus to the Program Monitor
"""
    }

    // MARK: - Pro Tools

    private static var GetProToolsContent: () -> String = {
        return """
-- Playback & Transport --
>> Controlling playback and transport in Pro Tools.
Space: Play / stop :: Toggles playback of the current session
0 (numpad): Stop and return to beginning :: Stops playback and returns to the session start
3 (numpad): Play from selection start :: Begins playback from the start of the current selection
4 (numpad): Play from pre-roll :: Plays from the pre-roll point before the selection
F12: Record :: Starts recording on all record-armed tracks
Cmd + Space: Audition (play through selection) :: Plays back the current selection range
Shift + Space: Loop play selection :: Continuously loops playback of the selection
Up / Down: Move forward / backward by grid increment :: Nudges the playhead by one grid unit
Left / Right: Nudge selection left / right :: Moves the selection by the current nudge value

-- Selection --
>> Making and extending selections in the Pro Tools timeline.
Cmd + A: Select all :: Selects all regions across all tracks
Shift + Click: Extend selection :: Extends the current selection to the clicked point
Tab: Next region boundary :: Jumps the cursor to the next region boundary
Shift + Tab: Previous region boundary :: Jumps the cursor to the previous region boundary
Option + Tab: Tab to next transient :: Jumps to the next audio transient point
Cmd + Tab: Tab to next region :: Jumps to the start of the next region

-- Editing --
>> Cutting, healing, and rearranging audio and MIDI regions.
Cmd + D: Duplicate selection :: Creates a copy of the selected region(s) immediately after
Cmd + R: Repeat selection (with dialog) :: Opens dialog to repeat the selection multiple times
Cmd + E: Separate region at selection :: Cuts a region into two at the selection boundaries
Cmd + H: Heal separation :: Merges two adjacent regions back into one
Cmd + G: Group regions :: Combines selected regions into a group for simultaneous editing
Cmd + Shift + G: Ungroup regions :: Breaks the group back into individual regions
Cmd + J: Consolidate selection :: Renders the selection into a single continuous region
B: Scrub (with Scrubber tool active) :: Activates audio scrubbing with the Scrubber tool
Cmd + Z: Undo :: Reverses the last action
Cmd + Shift + Z: Redo :: Re-applies the last undone action

-- Tools --
>> Activating different editing tools in the Pro Tools toolbar.
F1: Zoom tool :: Activates the Zoom tool for zooming into the timeline
F2: Trim tool :: Activates the Trim tool for adjusting region edges
F3: Selector tool :: Activates the Selector tool for making time selections
F4: Grabber tool :: Activates the Grabber tool for moving regions
F5: Pencil tool :: Activates the Pencil tool for drawing automation
F6: Scrubber tool :: Activates the Scrubber tool for audio scrubbing
F7: Smart tool :: Activates the Smart tool combining Selector and Grabber
F8: Fade tool :: Activates the Fade tool for creating crossfades

-- Zoom --
>> Zooming the timeline view horizontally and vertically.
Cmd + [ : Zoom in (horizontal) :: Zooms in horizontally to see more detail
Cmd + ] : Zoom out (horizontal) :: Zooms out horizontally to see more of the session
Cmd + Option + [ : Zoom in (vertical) :: Increases the track height for larger waveforms
Cmd + Option + ] : Zoom out (vertical) :: Decreases the track height to fit more tracks
Option + A: Zoom to session :: Zooms the timeline to fit the entire session in view
Cmd + Option + E: Zoom to selection :: Zooms the timeline to fill the window with the selection

-- Tracks --
>> Creating and managing tracks in the Pro Tools session.
Cmd + Shift + N: New track :: Opens the New Track dialog to add audio, MIDI, or bus tracks
Cmd + Option + H: Hide selected track :: Hides the selected track from the Edit window
Cmd + Option + A: Select all tracks :: Selects all tracks in the session
Shift + Click track: Add to selection :: Adds the clicked track to the current track selection
Option + M: Mute selected track :: Mutes or unmutes the selected track
Option + S: Solo selected track :: Solos or unsolos the selected track

-- Clips --
>> Finding and managing clips in the Clip List.
Cmd + F: Find clip :: Opens the Find dialog to search the Clip List
Cmd + Option + B: Bounce to disk :: Opens the Bounce to Disk dialog for export
Option + Drag: Copy clip :: Holds Option while dragging to duplicate a clip
Cmd + Click clip: Lock / unlock clip :: Toggles the clip lock to prevent accidental editing

-- Views & Windows --
>> Managing Pro Tools windows and switching between main views.
Cmd + W: Close window :: Closes the current floating window
Cmd + Shift + W: Close all windows :: Closes all floating windows
Cmd + =: Toggle Edit and Mix windows :: Switches between the Edit window (waveform view) and the Mix window (channel strips)
Cmd + 1: Transport window :: Shows or hides the Transport floating window
Cmd + 9: Video window :: Shows or hides the Video window
"""
    }

    // MARK: - REAPER + OSARA

    private static var GetREAPERContent: () -> String = {
        return """
-- What Is REAPER + OSARA --
>> REAPER is a professional, fully accessible DAW for Mac. OSARA (Open Source Accessibility Runtime for REAPER) adds comprehensive VoiceOver and screen reader support.
>> REAPER is the most recommended DAW in the blind audio production community.
>> Download REAPER: reaper.fm (free 60-day trial, then discounted license). Download OSARA: github.com/jcsteh/osara. Installation guide: reaperaccessibility.com

-- Installation Order --
>> Install components in this order to ensure OSARA works correctly with REAPER.
>> 1. Install REAPER from reaper.fm.
>> 2. Install the SWS extension (required by OSARA).
>> 3. Install OSARA and import the OSARA Key Map file.
>> 4. Launch REAPER with VoiceOver active (Cmd + F5).

-- Essential OSARA Tips --
>> OSARA speaks action names, track info, and parameter values as you navigate with the keyboard.
F12: Toggle keyboard shortcut help :: OSARA announces the action name for each key pressed — useful for learning
F4: Open Actions List :: Search and assign thousands of REAPER actions
Ctrl + 1: Open context menu for focused element :: Shows available actions for the currently focused item
Tab: Move between interactive controls :: Cycles forward through UI elements in the focused window
Shift + Tab: Move backward through controls :: Cycles backward through UI elements

-- Playback & Transport --
>> Control playback and navigate the timeline using the keyboard.
Space: Play / stop :: Toggles playback at the current edit cursor position
W: Stop and return to beginning :: Stops playback and moves the cursor to the start of the project
Home: Go to beginning of project :: Moves the edit cursor to time zero
End: Go to end of project :: Moves the edit cursor to the last item in the project
Left / Right: Move edit cursor by one beat :: Steps the cursor left or right by one beat at the current tempo
Ctrl + Left / Right: Move cursor to previous / next item edge :: Snaps the cursor to the nearest region boundary
Up / Down: Scrub backward / forward :: Auditions audio in slow motion in either direction
. (period): Toggle repeat (loop) :: Enables or disables looped playback within the time selection

-- Recording --
>> Arm tracks via the keyboard and use REAPER's standard record shortcut to capture audio.
Ctrl + R: Toggle record arm on selected track :: Arms or disarms the selected track for recording
Cmd + R: Begin recording :: Starts recording on all armed tracks
F12 (while recording): Stop recording :: Stops the recording pass
Shift + Cmd + R: Record in a new take :: Records an additional take without overwriting the previous one

-- Tracks --
>> Create, name, and navigate tracks. OSARA speaks the track name when you move between them.
Cmd + T: Insert new track :: Adds a new track at the bottom of the track list
Ctrl + Up / Down: Move between tracks :: OSARA announces the track name and number as you navigate
M: Mute selected track :: Toggles mute on the selected track
S: Solo selected track :: Toggles solo on the selected track
Ctrl + M: Mute all tracks :: Mutes every track in the project simultaneously
Ctrl + S: Un-solo all tracks :: Clears solo from all tracks
Ctrl + Shift + Up: Move track up :: Reorders the selected track one position up in the list
Ctrl + Shift + Down: Move track down :: Reorders the selected track one position down in the list
F2: Rename selected track :: Opens an inline text field to rename the track

-- Items (Clips) --
>> Split, move, duplicate, and delete audio clips on the timeline.
S: Split item at edit cursor :: Cuts the selected item at the current cursor position into two pieces
Delete: Remove selected item :: Deletes the selected clip from the timeline
Cmd + D: Duplicate selected item :: Creates a copy of the selected item immediately after it
Cmd + Z: Undo :: Reverses the last action
Cmd + Shift + Z: Redo :: Reapplies the last undone action
G: Open item properties :: OSARA announces clip details such as position, length, and pitch settings
Ctrl + Left / Right: Move item left / right by grid :: Nudges the selected item by the current grid size

-- Selection --
>> Define a time range for looping, editing, or exporting.
Cmd + A: Select all items :: Selects every item in the project
Shift + Left / Right: Extend time selection :: Grows or shrinks the current time selection
I: Set selection start to edit cursor :: Marks the left edge of the time selection at the cursor
O: Set selection end to edit cursor :: Marks the right edge of the time selection at the cursor
Escape: Clear time selection :: Removes the current time selection

-- Zoom --
>> Zoom the timeline horizontally or vertically to see more or less detail.
Ctrl + =: Zoom in (horizontal) :: Expands the timeline view to show more detail
Ctrl + -: Zoom out (horizontal) :: Contracts the timeline to show a wider time range
Ctrl + Option + =: Zoom in (vertical, tracks) :: Increases track height for more detailed waveform view
Ctrl + Option + -: Zoom out (vertical, tracks) :: Decreases track height to fit more tracks on screen
Z: Zoom to time selection :: Fits the current time selection to fill the arrange view
Ctrl + Shift + Z: Zoom out full project :: Zooms out to show the entire project from start to finish

-- Mixer --
>> Access the Mixer and adjust faders with keyboard navigation and OSARA feedback.
Cmd + L: Show / hide Mixer :: Toggles the Mixer window open or closed
Tab (in Mixer): Move between track faders :: OSARA speaks the track name and fader value as you tab
Up / Down (in Mixer): Adjust focused fader :: Raises or lowers the fader by a small increment
Ctrl + Click fader: Reset fader to 0 dB :: Snaps the track fader to unity gain

-- FX (Plugins) --
>> Open and navigate the FX chain for any track using only the keyboard.
E: Open FX chain for selected track :: Opens the plugin insert list for the selected track
Ctrl + Shift + E: Bypass all FX on selected track :: Toggles the entire FX chain on or off
Tab (in FX chain): Move between plugins and parameters :: Cycles through plugins and their editable parameters

-- OSARA Reporting --
>> Trigger OSARA to speak key session information on demand.
Ctrl + Shift + F2: Speak selected track / item info :: Announces the name, position, and properties of the selection
Ctrl + Shift + F3: Speak edit cursor position :: Announces the current timecode position of the edit cursor
Ctrl + Shift + F4: Speak current time selection :: Announces the start, end, and length of the time selection
Ctrl + Shift + F5: Speak project tempo and time signature :: Announces the BPM and time signature of the project
Ctrl + Shift + F6: Speak peak volume of selected track :: Announces the peak meter reading for the selected track

-- Resources --
>> Community sites and documentation for learning accessible audio production with REAPER.
reaperaccessibility.com: Full keyboard reference and tutorials :: Comprehensive guide to using REAPER with OSARA
flotools.org: Flo Tools for Pro Tools users :: Similar accessibility extension for Pro Tools on Mac
audio.pizza: Accessible audio production community :: Forum and resources for blind and low-vision producers
"""
    }

    // MARK: - Libby

    private static var GetLibbyContent: () -> String = {
        return """
-- What Is Libby --
>> Libby is a free app by OverDrive for borrowing ebooks, audiobooks, and magazines from your public library at no cost.
>> It is fully compatible with VoiceOver and offers comprehensive keyboard navigation on Mac.
>> Visit libbyapp.com in Safari (no download required) or download the Libby app from the Mac App Store.

-- Getting Started --
>> Sign in with your library card to borrow and read titles directly in Libby.
>> 1. Open libbyapp.com in Safari or launch the Libby Mac app.
>> 2. Sign in with your library card number.
>> 3. Search for a title, borrow it, and open it directly in Libby.

-- General Navigation --
>> Navigate all Libby screens using the keyboard. Press ? from any view to see available shortcuts.
Tab: Move forward through interactive elements :: Cycles focus to the next button, link, or input field
Shift + Tab: Move backward through interactive elements :: Cycles focus to the previous interactive element
Enter / Space: Activate focused button or link :: Clicks the focused control
Escape: Close dialog or panel :: Dismisses a dialog or collapses an open panel
? (Shift + /): Show all keyboard shortcuts in current view :: Opens Libby's built-in shortcut help overlay
Arrow keys: Navigate within menus and lists :: Moves selection through dropdown menus and result lists

-- Ebook Reader --
>> Read borrowed ebooks with full keyboard navigation for pages, chapters, and settings.
Right Arrow: Turn to next page :: Advances one page forward in the ebook
Left Arrow: Turn to previous page :: Goes back one page in the ebook
Cmd + Right: Jump forward 10 pages :: Skips ahead 10 pages at once
Cmd + Left: Jump back 10 pages :: Goes back 10 pages at once
Home: Go to beginning of book :: Jumps to the first page of the ebook
End: Go to end of book :: Jumps to the last page of the ebook
Cmd + F: Search within the book :: Opens a text search field to find words or phrases in the ebook
T: Open table of contents :: Opens the chapter list to jump to any section
B: Open bookmarks panel :: Shows saved bookmarks in the current book
S: Open settings :: Opens font size, theme, and spacing options for the reader
Escape: Close reading menu / exit reading view :: Dismisses menus or returns to the library from the reader

-- Audiobook Player --
>> Control audiobook playback including speed, chapter navigation, and bookmarks.
Space: Play / pause :: Starts or pauses audiobook playback
Right Arrow: Skip forward 30 seconds :: Jumps ahead 30 seconds in the current chapter
Left Arrow: Skip back 30 seconds :: Goes back 30 seconds in the current chapter
Shift + Right: Skip forward by one chapter :: Advances to the beginning of the next chapter
Shift + Left: Skip back by one chapter :: Returns to the beginning of the previous chapter
Up Arrow: Increase playback speed :: Raises the narration speed by one increment
Down Arrow: Decrease playback speed :: Lowers the narration speed by one increment
S: Open sleep timer :: Sets a timer to automatically stop playback after a set duration
B: Open bookmarks :: Shows saved position bookmarks for the current audiobook
T: Open table of contents / chapters :: Opens the chapter list to jump to any part of the audiobook

-- Library Browsing --
>> Search for titles and navigate library results using the keyboard.
Enter: Open selected title :: Opens the detail page for the focused book or audiobook
Shift + / (?): Show available shortcuts for current view :: Displays keyboard shortcuts relevant to the current library page
Tab: Move between search, filters, and results :: Cycles focus between the search bar, filter controls, and title cards
Arrow keys: Move through title cards in search results :: Navigates between book covers in the results grid

-- VoiceOver Tips --
>> Enable VoiceOver before launching Libby for the best accessible experience.
>> Libby announces book titles, authors, and formats automatically with VoiceOver active.
>> Use VO + A to read the current page continuously in the ebook reader.
>> Use headings navigation (VO + Cmd + H) to jump between sections of the library interface.
>> The audiobook player controls are fully labeled and work seamlessly with VoiceOver.

-- Notes --
>> A library card is required — sign up for free at your local public library.
>> Libby is completely ad-free and free to use with a valid library card.
>> Borrowed titles are available for a set lending period (typically 14 or 21 days).
"""
    }

}
