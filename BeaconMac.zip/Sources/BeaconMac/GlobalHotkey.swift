// =============================================================================
//  GlobalHotkey.swift — CGEventTap Global Hotkey (configurable at runtime)
//
//  Permission flow (no restart required):
//    1. setup() checks AXIsProcessTrusted().
//    2. If not trusted, the native macOS system prompt is shown and a 1-second
//       polling timer starts.
//    3. Once the user grants permission the timer detects it and calls
//       createEventTap() automatically — no restart needed.
//
//  `suppressFiring` is set to true while the Preferences window records
//  a new hotkey, so the current hotkey does not fire in the background.
//
//  CGEventTap requires a C-style callback. We pass `self` through the
//  `userInfo` pointer and recover it with Unmanaged.fromOpaque() inside
//  the callback.
// =============================================================================
import AppKit
import CoreGraphics

// MARK: - C Callback (module-level — cannot be inside a class)

/// Invoked by the OS for every keyDown event system-wide.
/// Reads the current HotkeySetting from the recovered instance and
/// fires if the event matches.
private func eventTapCallback(
    proxy:  CGEventTapProxy,
    type:   CGEventType,
    event:  CGEvent,
    refcon: UnsafeMutableRawPointer?
) -> Unmanaged<CGEvent>? {

    guard let refcon = refcon else { return Unmanaged.passRetained(event) }
    let hotkey = Unmanaged<GlobalHotkey>.fromOpaque(refcon).takeUnretainedValue()

    // If the tap was disabled by the OS (can happen if the app is slow),
    // re-enable it so we keep receiving events.
    if type == .tapDisabledByTimeout || type == .tapDisabledByUserInput {
        if let tap = hotkey.eventTap { CGEvent.tapEnable(tap: tap, enable: true) }
        return Unmanaged.passRetained(event)
    }

    guard type == .keyDown         else { return Unmanaged.passRetained(event) }
    guard !hotkey.suppressFiring   else { return Unmanaged.passRetained(event) }

    let kc    = Int(event.getIntegerValueField(.keyboardEventKeycode))
    let flags = event.flags

    if hotkey.currentSetting.matches(cgKeyCode: kc, cgFlags: flags) {
        hotkey.fire()
        return nil   // Consume — do not pass to the frontmost app
    }
    return Unmanaged.passRetained(event)
}

// MARK: - GlobalHotkey

class GlobalHotkey {

    // MARK: Singleton
    static let shared = GlobalHotkey()
    private init() {
        currentSetting = HotkeySetting.loadFromDefaults()
    }

    // MARK: State

    /// The active hotkey. Update with `updateSetting(_:)` — takes effect immediately.
    private(set) var currentSetting: HotkeySetting

    /// Set to `true` while the Preferences window is recording a new hotkey
    /// to prevent the existing hotkey from firing during recording.
    var suppressFiring: Bool = false

    /// Called on the main thread when the hotkey fires.
    var onTrigger: (() -> Void)?

    // Called when permission is newly granted (so AppDelegate can update UI).
    var onPermissionGranted: (() -> Void)?

    /// Called on the main thread the first time Accessibility permission is
    /// needed (i.e. the app has never been trusted before).  If set, this
    /// callback replaces the bare macOS system dialog so the caller can show
    /// a friendlier explanation first.  The permission poller still starts
    /// automatically after the callback returns, so the hotkey self-activates
    /// the moment the user grants access — no restart needed.
    /// NOTE: the stale-TCC case (trusted but tap creation fails, typically
    /// after a reinstall) bypasses this callback and shows the raw system
    /// prompt directly, since that scenario targets developers, not end users.
    var onPermissionNeeded: (() -> Void)?

    private(set) var eventTap:      CFMachPort?
    private var runLoopSource: CFRunLoopSource?
    private var permissionPoller: Timer?

    // MARK: - Public Status

    /// True when the CGEventTap is installed AND currently enabled.
    /// False when Accessibility permission is missing, tap creation failed,
    /// or the tap was disabled by the OS.
    var isHotkeyActive: Bool {
        guard let tap = eventTap else { return false }
        return CGEvent.tapIsEnabled(tap: tap)
    }

    // MARK: - Setup

    /// Call once at launch. Checks Accessibility permission and either
    /// installs the CGEventTap immediately or starts the permission UI +
    /// a background poller that activates the tap the moment the user
    /// grants access — no app restart required.
    func setup() {
        if AXIsProcessTrusted() {
            // Permission is granted — try to create the tap now.
            // createEventTap() can still fail if the TCC entry is stale
            // (e.g. the binary was rebuilt and the permission was tied to
            // the previous binary's hash). If it fails, show the raw system
            // prompt (bypassing onPermissionNeeded — this is a developer /
            // reinstall scenario, not a first-run end-user scenario) and
            // start the poller to retry once TCC is fully updated.
            if !createEventTap() {
                print("[BeaconMac] AXIsProcessTrusted is true but tapCreate failed — " +
                      "TCC entry may be stale. Showing prompt and retrying…")
                showSystemPrompt()
                startPermissionPoller(retrying: true)
            }
        } else {
            // First-time permission request.  Use onPermissionNeeded if set
            // so AppDelegate can show a friendly explanation; otherwise fall
            // back to the bare macOS system dialog.
            if let handler = onPermissionNeeded {
                handler()
            } else {
                showSystemPrompt()
            }
            startPermissionPoller(retrying: false)
        }
    }

    // MARK: - Permission Helpers

    private func showSystemPrompt() {
        // Opens System Settings → Privacy & Security → Accessibility.
        let opts = [kAXTrustedCheckOptionPrompt.takeUnretainedValue() as String: true]
        AXIsProcessTrustedWithOptions(opts as CFDictionary)
    }

    // MARK: - Permission Poller

    /// Polls every second until the CGEventTap is successfully created.
    ///
    /// - Parameter retrying: pass `true` when the tap previously failed even
    ///   with permission granted (stale TCC) — the poller will keep trying
    ///   even if AXIsProcessTrusted() already returns true, until the tap
    ///   itself confirms it is running.
    private func startPermissionPoller(retrying: Bool) {
        permissionPoller?.invalidate()
        permissionPoller = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in
            guard let self = self else { return }
            // Only attempt once permission is actually granted.
            guard AXIsProcessTrusted() else { return }
            // Keep retrying until the tap is ACTUALLY running.
            // (createEventTap returns false when tapCreate returns nil.)
            if self.createEventTap() {
                self.permissionPoller?.invalidate()
                self.permissionPoller = nil
                self.onPermissionGranted?()
                print("[BeaconMac] Event tap is now active.")
            } else if !retrying {
                // First-time permission grant path: tap failed on first try.
                // Switch to retry mode and keep going.
                print("[BeaconMac] Tap creation failed after permission grant — will keep retrying…")
            }
        }
    }

    // MARK: - Event Tap

    /// Installs the CGEventTap. Only called when AXIsProcessTrusted() == true.
    @discardableResult
    private func createEventTap() -> Bool {
        // Tear down any existing tap first (handles rebuilds / multiple calls).
        teardownEventTap()

        let eventMask: CGEventMask = (1 << CGEventType.keyDown.rawValue)
            | (1 << CGEventType.tapDisabledByTimeout.rawValue)
            | (1 << CGEventType.tapDisabledByUserInput.rawValue)
        let selfPtr = Unmanaged.passUnretained(self).toOpaque()

        guard let tap = CGEvent.tapCreate(
            tap:              .cghidEventTap,
            place:            .tailAppendEventTap,   // tail = Zoom/magnifier sees events first
            options:          .defaultTap,
            eventsOfInterest: eventMask,
            callback:         eventTapCallback,
            userInfo:         selfPtr
        ) else {
            print("[BeaconMac] CGEvent.tapCreate failed — check Accessibility permission.")
            return false
        }

        eventTap      = tap
        runLoopSource = CFMachPortCreateRunLoopSource(kCFAllocatorDefault, tap, 0)
        CFRunLoopAddSource(CFRunLoopGetMain(), runLoopSource, .commonModes)
        CGEvent.tapEnable(tap: tap, enable: true)

        print("[BeaconMac] Hotkey active: \(currentSetting.displayString)")
        return true
    }

    // MARK: - Update Hotkey

    /// Changes the active hotkey immediately — no restart required.
    /// The C callback reads `currentSetting` from `self` on every event,
    /// so the new hotkey takes effect on the very next keypress.
    func updateSetting(_ newSetting: HotkeySetting) {
        currentSetting = newSetting
        print("[BeaconMac] Hotkey updated to: \(newSetting.displayString)")
    }

    // MARK: - Fire

    /// Called by the C callback; dispatches to the main thread.
    func fire() {
        DispatchQueue.main.async { [weak self] in
            self?.onTrigger?()
        }
    }

    // MARK: - Teardown

    private func teardownEventTap() {
        if let tap = eventTap {
            CGEvent.tapEnable(tap: tap, enable: false)
        }
        if let src = runLoopSource {
            CFRunLoopRemoveSource(CFRunLoopGetMain(), src, .commonModes)
        }
        eventTap      = nil
        runLoopSource = nil
    }

    /// Disables and releases everything. Call from applicationWillTerminate.
    func teardown() {
        permissionPoller?.invalidate()
        permissionPoller = nil
        teardownEventTap()
    }
}
