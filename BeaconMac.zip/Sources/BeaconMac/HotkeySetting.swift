// =============================================================================
//  HotkeySetting.swift — Hotkey Configuration & UserDefaults Persistence
//
//  Stores which key + modifier combination triggers the BeaconMac panel.
//  Persisted to UserDefaults so it survives app restarts.
//  Consumed by GlobalHotkey.swift and displayed in PreferencesWindow.swift.
// =============================================================================
import AppKit

struct HotkeySetting {

    // MARK: - Properties

    var keyCode:   Int       // Carbon/CGEvent key code (e.g. 5 = G)
    var modifiers: [String]  // Ordered subset of: "ctrl", "alt", "cmd", "shift"

    // MARK: - Default

    /// Default: Ctrl + Option + G  (keyCode 5)
    static let `default` = HotkeySetting(keyCode: 5, modifiers: ["ctrl", "alt"])

    // MARK: - UserDefaults Keys

    private static let keyCodeKey   = "BeaconMac.hotkey.keyCode"
    private static let modifiersKey = "BeaconMac.hotkey.modifiers"

    // MARK: - Persistence

    static func loadFromDefaults() -> HotkeySetting {
        let d = UserDefaults.standard
        guard let code = d.object(forKey: keyCodeKey) as? Int,
              let mods = d.object(forKey: modifiersKey) as? [String],
              !mods.isEmpty
        else { return .default }
        return HotkeySetting(keyCode: code, modifiers: mods)
    }

    func saveToDefaults() {
        let d = UserDefaults.standard
        d.set(keyCode,   forKey: HotkeySetting.keyCodeKey)
        d.set(modifiers, forKey: HotkeySetting.modifiersKey)
        d.synchronize()
    }

    // MARK: - Display

    /// Human-readable string, e.g. "⌃⌥G" or "⌘⇧K"
    var displayString: String {
        var parts = [String]()
        if modifiers.contains("ctrl")  { parts.append("⌃") }
        if modifiers.contains("alt")   { parts.append("⌥") }
        if modifiers.contains("shift") { parts.append("⇧") }
        if modifiers.contains("cmd")   { parts.append("⌘") }
        parts.append(keyChar)
        return parts.joined()
    }

    /// The printable name for the key code, e.g. "G", "Space", "F5"
    var keyChar: String {
        HotkeySetting.keyCodeToChar[keyCode] ?? "(\(keyCode))"
    }

    // Carbon key code → printable name
    static let keyCodeToChar: [Int: String] = [
        0:"A",   1:"S",   2:"D",   3:"F",   4:"H",   5:"G",   6:"Z",   7:"X",
        8:"C",   9:"V",  11:"B",  12:"Q",  13:"W",  14:"E",  15:"R",  16:"Y",
       17:"T",  18:"1",  19:"2",  20:"3",  21:"4",  22:"6",  23:"5",  24:"=",
       25:"9",  26:"7",  27:"-",  28:"8",  29:"0",  30:"]",  31:"O",  32:"U",
       33:"[",  34:"I",  35:"P",  37:"L",  38:"J",  39:"'",  40:"K",  41:";",
       42:"\\", 43:",",  44:"/",  45:"N",  46:"M",  47:".",
       49:"Space", 50:"`",
       96:"F5", 97:"F6", 98:"F7", 99:"F3", 100:"F8", 101:"F9",
      103:"F11",109:"F10",111:"F12",118:"F4",120:"F2",122:"F1",
      123:"←",124:"→",125:"↓",126:"↑"
    ]

    // MARK: - Matching

    /// Returns true when the given CGEvent key code + flags match this setting.
    func matches(cgKeyCode k: Int, cgFlags flags: CGEventFlags) -> Bool {
        guard k == keyCode else { return false }
        let wantsCtrl  = modifiers.contains("ctrl")
        let wantsAlt   = modifiers.contains("alt")
        let wantsCmd   = modifiers.contains("cmd")
        let wantsShift = modifiers.contains("shift")
        return wantsCtrl  == flags.contains(.maskControl)   &&
               wantsAlt   == flags.contains(.maskAlternate) &&
               wantsCmd   == flags.contains(.maskCommand)   &&
               wantsShift == flags.contains(.maskShift)
    }

    // MARK: - Validation

    /// A valid hotkey must have at least one modifier key.
    var isValid: Bool {
        !modifiers.isEmpty
    }

    // MARK: - Build from NSEvent (used during recording)

    /// Creates a HotkeySetting from a recorded NSEvent keyDown event.
    /// Returns nil if the event is Escape or has no modifiers.
    static func fromEvent(_ event: NSEvent) -> HotkeySetting? {
        let kc = Int(event.keyCode)
        guard kc != 53 else { return nil }   // Escape = cancel

        var mods = [String]()
        if event.modifierFlags.contains(.control) { mods.append("ctrl") }
        if event.modifierFlags.contains(.option)  { mods.append("alt") }
        if event.modifierFlags.contains(.shift)   { mods.append("shift") }
        if event.modifierFlags.contains(.command) { mods.append("cmd") }

        let setting = HotkeySetting(keyCode: kc, modifiers: mods)
        return setting.isValid ? setting : nil
    }
}
