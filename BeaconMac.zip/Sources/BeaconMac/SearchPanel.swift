import AppKit

final class SearchPanel: NSWindow, NSWindowDelegate, NSSearchFieldDelegate {

    // MARK: Public callbacks

    var onGuideSelected: ((ShortcutGuide) -> Void)?
    var onDismissed: (() -> Void)?

    // MARK: Constants

    private let panelWidth: CGFloat = 760
    private let panelHeight: CGFloat = 640
    private let rowHeight: CGFloat = 56

    // MARK: Data

    private let allGuides: [ShortcutGuide] = ShortcutContent.allGuides.filter { $0.id != "BrowseAll" }
    private var filteredGuides: [ShortcutGuide] = []
    private var preferredGuideID: String?
    private var selectedIndex: Int = 0
    private var dismissingForGuide = false
    private var localKeyMonitor: Any?
    private var helpOverlayWindow: NSWindow?
    private var guideButtons: [GuideListItemButton] = []
    private var searchDebounceTimer: Timer?

    // MARK: UI

    private var effectView: NSVisualEffectView!
    private var contextLabel: NSTextField!
    private var scrollView: NSScrollView!
    private var listContainerView: NSView!
    private var listStackView: NSStackView!
    private var searchField: NSSearchField!
    private var footerLabel: NSTextField!

    // MARK: Init

    init() {
        let rect = NSRect(x: 0, y: 0, width: panelWidth, height: panelHeight)
        super.init(
            contentRect: rect,
            styleMask: [.titled, .closable, .fullSizeContentView],
            backing: .buffered,
            defer: true
        )

        title = "BeaconMac"
        titleVisibility = .hidden
        titlebarAppearsTransparent = true
        level = .normal
        isOpaque = false
        backgroundColor = .clear
        hasShadow = true
        isMovableByWindowBackground = true
        collectionBehavior = [.canJoinAllSpaces, .managed]
        delegate = self

        // VoiceOver Application Chooser: the explicit .standardWindow subrole
        // ensures this panel is listed under "BeaconMac" rather than "System Dialogs".
        setAccessibilityLabel("BeaconMac shortcut guides")
        setAccessibilitySubrole(.standardWindow)

        buildUI()
        resetList()
    }

    override var canBecomeKey: Bool { true }
    override var canBecomeMain: Bool { true }
    override func noResponder(for eventSelector: Selector) { }

    // MARK: UI

    private func buildUI() {
        // Fail loudly if contentView is missing.  Silently returning here would
        // leave every IUO property below (effectView, searchField, etc.) nil,
        // which would then crash much later inside prepareForPresentation(_:) —
        // far from the real cause.  NSWindow always has a contentView once the
        // super.init(contentRect:...) call returns, so this should never trip.
        guard let contentView else {
            fatalError("SearchPanel.buildUI() called before contentView was available")
        }

        effectView = NSVisualEffectView(frame: contentView.bounds)
        effectView.autoresizingMask = [.width, .height]
        effectView.blendingMode = .behindWindow
        effectView.state = .active
        effectView.material = .hudWindow
        effectView.wantsLayer = true
        effectView.layer?.cornerRadius = 14
        effectView.layer?.masksToBounds = true
        contentView.addSubview(effectView)

        contextLabel = NSTextField(labelWithString: "Guides")
        contextLabel.translatesAutoresizingMaskIntoConstraints = false
        contextLabel.font = .systemFont(ofSize: 14, weight: .semibold)
        contextLabel.textColor = .secondaryLabelColor
        contextLabel.setAccessibilityLabel("Current application context")
        effectView.addSubview(contextLabel)

        listStackView = NSStackView()
        listStackView.translatesAutoresizingMaskIntoConstraints = false
        listStackView.orientation = .vertical
        listStackView.alignment = .leading
        listStackView.spacing = 4
        listStackView.edgeInsets = NSEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        listStackView.setAccessibilityElement(false)

        listContainerView = NSView()
        listContainerView.translatesAutoresizingMaskIntoConstraints = false
        listContainerView.addSubview(listStackView)

        NSLayoutConstraint.activate([
            listStackView.topAnchor.constraint(equalTo: listContainerView.topAnchor),
            listStackView.leadingAnchor.constraint(equalTo: listContainerView.leadingAnchor),
            listStackView.trailingAnchor.constraint(equalTo: listContainerView.trailingAnchor),
            listStackView.bottomAnchor.constraint(equalTo: listContainerView.bottomAnchor),
            listStackView.widthAnchor.constraint(equalTo: listContainerView.widthAnchor)
        ])

        scrollView = NSScrollView()
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        scrollView.drawsBackground = false
        scrollView.hasVerticalScroller = true
        scrollView.hasHorizontalScroller = false
        scrollView.autohidesScrollers = true
        scrollView.borderType = .noBorder
        scrollView.documentView = listContainerView
        scrollView.setAccessibilityLabel("Shortcut guides")
        effectView.addSubview(scrollView)

        searchField = NSSearchField()
        searchField.translatesAutoresizingMaskIntoConstraints = false
        searchField.placeholderString = "Search guides"
        searchField.font = .systemFont(ofSize: 15)
        searchField.delegate = self
        searchField.setAccessibilityLabel("Search guides")
        searchField.setAccessibilityHelp("Type to filter the guides list. Press Escape to return to the selected guide.")
        effectView.addSubview(searchField)

        footerLabel = NSTextField(labelWithString: "Up/Down: move guides   Return: open guide   Tab: search   Escape: close")
        footerLabel.translatesAutoresizingMaskIntoConstraints = false
        footerLabel.font = .systemFont(ofSize: 12)
        footerLabel.textColor = .secondaryLabelColor
        effectView.addSubview(footerLabel)

        NSLayoutConstraint.activate([
            contextLabel.topAnchor.constraint(equalTo: effectView.topAnchor, constant: 14),
            contextLabel.leadingAnchor.constraint(equalTo: effectView.leadingAnchor, constant: 16),
            contextLabel.trailingAnchor.constraint(equalTo: effectView.trailingAnchor, constant: -16),

            scrollView.topAnchor.constraint(equalTo: contextLabel.bottomAnchor, constant: 10),
            scrollView.leadingAnchor.constraint(equalTo: effectView.leadingAnchor, constant: 12),
            scrollView.trailingAnchor.constraint(equalTo: effectView.trailingAnchor, constant: -12),

            searchField.topAnchor.constraint(equalTo: scrollView.bottomAnchor, constant: 10),
            searchField.leadingAnchor.constraint(equalTo: effectView.leadingAnchor, constant: 12),
            searchField.trailingAnchor.constraint(equalTo: effectView.trailingAnchor, constant: -12),
            searchField.heightAnchor.constraint(equalToConstant: 30),

            footerLabel.topAnchor.constraint(equalTo: searchField.bottomAnchor, constant: 8),
            footerLabel.leadingAnchor.constraint(equalTo: effectView.leadingAnchor, constant: 16),
            footerLabel.trailingAnchor.constraint(equalTo: effectView.trailingAnchor, constant: -16),
            footerLabel.bottomAnchor.constraint(equalTo: effectView.bottomAnchor, constant: -12),

            scrollView.bottomAnchor.constraint(equalTo: searchField.topAnchor, constant: -10)
        ])
    }

    // MARK: Show / hide

    func showPanel(initialQuery: String? = nil) {
        centerOnScreen()
        prepareForPresentation(initialQuery: initialQuery)
        installLocalKeyMonitor()
        makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)

        DispatchQueue.main.async { [weak self] in
            self?.moveVoiceOverIntoGuideList()
        }
    }

    func reshowPanel() {
        centerOnScreen()
        installLocalKeyMonitor()
        makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
        DispatchQueue.main.async { [weak self] in
            self?.moveVoiceOverIntoGuideList()
        }
    }

    func hidePanel() {
        removeLocalKeyMonitor()
        orderOut(nil)
    }

    private func prepareForPresentation(initialQuery: String?) {
        searchField.stringValue = ""
        preferredGuideID = nil
        resetList()

        if let query = initialQuery?.trimmingCharacters(in: .whitespacesAndNewlines), !query.isEmpty {
            let lower = query.lowercased()
            let matches = allGuides.filter {
                $0.title.lowercased().contains(lower) ||
                $0.description.lowercased().contains(lower) ||
                $0.category.lowercased().contains(lower)
            }
            if let first = matches.first {
                preferredGuideID = first.id
                contextLabel.stringValue = "Guides for current app: \(first.title)"
            } else {
                contextLabel.stringValue = "Guides"
            }
        } else {
            contextLabel.stringValue = "Guides"
        }

        rebuildGuideList()
        selectInitialGuide()
    }

    private func resetList() {
        filteredGuides = allGuides
        rebuildGuideList()
    }

    private func selectInitialGuide() {
        let index: Int
        if let preferredGuideID,
           let idx = filteredGuides.firstIndex(where: { $0.id == preferredGuideID }) {
            index = idx
        } else {
            index = 0
        }
        selectGuide(at: index, focus: false, announce: false)
    }

    private func centerOnScreen() {
        guard let screen = NSScreen.main else { return }
        let visible = screen.visibleFrame
        let x = visible.midX - frame.width / 2
        let y = visible.midY - frame.height / 2
        setFrameOrigin(NSPoint(x: x, y: y))
    }

    private func rebuildGuideList() {
        // Remove every arranged subview, not just tracked buttons — otherwise
        // the "No matching guides" placeholder label (added below when
        // filteredGuides is empty) is never cleaned up and accumulates across
        // rebuilds, leaving phantom blank rows in the list.
        for subview in listStackView.arrangedSubviews {
            listStackView.removeArrangedSubview(subview)
            subview.removeFromSuperview()
        }
        guideButtons.removeAll()

        for (index, guide) in filteredGuides.enumerated() {
            let button = GuideListItemButton()
            button.translatesAutoresizingMaskIntoConstraints = false
            button.guide = guide
            button.index = index
            button.target = self
            button.action = #selector(guideButtonPressed(_:))
            button.doubleActionTarget = self
            button.doubleAction = #selector(guideButtonDoublePressed(_:))
            button.configure(with: guide)
            listStackView.addArrangedSubview(button)
            button.heightAnchor.constraint(equalToConstant: rowHeight).isActive = true
            guideButtons.append(button)
        }

        if filteredGuides.isEmpty {
            let emptyLabel = NSTextField(labelWithString: "No matching guides")
            emptyLabel.textColor = .secondaryLabelColor
            emptyLabel.font = .systemFont(ofSize: 14)
            emptyLabel.alignment = .center
            emptyLabel.translatesAutoresizingMaskIntoConstraints = false
            emptyLabel.setAccessibilityElement(false)
            listStackView.addArrangedSubview(emptyLabel)
            emptyLabel.heightAnchor.constraint(equalToConstant: 40).isActive = true
        }
    }

    private func scrollSelectionToVisible() {
        guard selectedIndex >= 0, selectedIndex < guideButtons.count else { return }
        let button = guideButtons[selectedIndex]
        let rect = button.convert(button.bounds, to: listContainerView)
        scrollView.contentView.scrollToVisible(rect.insetBy(dx: 0, dy: -8))
        scrollView.reflectScrolledClipView(scrollView.contentView)
    }

    private func focusSelectedGuideForVoiceOver() {
        guard selectedIndex >= 0, selectedIndex < guideButtons.count else { return }
        let button = guideButtons[selectedIndex]
        makeFirstResponder(button)
        NSAccessibility.post(element: NSApplication.shared, notification: .focusedWindowChanged)
        NSAccessibility.post(element: button, notification: .focusedUIElementChanged)
        NSAccessibility.post(element: button, notification: .selectedChildrenChanged)
    }

    private func moveVoiceOverIntoGuideList() {
        let delays: [Double] = [0.0, 0.12, 0.35, 0.7]
        for delay in delays {
            DispatchQueue.main.asyncAfter(deadline: .now() + delay) { [weak self] in
                guard let self, self.isVisible else { return }
                self.focusSelectedGuideForVoiceOver()
            }
        }
    }

    // MARK: Filtering

    @objc private func searchDidChange() {
        applyFilter(searchField.stringValue)
    }

    func controlTextDidChange(_ obj: Notification) {
        // Debounce: rebuilding 82 buttons per keystroke is expensive.
        // Wait 80 ms after the last character before filtering, so fast
        // typists don't trigger a full list rebuild on every keypress.
        searchDebounceTimer?.invalidate()
        searchDebounceTimer = Timer.scheduledTimer(withTimeInterval: 0.08,
                                                   repeats: false) { [weak self] _ in
            self?.searchDidChange()
        }
    }

    private func applyFilter(_ rawText: String) {
        let text = rawText.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        if text.isEmpty {
            filteredGuides = allGuides
        } else {
            filteredGuides = allGuides.filter {
                $0.title.lowercased().contains(text) ||
                $0.description.lowercased().contains(text) ||
                $0.category.lowercased().contains(text)
            }
        }

        if filteredGuides.isEmpty {
            contextLabel.stringValue = "No matching guides"
        } else if let preferredGuideID,
                  text.isEmpty,
                  let preferredGuide = filteredGuides.first(where: { $0.id == preferredGuideID }) {
            contextLabel.stringValue = "Guides for current app: \(preferredGuide.title)"
        } else if !text.isEmpty {
            contextLabel.stringValue = "Search results: \(filteredGuides.count) guides"
        } else {
            contextLabel.stringValue = "Guides"
        }

        rebuildGuideList()

        guard !filteredGuides.isEmpty else {
            selectedIndex = 0
            return
        }

        if let preferredGuideID,
           text.isEmpty,
           let preferredIndex = filteredGuides.firstIndex(where: { $0.id == preferredGuideID }) {
            selectGuide(at: preferredIndex, focus: false, announce: false)
        } else {
            selectGuide(at: 0, focus: false, announce: false)
        }

        if !(firstResponder is NSText) {
            focusSelectedGuideForVoiceOver()
        }
    }

    // MARK: Selection

    private func selectGuide(at index: Int, focus: Bool = true, announce: Bool = true) {
        guard !filteredGuides.isEmpty, !guideButtons.isEmpty else { return }

        let clamped = max(0, min(index, filteredGuides.count - 1))
        selectedIndex = clamped

        for (idx, button) in guideButtons.enumerated() {
            button.isSelectedGuide = (idx == clamped)
        }

        scrollSelectionToVisible()

        if focus {
            focusSelectedGuideForVoiceOver()
        } else if announce {
            NSAccessibility.post(element: guideButtons[clamped], notification: .selectedChildrenChanged)
        }
    }

    private func openSelectedGuide() {
        guard selectedIndex >= 0, selectedIndex < filteredGuides.count else { return }
        let guide = filteredGuides[selectedIndex]
        dismissingForGuide = true
        hidePanel()
        dismissingForGuide = false
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { [weak self] in
            self?.onGuideSelected?(guide)
        }
    }

    private func moveSelection(delta: Int) {
        guard !filteredGuides.isEmpty else { return }
        selectGuide(at: selectedIndex + delta)
    }

    private func moveSelectionToBoundary(_ toEnd: Bool) {
        guard !filteredGuides.isEmpty else { return }
        selectGuide(at: toEnd ? filteredGuides.count - 1 : 0)
    }

    private func moveSelectionByPage(_ direction: Int) {
        guard !filteredGuides.isEmpty else { return }
        let visibleRows = max(1, Int(scrollView.contentView.bounds.height / rowHeight) - 1)
        selectGuide(at: selectedIndex + (visibleRows * direction))
    }

    // MARK: Actions

    @objc private func guideButtonPressed(_ sender: GuideListItemButton) {
        selectGuide(at: sender.index)
    }

    @objc private func guideButtonDoublePressed(_ sender: GuideListItemButton) {
        selectGuide(at: sender.index)
        openSelectedGuide()
    }

    private func showKeyboardHelp() {
        if let existing = helpOverlayWindow, existing.isVisible {
            existing.orderOut(nil)
            helpOverlayWindow = nil
            focusSelectedGuideForVoiceOver()
            return
        }

        let helpText = """
BeaconMac Keyboard Help

Guide list
\u{2022} Up / Down Arrow: Move through guides
\u{2022} Home / End: Jump to first or last guide
\u{2022} Page Up / Page Down: Jump by a page
\u{2022} Return: Open selected guide
\u{2022} Tab: Move to search
\u{2022} ?: Show or hide this help
\u{2022} Escape: Close BeaconMac

Guide window
\u{2022} Up / Down Arrow: Move through content
\u{2022} [ : Previous heading
\u{2022} ] : Next heading
\u{2022} H (VoiceOver): Jump directly between headings
\u{2022} Escape: Return to the guide list
"""
        let textView = NSTextView(frame: NSRect(x: 0, y: 0, width: 520, height: 300))
        textView.isEditable = false
        textView.isSelectable = true
        textView.drawsBackground = false
        textView.string = helpText
        textView.font = .systemFont(ofSize: 14)
        textView.textColor = .labelColor
        textView.setAccessibilityLabel("BeaconMac keyboard help")

        let scroll = NSScrollView(frame: textView.frame)
        scroll.drawsBackground = false
        scroll.borderType = .noBorder
        scroll.hasVerticalScroller = true
        scroll.documentView = textView

        let helpWindow = NSWindow(
            contentRect: NSRect(x: 0, y: 0, width: 520, height: 300),
            styleMask: [.titled, .closable],
            backing: .buffered,
            defer: false
        )
        helpWindow.title = "BeaconMac Keyboard Help"
        helpWindow.isReleasedWhenClosed = false
        helpWindow.level = .floating
        helpWindow.contentView = scroll
        helpWindow.center()
        helpWindow.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
        helpOverlayWindow = helpWindow
    }

    // MARK: Local key monitor

    private func installLocalKeyMonitor() {
        guard localKeyMonitor == nil else { return }
        localKeyMonitor = NSEvent.addLocalMonitorForEvents(matching: .keyDown) { [weak self] event in
            guard let self, self.isVisible else { return event }
            return self.handleLocalKeyDown(event)
        }
    }

    private func removeLocalKeyMonitor() {
        if let localKeyMonitor { NSEvent.removeMonitor(localKeyMonitor) }
        localKeyMonitor = nil
    }

    private func handleLocalKeyDown(_ event: NSEvent) -> NSEvent? {
        switch event.keyCode {
        case 53: // escape
            if firstResponder is NSText {
                searchField.stringValue = ""
                applyFilter("")
                focusSelectedGuideForVoiceOver()
            } else {
                hidePanel()
            }
            return nil

        case 36, 76: // return
            openSelectedGuide()
            return nil

        case 48: // tab
            if firstResponder is NSText {
                focusSelectedGuideForVoiceOver()
            } else {
                makeFirstResponder(searchField)
                NSAccessibility.post(element: searchField!, notification: .focusedUIElementChanged)
            }
            return nil

        case 115: // home
            moveSelectionToBoundary(false)
            return nil

        case 119: // end
            moveSelectionToBoundary(true)
            return nil

        case 116: // page up
            moveSelectionByPage(-1)
            return nil

        case 121: // page down
            moveSelectionByPage(1)
            return nil

        case 125: // down
            if firstResponder is NSText { focusSelectedGuideForVoiceOver() }
            moveSelection(delta: 1)
            return nil

        case 126: // up
            if firstResponder is NSText { focusSelectedGuideForVoiceOver() }
            moveSelection(delta: -1)
            return nil

        default:
            if let chars = event.charactersIgnoringModifiers, chars == "?" {
                showKeyboardHelp()
                return nil
            }
            if !(firstResponder is NSText),
               let chars = event.characters,
               !chars.isEmpty,
               !event.modifierFlags.contains(.command),
               !event.modifierFlags.contains(.control),
               !event.modifierFlags.contains(.option) {
                makeFirstResponder(searchField)
                searchField.keyDown(with: event)
                return nil
            }
            return event
        }
    }

    // MARK: Window delegate

    func windowDidBecomeKey(_ notification: Notification) {
        DispatchQueue.main.async { [weak self] in
            guard let self, self.isVisible else { return }
            self.moveVoiceOverIntoGuideList()
        }
    }

    func windowDidResignKey(_ notification: Notification) {
        guard !dismissingForGuide else { return }
        if isVisible {
            hidePanel()
            onDismissed?()
        }
    }

    func windowWillClose(_ notification: Notification) {
        removeLocalKeyMonitor()
    }
}

final class PlainAXTextField: NSTextField {
    override func accessibilityAttributedString(for range: NSRange) -> NSAttributedString? {
        NSAttributedString(string: stringValue)
    }
}

final class GuideListItemButton: NSButton {
    fileprivate var guide: ShortcutGuide?
    fileprivate var index: Int = 0
    fileprivate weak var doubleActionTarget: AnyObject?
    fileprivate var doubleAction: Selector?

    private let titleField = PlainAXTextField(labelWithString: "")
    private let detailField = PlainAXTextField(labelWithString: "")

    var isSelectedGuide: Bool = false {
        didSet { updateAppearance() }
    }

    override init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        setup()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setup()
    }

    override var acceptsFirstResponder: Bool { true }

    private func setup() {
        isBordered = false
        bezelStyle = .regularSquare
        setButtonType(.momentaryChange)
        imagePosition = .noImage
        focusRingType = .none
        wantsLayer = true
        layer?.cornerRadius = 10
        setAccessibilityRole(.staticText)
        setAccessibilityHelp("Use Up and Down Arrow to move between guides. Press Return to open this guide.")

        titleField.translatesAutoresizingMaskIntoConstraints = false
        titleField.font = .systemFont(ofSize: 15, weight: .semibold)
        titleField.lineBreakMode = .byTruncatingTail
        titleField.setAccessibilityElement(false)
        addSubview(titleField)

        detailField.translatesAutoresizingMaskIntoConstraints = false
        detailField.font = .systemFont(ofSize: 12)
        detailField.textColor = .secondaryLabelColor
        detailField.lineBreakMode = .byTruncatingTail
        detailField.setAccessibilityElement(false)
        addSubview(detailField)

        NSLayoutConstraint.activate([
            titleField.topAnchor.constraint(equalTo: topAnchor, constant: 8),
            titleField.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 12),
            titleField.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -12),

            detailField.topAnchor.constraint(equalTo: titleField.bottomAnchor, constant: 4),
            detailField.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 12),
            detailField.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -12),
            detailField.bottomAnchor.constraint(lessThanOrEqualTo: bottomAnchor, constant: -8)
        ])

        updateAppearance()
    }

    func configure(with guide: ShortcutGuide) {
        self.guide = guide
        titleField.stringValue = guide.title
        detailField.stringValue = "\(guide.category) — \(guide.description)"
        setAccessibilityLabel("\(guide.title). \(guide.category). \(guide.description)")
        setAccessibilityValue(guide.title)
    }

    override func mouseDown(with event: NSEvent) {
        super.mouseDown(with: event)
        if event.clickCount >= 2,
           let doubleAction,
           let target = doubleActionTarget {
            NSApp.sendAction(doubleAction, to: target, from: self)
        }
    }

    override func becomeFirstResponder() -> Bool {
        let didBecome = super.becomeFirstResponder()
        updateAppearance()
        if didBecome {
            NSAccessibility.post(element: self, notification: .focusedUIElementChanged)
        }
        return didBecome
    }

    override func resignFirstResponder() -> Bool {
        let didResign = super.resignFirstResponder()
        updateAppearance()
        return didResign
    }

    override func drawFocusRingMask() {
        bounds.fill()
    }

    override var focusRingMaskBounds: NSRect { bounds }

    private func updateAppearance() {
        guard let layer else { return }

        if isSelectedGuide {
            layer.backgroundColor = NSColor.controlAccentColor.withAlphaComponent(0.22).cgColor
            layer.borderColor = NSColor.controlAccentColor.withAlphaComponent(0.75).cgColor
            layer.borderWidth = 1.5
        } else if window?.firstResponder === self {
            layer.backgroundColor = NSColor.selectedControlColor.withAlphaComponent(0.16).cgColor
            layer.borderColor = NSColor.keyboardFocusIndicatorColor.withAlphaComponent(0.8).cgColor
            layer.borderWidth = 1.0
        } else {
            layer.backgroundColor = NSColor.clear.cgColor
            layer.borderColor = NSColor.clear.cgColor
            layer.borderWidth = 0
        }
    }

    override func accessibilityPerformPress() -> Bool {
        performClick(nil)
        return true
    }

    override func accessibilityRole() -> NSAccessibility.Role? {
        .staticText
    }
}
