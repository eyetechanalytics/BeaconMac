// =============================================================================
//  AppDelegate.swift — App Lifecycle, Menu Bar, Hotkey Wiring
// =============================================================================
import AppKit
import ServiceManagement
import WebKit

class AppDelegate: NSObject, NSApplicationDelegate {

    // MARK: - Properties

    private var statusItem:         NSStatusItem?
    private var searchPanel:        SearchPanel?
    private let globalHotkey      = GlobalHotkey.shared
    /// The app that was frontmost when the panel was last opened.
    /// Restored when the panel is dismissed without opening a guide.
    private var previousActiveApp:  NSRunningApplication?

    /// Held only during app startup to warm the shared WebKit renderer process.
    /// WebKit spawns its WebContent process the first time any WKWebView loads
    /// a document.  Without pre-warming, the very first guide open in each
    /// app session hits a cold-start penalty (200–500 ms on Apple Silicon,
    /// longer on older hardware) during which:
    ///   • arrow keys don't reach the JS keydown listener yet, and
    ///   • WebKit's initial accessibility-tree registration floods the system
    ///     accessibility channel at the same moment SearchPanel posts its own
    ///     VoiceOver announcements, causing unexpected bink sounds.
    /// Both are deallocated after 3 s — the WebKit process pool stays alive
    /// for the rest of the session regardless.
    ///
    /// IMPORTANT: the WKWebView must be hosted in a real NSWindow (even one
    /// that is never shown).  An orphaned WKWebView registers its accessibility
    /// elements with the system server without a parent window context; VoiceOver
    /// then surfaces those parentless nodes as a "system dialog" entry in the
    /// VO+F1+F1 Application Chooser.  Hosting it in a hidden, accessibility-
    /// excluded NSWindow gives the tree a proper parent so VoiceOver ignores it.
    private var webKitWarmupView:   WKWebView?
    private var webKitWarmupWindow: NSWindow?

    // MARK: - Launch

    func applicationDidFinishLaunching(_ notification: Notification) {
        // The app always runs with .regular activation policy (never .accessory).
        //
        // Switching to .accessory at any point causes VoiceOver to re-classify
        // BeaconMac as a background agent, making it appear under "System Dialogs"
        // in the VO+F1+F1 Application Chooser instead of under "BeaconMac".
        // Staying .regular at all times ensures VoiceOver sees a consistent, named
        // application identity throughout the session — the Dock icon will be
        // visible while any BeaconMac window is shown, and hidden automatically
        // when all windows are ordered out, which is the correct macOS behavior.

        // Explicitly set the VoiceOver name for this application element so the
        // VO+F1+F1 Application Chooser always announces "BeaconMac" regardless of
        // which window is focused or what activation policy is currently active.
        NSApp.setAccessibilityTitle("BeaconMac")

        // If this is a new binary build AND Accessibility was previously granted,
        // remove the stale TCC entry and relaunch so the fresh binary registers
        // cleanly.  Must run before setupGlobalHotkey() — if a relaunch is needed,
        // this call terminates the process immediately.
        resetPermissionIfNewBuild()

        setupMenuBarItem()
        setupSearchPanel()
        setupGlobalHotkey()
        // Rebuild the menu now that the hotkey tap attempt has been made,
        // so the initial menu state accurately shows the active/waiting status.
        buildMenu()
        updateStatusTooltip()
        // Listen for Preferences-saved hotkey changes so the menu bar item
        // and tooltip refresh immediately after the user picks a new combo.
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(hotkeyDidChange),
            name: .bmHotkeyChanged,
            object: nil
        )
        // On the very first launch, silently register as a login item so the
        // app is ready every time the user logs in without them needing to
        // configure it manually.
        enableLoginItemOnFirstRun()
        // Start the WebKit renderer process now so the first guide opens
        // without a cold-start delay.  See webKitWarmupView comment above.
        warmWebKitRenderer()
        // Check for a newer version in the background after 60 seconds so the
        // app is fully settled and the user is actively working before any
        // update prompt appears.
        DispatchQueue.main.asyncAfter(deadline: .now() + 60) {
            UpdateChecker.checkForUpdates(silent: true)
        }
    }

    func applicationWillTerminate(_ notification: Notification) {
        globalHotkey.teardown()
    }

    // MARK: - Menu Bar Status Item

    private func setupMenuBarItem() {
        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)

        if let button = statusItem?.button {
            if let img = NSImage(systemSymbolName: "keyboard", accessibilityDescription: "BeaconMac") {
                img.isTemplate = true
                button.image   = img
            } else {
                button.title = "⌨"
            }
            updateStatusTooltip()
        }

        buildMenu()
    }

    /// Builds (or rebuilds) the status item menu.
    /// Called once at launch and again after the hotkey changes so the menu title stays accurate.
    private func buildMenu() {
        let hotkey = globalHotkey.currentSetting.displayString
        let active = globalHotkey.isHotkeyActive
        let menu   = NSMenu()

        // ── Hotkey status (shown when tap isn't running) ─────────────────────
        if !active {
            let warningItem = NSMenuItem(
                title:  "⚠ Accessibility permission required",
                action: #selector(openAccessibilitySettings),
                keyEquivalent: ""
            )
            warningItem.target = self
            menu.addItem(warningItem)

            let hintItem = NSMenuItem(
                title:  "  System Settings → Privacy → Accessibility",
                action: nil,
                keyEquivalent: ""
            )
            hintItem.isEnabled = false
            menu.addItem(hintItem)
            menu.addItem(NSMenuItem.separator())
        }

        let openItem = NSMenuItem(
            title:  "Open Shortcut Guide  (\(hotkey))",
            action: #selector(openGuide),
            keyEquivalent: ""
        )
        openItem.target = self
        menu.addItem(openItem)

        menu.addItem(NSMenuItem.separator())

        let prefsItem = NSMenuItem(
            title:  "Preferences…",
            action: #selector(openPreferences),
            keyEquivalent: ","
        )
        prefsItem.keyEquivalentModifierMask = .command
        prefsItem.target = self
        menu.addItem(prefsItem)

        menu.addItem(NSMenuItem.separator())

        let aboutItem = NSMenuItem(
            title:  "About BeaconMac",
            action: #selector(showAbout),
            keyEquivalent: ""
        )
        aboutItem.target = self
        menu.addItem(aboutItem)

        menu.addItem(NSMenuItem.separator())

        let quitItem = NSMenuItem(
            title:  "Quit BeaconMac",
            action: #selector(quitApp),
            keyEquivalent: "q"
        )
        quitItem.keyEquivalentModifierMask = .command
        quitItem.target = self
        menu.addItem(quitItem)

        statusItem?.menu = menu
    }

    // MARK: - Status Tooltip

    /// Refreshes the menu bar icon tooltip to reflect whether the hotkey
    /// event tap is currently active. This lets the user immediately see
    /// whether the app is working or still waiting for Accessibility permission.
    private func updateStatusTooltip() {
        let hotkey = globalHotkey.currentSetting.displayString
        let status = globalHotkey.isHotkeyActive
            ? hotkey
            : "\(hotkey)  ⚠ Awaiting Accessibility permission"
        statusItem?.button?.toolTip = "BeaconMac — \(status)"
    }

    // MARK: - Search Panel

    private func setupSearchPanel() {
        searchPanel = SearchPanel()
        searchPanel?.onGuideSelected = { [weak self] guide in
            self?.openContentWindow(for: guide)
        }
        // When the panel is explicitly dismissed (Escape, click outside, or hotkey
        // toggle), restore focus to whichever app was active before the panel opened.
        searchPanel?.onDismissed = { [weak self] in
            self?.restorePreviousApp()
        }
    }

    // MARK: - Global Hotkey

    private func setupGlobalHotkey() {
        globalHotkey.onTrigger = { [weak self] in
            self?.toggleSearchPanel()
        }

        // When the hotkey tap becomes active (either immediately at launch
        // or after the user grants Accessibility permission), update the
        // tooltip and rebuild the menu so the status reflects reality.
        // Also record that permission has been granted so resetPermissionIfNewBuild()
        // can detect a stale TCC entry on the next rebuild.
        globalHotkey.onPermissionGranted = { [weak self] in
            DispatchQueue.main.async {
                UserDefaults.standard.set(true, forKey: "hasBeenGrantedAccessibility")
                self?.updateStatusTooltip()
                self?.buildMenu()
            }
        }

        // Show a friendly first-run explanation instead of the bare macOS
        // system dialog.  The polling timer in GlobalHotkey still watches for
        // the permission grant and activates the hotkey automatically.
        globalHotkey.onPermissionNeeded = { [weak self] in
            self?.showAccessibilityPermissionAlert()
        }

        globalHotkey.setup()
    }

    /// Shown the first time BeaconMac launches without Accessibility permission.
    /// Explains in plain language what the permission is for, names the
    /// password / Touch ID step explicitly, then opens System Settings to the
    /// correct pane so the user can enable it in one click.
    private func showAccessibilityPermissionAlert() {
        NSApp.activate(ignoringOtherApps: true)

        let hotkey = globalHotkey.currentSetting.displayString

        let alert = NSAlert()
        alert.messageText = "One Permission Required"
        alert.informativeText = """
            To open the shortcut guide from any app using \(hotkey), \
            BeaconMac needs Accessibility permission from macOS.

            How to enable it:
            1. Click "Open Settings" below
            2. Find BeaconMac in the list and flip its switch to ON
            3. macOS will ask for your password or Touch ID to confirm

            The keyboard shortcut will start working immediately — \
            no restart needed.
            """
        alert.alertStyle = .informational
        alert.addButton(withTitle: "Open Settings")
        alert.addButton(withTitle: "Later")

        if alert.runModal() == .alertFirstButtonReturn {
            openAccessibilitySettings()
        }
    }

    // MARK: - Toggle Search Panel

    /// Shows the panel pre-filtered for the currently focused app,
    /// or hides it if already visible.
    private func toggleSearchPanel() {
        guard let panel = searchPanel else { return }
        if panel.isVisible {
            // Hotkey pressed while visible — treat as explicit dismiss.
            // windowDidResignKey will fire and call onDismissed → restorePreviousApp.
            panel.hidePanel()
        } else {
            // Capture frontmost app NOW, before we make any window key
            // (our panel is nonactivatingPanel so NSWorkspace still reports
            // the user's app as frontmost at this point)
            let frontApp      = NSWorkspace.shared.frontmostApplication
            previousActiveApp = frontApp
            let query         = AppDetector.searchQuery(for: frontApp)
            // Ensure .regular policy so the SearchPanel appears as "BeaconMac"
            // in VoiceOver's VO+F1+F1 Application Chooser and Cmd+Tab.
            NSApp.setActivationPolicy(.regular)
            panel.showPanel(initialQuery: query)
        }
    }

    /// Activates the app that was frontmost when the panel was opened,
    /// so keyboard focus returns to where the user was working.
    private func restorePreviousApp() {
        // Stay in .regular activation policy at all times.  Switching to
        // .accessory here (or anywhere) causes VoiceOver to re-classify the
        // app under "System Dialogs" in the VO+F1+F1 Application Chooser the
        // next time the panel opens, because VoiceOver caches the process's
        // policy state during transitions.  Remaining .regular is harmless —
        // a menu-bar-only app behaves identically whether .regular or .accessory
        // when no windows are visible, and the Dock icon disappears automatically
        // once all windows are hidden.
        previousActiveApp?.activate(options: .activateIgnoringOtherApps)
        previousActiveApp = nil
    }

    // MARK: - Content Windows

    private func openContentWindow(for guide: ShortcutGuide) {
        let window = ContentWindow(guide: guide)

        // Ensure .regular policy so this ContentWindow appears as "BeaconMac"
        // in the Cmd+Tab switcher, Mission Control, and VoiceOver's VO+F1+F1
        // Application Chooser.  (The app always stays .regular — see comment
        // in applicationDidFinishLaunching for the full rationale.)
        NSApp.setActivationPolicy(.regular)

        // When this window closes (Escape or red-button), reshow the search panel
        // so the user can press Escape once more to dismiss it entirely.
        // We never switch to .accessory here — see restorePreviousApp() for details.
        window.onClose = { [weak self] in
            self?.searchPanel?.reshowPanel()
        }

        window.makeKeyAndOrderFront(nil)
        // The search panel hid itself just before this call, leaving the app
        // temporarily without a frontmost window.  Activate explicitly so the
        // ContentWindow can become key and accept first-responder assignments.
        NSApp.activate(ignoringOtherApps: true)
        // Transfer AppKit keyboard focus to the web view immediately so that
        // arrow keys reach the JavaScript keydown listener from the first moment
        // the window is visible.  Without this call, focus doesn't arrive until
        // webView(_:didFinish:) fires, which can be 100–400 ms later on a cold
        // WKWebView process start — long enough for the user to press a key and
        // hear a system beep instead of getting content navigation.
        window.focusWebView()
    }

    // MARK: - Menu Actions

    @objc private func openGuide() {
        let frontApp = NSWorkspace.shared.frontmostApplication
        let query    = AppDetector.searchQuery(for: frontApp)
        NSApp.setActivationPolicy(.regular)
        searchPanel?.showPanel(initialQuery: query)
    }

    @objc private func openAccessibilitySettings() {
        // Open System Settings directly to the Accessibility privacy pane.
        if let url = URL(string: "x-apple.systempreferences:com.apple.preference.security?Privacy_Accessibility") {
            NSWorkspace.shared.open(url)
        }
    }

    @objc private func openPreferences() {
        PreferencesWindowController.shared.showPreferences()
        // Menu is rebuilt via the .bmHotkeyChanged notification observed in
        // applicationDidFinishLaunching — no need to rebuild here.
    }

    /// Observer for `.bmHotkeyChanged` — posted by PreferencesWindow after the
    /// user saves a new hotkey. Rebuilds the menu bar item title and refreshes
    /// the status-item tooltip so both reflect the current hotkey combination.
    @objc private func hotkeyDidChange() {
        buildMenu()
        updateStatusTooltip()
    }

    @objc private func showAbout() {
        let setting = globalHotkey.currentSetting.displayString
        let alert   = NSAlert()
        alert.messageText = "BeaconMac 1.0.0"
        alert.informativeText = """
            A keyboard shortcut reference tool for macOS.
            82 guides: macOS, Microsoft Office, Google Workspace,
            Apple iWork, Adobe Creative Suite, dev tools, and more.

            Hotkey: \(setting)  ·  Change: menu bar ⌨ → Preferences…

            Developed by EyeTech Analytics  ·  (859) 212-3668
            Distributed under the MIT License.
            """
        alert.alertStyle = .informational
        alert.addButton(withTitle: "OK")

        // ── Accessory view: clickable email + website links ───────────────────
        // NSAlert.informativeText is plain text only; an NSTextView accessory
        // view lets us embed proper .link attributes that NSWorkspace will open.
        let tv = NSTextView(frame: NSRect(x: 0, y: 0, width: 320, height: 36))
        tv.isEditable   = false
        tv.isSelectable = true
        tv.drawsBackground   = false
        tv.alignment = .center

        let bodyFont = NSFont.systemFont(ofSize: 12)
        let str      = NSMutableAttributedString()

        // Helper: build a clickable link span
        func addLink(_ label: String, _ urlString: String) {
            str.append(NSAttributedString(string: label, attributes: [
                .link:            URL(string: urlString)!,
                .font:            bodyFont,
                .foregroundColor: NSColor.linkColor
            ]))
        }

        addLink("beacon@eyetechanalytics.com",
                "mailto:beacon@eyetechanalytics.com")
        str.append(NSAttributedString(string: "   ·   ",
                                      attributes: [.font: bodyFont]))
        addLink("eyetechanalytics.com/projects/",
                "https://eyetechanalytics.com/projects/")

        tv.textStorage?.setAttributedString(str)
        alert.accessoryView = tv

        NSApp.activate(ignoringOtherApps: true)
        alert.runModal()
    }

    // MARK: - WebKit Renderer Warm-up

    /// Loads a minimal HTML document in an off-screen, hidden NSWindow so that
    /// WebKit's shared WebContent process is running before the user opens their
    /// first guide.  Both the window and the web view are excluded from the
    /// accessibility hierarchy so VoiceOver cannot see them; the window is never
    /// ordered front so it is invisible to the user.  After 3 s both references
    /// are released and the window is closed; WebKit keeps the process alive.
    private func warmWebKitRenderer() {
        // A 1×1 titled window positioned off the visible screen area.
        // Must exist so WebKit's accessibility tree has a proper parent window —
        // without one, the orphaned tree surfaces as a "system dialog" in the
        // VoiceOver Application Chooser.
        //
        // IMPORTANT: styleMask must include .titled.  A borderless window
        // (styleMask: []) has no AXSubrole (or AXUnknown), which causes VoiceOver
        // to classify the entire application under "System Dialogs" in the
        // VO+F1+F1 Application Chooser.  A .titled window gets AXSubrole =
        // AXStandardWindow, matching the SearchPanel and ContentWindow — so
        // VoiceOver sees only one consistent window type from this process.
        // The window is never ordered front so it is invisible to the user.
        let win = NSWindow(
            contentRect: NSRect(x: -2, y: -2, width: 1, height: 1),
            styleMask:   [.titled],
            backing:     .buffered,
            defer:       false
        )
        win.isReleasedWhenClosed = false
        win.setAccessibilityHidden(true)   // exclude from VoiceOver entirely

        let wv = WKWebView(frame: NSRect(x: 0, y: 0, width: 1, height: 1))
        wv.setAccessibilityHidden(true)
        win.contentView = wv

        webKitWarmupView   = wv
        webKitWarmupWindow = win

        wv.loadHTMLString("<html><body></body></html>", baseURL: nil)

        DispatchQueue.main.asyncAfter(deadline: .now() + 3) { [weak self] in
            self?.webKitWarmupView   = nil
            self?.webKitWarmupWindow?.close()
            self?.webKitWarmupWindow = nil
        }
    }

    // MARK: - New-build Permission Reset

    /// Detects whether the app binary has changed since the last launch (i.e. a
    /// new build was installed) and, if Accessibility permission was previously
    /// granted, removes the now-stale TCC entry and relaunches so the fresh binary
    /// is the one that registers with macOS — giving the user a clean re-grant
    /// prompt linked to the current binary hash.
    ///
    /// Three conditions must ALL be true before a reset happens:
    ///   1. The app has launched at least once before (we have a stored mod date).
    ///   2. The binary's modification date has changed (a new build was installed).
    ///   3. Accessibility permission was previously granted (there is a live TCC
    ///      entry to replace — we never disturb a system that never had one).
    ///
    /// If a reset is triggered this method terminates the process immediately after
    /// scheduling a relaunch; the caller should not do any further work after calling it.
    private func resetPermissionIfNewBuild() {
        guard let execURL = Bundle.main.executableURL,
              let attrs   = try? FileManager.default.attributesOfItem(atPath: execURL.path),
              let modDate = attrs[.modificationDate] as? Date
        else { return }

        let modKey   = "lastBinaryModDate"
        let grantKey = "hasBeenGrantedAccessibility"

        let storedInterval = UserDefaults.standard.double(forKey: modKey)
        // Persist the current binary's mod date for the next launch to compare.
        UserDefaults.standard.set(modDate.timeIntervalSinceReferenceDate, forKey: modKey)

        // If the binary already has Accessibility permission (e.g. stable cert),
        // record that fact so we know to reset on a future rebuild.
        if AXIsProcessTrusted() {
            UserDefaults.standard.set(true, forKey: grantKey)
        }

        // ── Condition 1: not the very first launch ────────────────────────────
        guard storedInterval > 0 else { return }

        // ── Condition 2: binary changed ───────────────────────────────────────
        let storedDate = Date(timeIntervalSinceReferenceDate: storedInterval)
        guard abs(modDate.timeIntervalSince(storedDate)) > 1.0 else { return }

        // ── Condition 3: accessibility was previously granted ─────────────────
        guard UserDefaults.standard.bool(forKey: grantKey) else { return }

        // All three conditions met — clear the grant flag (the relaunched process
        // will set it again once the user re-grants) and remove the stale TCC entry.
        UserDefaults.standard.removeObject(forKey: grantKey)

        let bundleID = Bundle.main.bundleIdentifier ?? "com.eyetechanalytics.BeaconMac"
        let resetTask = Process()
        resetTask.executableURL = URL(fileURLWithPath: "/usr/bin/tccutil")
        resetTask.arguments     = ["reset", "Accessibility", bundleID]
        try? resetTask.run()
        resetTask.waitUntilExit()

        // Relaunch after a brief pause so the new binary is the one that
        // triggers the Accessibility permission prompt in System Settings.
        let safePath    = Bundle.main.bundlePath.replacingOccurrences(of: "'", with: "'\\''")
        let relaunchTask = Process()
        relaunchTask.executableURL = URL(fileURLWithPath: "/bin/sh")
        relaunchTask.arguments     = ["-c", "sleep 0.5 && open '\(safePath)'"]
        try? relaunchTask.run()

        NSApp.terminate(nil)
    }

    // MARK: - First-run Login Item

    /// Silently registers BeaconMac as a login item the very first time the
    /// app launches.  Subsequent launches skip this entirely.
    /// Uses SMAppService (macOS 13+); on macOS 12 this is a no-op — the user
    /// can enable it manually in Preferences.
    private func enableLoginItemOnFirstRun() {
        guard #available(macOS 13.0, *) else { return }
        let key = "hasEnabledLoginItem"
        guard !UserDefaults.standard.bool(forKey: key) else { return }
        UserDefaults.standard.set(true, forKey: key)
        try? SMAppService.mainApp.register()
    }

    @objc private func quitApp() {
        NSApplication.shared.terminate(nil)
    }
}
