// =============================================================================
//  PreferencesWindow.swift — Hotkey Customization UI
//
//  Broadcasts `Notification.Name.bmHotkeyChanged` on the default
//  NotificationCenter whenever the user saves a new hotkey, so AppDelegate
//  can rebuild the menu bar item and refresh the status tooltip.
//
//  Accessible from the menu bar icon → Preferences...
//  Shows the current hotkey and lets the user record a new one.
//  Also exposes a "Launch at Login" toggle.
//
//  Recording flow:
//    1. User presses "Change Hotkey" (Tab to button, then Space/Return)
//    2. Panel enters recording mode (installs NSEvent local monitor)
//    3. User presses desired key combo (e.g. Cmd+Shift+K)
//    4. Combo is displayed; user presses Return/Save or Escape/Cancel
//    5. On Save: persists to UserDefaults + updates GlobalHotkey live
//
//  Launch at Login:
//    Uses SMAppService (macOS 13+).  On macOS 12 the checkbox is disabled
//    with an explanatory note — the API is simply not available there.
// =============================================================================
import AppKit
import ServiceManagement

// MARK: - Notifications

extension Notification.Name {
    /// Posted by PreferencesWindow after the user saves a new hotkey.
    /// AppDelegate observes this to rebuild the menu bar menu and refresh the
    /// status-item tooltip so they always reflect the current hotkey.
    static let bmHotkeyChanged = Notification.Name("com.eyetechanalytics.BeaconMac.hotkeyChanged")
}

// MARK: - PreferencesWindowController

class PreferencesWindowController: NSWindowController, NSWindowDelegate {

    // MARK: Singleton
    static let shared = PreferencesWindowController()

    // MARK: Subviews
    private var hotkeyBadge:       NSTextField!   // Shows e.g. "⌃⌥G"
    private var statusLabel:       NSTextField!   // Instructions / status
    private var changeButton:      NSButton!      // "Change Hotkey" / "Cancel"
    private var saveButton:        NSButton!
    private var cancelButton:      NSButton!
    private var startAtLoginCheck: NSButton!      // Launch at Login checkbox
    private var versionLabel:      NSTextField!   // e.g. "Version 1.0.0"
    private var checkUpdateButton: NSButton!      // "Check for Updates"

    // MARK: State
    private var pendingSetting:      HotkeySetting?
    /// Tracks a not-yet-committed change to the "Launch at Login" checkbox.
    /// nil = no pending change. true/false = the user toggled it but hasn't saved yet.
    private var pendingLoginEnabled: Bool?
    private var localMonitor:        Any?
    private var isRecording = false

    // MARK: - Init

    private init() {
        let w = NSWindow(
            contentRect: NSRect(x: 0, y: 0, width: 420, height: 330),
            styleMask: [.titled, .closable],
            backing: .buffered,
            defer: false
        )
        w.title = "BeaconMac Preferences"
        w.isReleasedWhenClosed = false
        super.init(window: w)
        w.delegate = self
        buildUI()
    }

    required init?(coder: NSCoder) { fatalError() }

    // MARK: - Build UI

    private func buildUI() {
        // Fail loudly if the window's contentView is missing.  Silently
        // returning here would leave every IUO subview property (hotkeyBadge,
        // statusLabel, changeButton, etc.) nil and crash the first time the
        // Preferences window was shown — with an error far from the real
        // cause.  NSWindow always has a contentView once its init returns.
        guard let cv = window?.contentView else {
            fatalError("PreferencesWindowController.buildUI() called before window.contentView was available")
        }

        // ── Section title ────────────────────────────────────────────────────
        let sectionLabel = makeLabel("Global Hotkey", size: 12, weight: .semibold)
        sectionLabel.textColor = .secondaryLabelColor
        cv.addSubview(sectionLabel)

        // ── Hotkey badge ─────────────────────────────────────────────────────
        hotkeyBadge = makeLabel("⌃⌥G", size: 22, weight: .medium)
        hotkeyBadge.alignment = .center
        hotkeyBadge.font = NSFont.monospacedSystemFont(ofSize: 22, weight: .medium)
        hotkeyBadge.wantsLayer = true
        hotkeyBadge.layer?.cornerRadius = 8
        hotkeyBadge.layer?.borderWidth  = 1.5
        hotkeyBadge.layer?.borderColor  = NSColor.separatorColor.cgColor
        hotkeyBadge.backgroundColor     = NSColor.controlBackgroundColor
        hotkeyBadge.drawsBackground     = true
        cv.addSubview(hotkeyBadge)

        // ── Status / instruction label ───────────────────────────────────────
        statusLabel = makeLabel("Press \u{201C}Change Hotkey\u{201D} and then press your desired key combination.", size: 11.5, weight: .regular)
        statusLabel.textColor    = .secondaryLabelColor
        statusLabel.lineBreakMode = .byWordWrapping
        statusLabel.maximumNumberOfLines = 2
        cv.addSubview(statusLabel)

        // ── Change / Cancel button ───────────────────────────────────────────
        changeButton = NSButton(title: "Change Hotkey", target: self, action: #selector(changeOrCancelTapped))
        changeButton.bezelStyle = .rounded
        cv.addSubview(changeButton)

        // ── Save button ──────────────────────────────────────────────────────
        saveButton = NSButton(title: "Save", target: self, action: #selector(saveTapped))
        saveButton.bezelStyle    = .rounded
        saveButton.keyEquivalent = "\r"
        saveButton.isEnabled     = false
        cv.addSubview(saveButton)

        // ── Cancel (close) button ────────────────────────────────────────────
        cancelButton = NSButton(title: "Cancel", target: self, action: #selector(cancelTapped))
        cancelButton.bezelStyle    = .rounded
        cancelButton.keyEquivalent = "\u{1b}"   // Escape
        cv.addSubview(cancelButton)

        // ── Divider ──────────────────────────────────────────────────────────
        let divider = NSBox()
        divider.boxType = .separator
        cv.addSubview(divider)

        // ── Startup section title ─────────────────────────────────────────────
        let startupLabel = makeLabel("Startup", size: 12, weight: .semibold)
        startupLabel.textColor = .secondaryLabelColor
        cv.addSubview(startupLabel)

        // ── Launch at Login checkbox ──────────────────────────────────────────
        startAtLoginCheck = NSButton(checkboxWithTitle: "Launch BeaconMac at login",
                                     target: self,
                                     action: #selector(startAtLoginToggled))
        if #available(macOS 13.0, *) {
            startAtLoginCheck.isEnabled = true
        } else {
            // SMAppService requires macOS 13 — disable with a tooltip on older systems
            startAtLoginCheck.isEnabled = false
            startAtLoginCheck.toolTip   = "Requires macOS Ventura (13.0) or later"
        }
        cv.addSubview(startAtLoginCheck)

        // ── "Requires macOS 13" note (shown only on macOS 12) ────────────────
        let loginNoteText: String
        if #available(macOS 13.0, *) {
            loginNoteText = ""
        } else {
            loginNoteText = "Requires macOS Ventura or later"
        }
        let loginNote = makeLabel(loginNoteText, size: 10.5, weight: .regular)
        loginNote.textColor = NSColor.tertiaryLabelColor
        cv.addSubview(loginNote)

        // ── Second divider ────────────────────────────────────────────────────
        let divider2 = NSBox()
        divider2.boxType = .separator
        cv.addSubview(divider2)

        // ── About / version section title ─────────────────────────────────────
        let aboutLabel = makeLabel("About", size: 12, weight: .semibold)
        aboutLabel.textColor = .secondaryLabelColor
        cv.addSubview(aboutLabel)

        // ── Version label ─────────────────────────────────────────────────────
        versionLabel = makeLabel("Version \(UpdateChecker.currentVersion)",
                                 size: 13, weight: .regular)
        versionLabel.textColor = .labelColor
        cv.addSubview(versionLabel)

        // ── Check for Updates button ──────────────────────────────────────────
        checkUpdateButton = NSButton(title: "Check for Updates",
                                     target: self,
                                     action: #selector(checkForUpdatesTapped))
        checkUpdateButton.bezelStyle = .rounded
        cv.addSubview(checkUpdateButton)

        // ── Layout ───────────────────────────────────────────────────────────
        [sectionLabel, hotkeyBadge, statusLabel, changeButton,
         divider, startupLabel, startAtLoginCheck, loginNote,
         divider2, aboutLabel, versionLabel, checkUpdateButton,
         saveButton, cancelButton].forEach {
            $0.translatesAutoresizingMaskIntoConstraints = false
        }

        NSLayoutConstraint.activate([
            // Section title
            sectionLabel.topAnchor.constraint(equalTo: cv.topAnchor, constant: 20),
            sectionLabel.leadingAnchor.constraint(equalTo: cv.leadingAnchor, constant: 20),

            // Badge (left column)
            hotkeyBadge.topAnchor.constraint(equalTo: sectionLabel.bottomAnchor, constant: 10),
            hotkeyBadge.leadingAnchor.constraint(equalTo: cv.leadingAnchor, constant: 20),
            hotkeyBadge.widthAnchor.constraint(equalToConstant: 100),
            hotkeyBadge.heightAnchor.constraint(equalToConstant: 52),

            // Status label (right of badge)
            statusLabel.centerYAnchor.constraint(equalTo: hotkeyBadge.centerYAnchor),
            statusLabel.leadingAnchor.constraint(equalTo: hotkeyBadge.trailingAnchor, constant: 16),
            statusLabel.trailingAnchor.constraint(equalTo: changeButton.leadingAnchor, constant: -12),

            // Change/Cancel button (right column)
            changeButton.centerYAnchor.constraint(equalTo: hotkeyBadge.centerYAnchor),
            changeButton.trailingAnchor.constraint(equalTo: cv.trailingAnchor, constant: -20),
            changeButton.widthAnchor.constraint(equalToConstant: 130),

            // Divider
            divider.topAnchor.constraint(equalTo: hotkeyBadge.bottomAnchor, constant: 18),
            divider.leadingAnchor.constraint(equalTo: cv.leadingAnchor, constant: 20),
            divider.trailingAnchor.constraint(equalTo: cv.trailingAnchor, constant: -20),

            // Startup label
            startupLabel.topAnchor.constraint(equalTo: divider.bottomAnchor, constant: 12),
            startupLabel.leadingAnchor.constraint(equalTo: cv.leadingAnchor, constant: 20),

            // Checkbox
            startAtLoginCheck.topAnchor.constraint(equalTo: startupLabel.bottomAnchor, constant: 8),
            startAtLoginCheck.leadingAnchor.constraint(equalTo: cv.leadingAnchor, constant: 20),

            // Note (sits to the right of the checkbox on macOS 12; empty on 13+)
            loginNote.centerYAnchor.constraint(equalTo: startAtLoginCheck.centerYAnchor),
            loginNote.leadingAnchor.constraint(equalTo: startAtLoginCheck.trailingAnchor, constant: 10),

            // Second divider
            divider2.topAnchor.constraint(equalTo: startAtLoginCheck.bottomAnchor, constant: 12),
            divider2.leadingAnchor.constraint(equalTo: cv.leadingAnchor, constant: 20),
            divider2.trailingAnchor.constraint(equalTo: cv.trailingAnchor, constant: -20),

            // About section title
            aboutLabel.topAnchor.constraint(equalTo: divider2.bottomAnchor, constant: 12),
            aboutLabel.leadingAnchor.constraint(equalTo: cv.leadingAnchor, constant: 20),

            // Version label (left) + Check for Updates button (right)
            versionLabel.topAnchor.constraint(equalTo: aboutLabel.bottomAnchor, constant: 8),
            versionLabel.leadingAnchor.constraint(equalTo: cv.leadingAnchor, constant: 20),
            versionLabel.centerYAnchor.constraint(equalTo: checkUpdateButton.centerYAnchor),

            checkUpdateButton.trailingAnchor.constraint(equalTo: cv.trailingAnchor, constant: -20),
            checkUpdateButton.topAnchor.constraint(equalTo: aboutLabel.bottomAnchor, constant: 4),
            checkUpdateButton.widthAnchor.constraint(equalToConstant: 150),

            // Bottom buttons
            saveButton.bottomAnchor.constraint(equalTo: cv.bottomAnchor, constant: -18),
            saveButton.trailingAnchor.constraint(equalTo: cv.trailingAnchor, constant: -20),
            saveButton.widthAnchor.constraint(equalToConstant: 80),

            cancelButton.bottomAnchor.constraint(equalTo: cv.bottomAnchor, constant: -18),
            cancelButton.trailingAnchor.constraint(equalTo: saveButton.leadingAnchor, constant: -10),
            cancelButton.widthAnchor.constraint(equalToConstant: 80),
        ])
    }

    // MARK: - Show

    func showPreferences() {
        window?.center()
        window?.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
        refreshDisplay(with: GlobalHotkey.shared.currentSetting)
        pendingSetting      = nil
        pendingLoginEnabled = nil
        saveButton.isEnabled = false
        if isRecording { stopRecording(save: false) }
        // Sync the checkbox to the current login-item registration state
        if #available(macOS 13.0, *) {
            let registered = SMAppService.mainApp.status == .enabled
            startAtLoginCheck.state = registered ? .on : .off
        }
    }

    private func refreshDisplay(with setting: HotkeySetting) {
        hotkeyBadge.stringValue = setting.displayString
        statusLabel.stringValue = "Press \u{201C}Change Hotkey\u{201D} and then press your desired key combination."
        statusLabel.textColor   = .secondaryLabelColor
        changeButton.title      = "Change Hotkey"
    }

    // MARK: - Recording

    @objc private func changeOrCancelTapped() {
        if isRecording {
            stopRecording(save: false)
        } else {
            startRecording()
        }
    }

    private func startRecording() {
        isRecording = true
        pendingSetting = nil
        saveButton.isEnabled = false
        changeButton.title   = "Cancel"

        hotkeyBadge.stringValue = "..."
        statusLabel.stringValue = "Press your new key combination now.  Escape = cancel."
        statusLabel.textColor   = .labelColor

        // Suppress the current hotkey while recording
        GlobalHotkey.shared.suppressFiring = true

        // Install a local monitor to capture keys while Preferences window is key
        localMonitor = NSEvent.addLocalMonitorForEvents(matching: .keyDown) { [weak self] event in
            self?.handleRecordedKey(event)
            return nil   // Consume so it doesn't type into the window
        }
    }

    private func handleRecordedKey(_ event: NSEvent) {
        // Escape = cancel recording
        if event.keyCode == 53 {
            stopRecording(save: false)
            return
        }

        // Build the setting from the event
        if let setting = HotkeySetting.fromEvent(event) {
            pendingSetting = setting
            stopRecording(save: false)

            // Update the display to show the pending combo
            hotkeyBadge.stringValue = setting.displayString
            hotkeyBadge.layer?.borderColor = NSColor.controlAccentColor.cgColor
            statusLabel.stringValue = "New hotkey: \(setting.displayString) — press Return or Save to apply."
            statusLabel.textColor   = .labelColor
            saveButton.isEnabled    = true
        } else {
            // Modifier-only or invalid — show hint
            statusLabel.stringValue = "Please include at least one modifier key (⌃⌥⌘⇧) plus a character."
            statusLabel.textColor   = .systemOrange
        }
    }

    private func stopRecording(save: Bool) {
        isRecording = false
        GlobalHotkey.shared.suppressFiring = false

        if let monitor = localMonitor {
            NSEvent.removeMonitor(monitor)
            localMonitor = nil
        }

        changeButton.title = "Change Hotkey"

        if !save {
            // Reset border color if no pending setting was kept
            hotkeyBadge.layer?.borderColor = NSColor.separatorColor.cgColor
            if pendingSetting == nil {
                refreshDisplay(with: GlobalHotkey.shared.currentSetting)
            }
        }
    }

    // MARK: - Launch at Login

    @objc private func startAtLoginToggled() {
        guard #available(macOS 13.0, *) else { return }
        // Store the intended state but don't commit it yet — Save will apply it.
        // This keeps the checkbox interactive so the user sees the toggle move,
        // while Save/Cancel decide whether the change is kept.
        let intendedState = startAtLoginCheck.state == .on
        let currentlyRegistered = SMAppService.mainApp.status == .enabled

        if intendedState != currentlyRegistered {
            pendingLoginEnabled = intendedState
        } else {
            // Toggled back to the already-committed state — no pending change
            pendingLoginEnabled = nil
        }

        // Enable Save whenever there is either a pending hotkey OR a pending login change
        saveButton.isEnabled = (pendingSetting != nil || pendingLoginEnabled != nil)
    }

    // MARK: - Save / Cancel

    @objc private func checkForUpdatesTapped() {
        UpdateChecker.checkForUpdates(silent: false)
    }

    @objc private func saveTapped() {
        // ── Apply pending hotkey change ────────────────────────────────────────
        if let setting = pendingSetting {
            setting.saveToDefaults()
            GlobalHotkey.shared.updateSetting(setting)
            hotkeyBadge.layer?.borderColor = NSColor.separatorColor.cgColor
            refreshDisplay(with: setting)
            pendingSetting = nil
            // Notify the rest of the app (e.g. AppDelegate's menu bar item)
            // that the hotkey has changed so UI displaying the hotkey can refresh.
            NotificationCenter.default.post(name: .bmHotkeyChanged, object: nil)
        }

        // ── Apply pending login item change ────────────────────────────────────
        if #available(macOS 13.0, *), let enable = pendingLoginEnabled {
            do {
                if enable {
                    try SMAppService.mainApp.register()
                } else {
                    try SMAppService.mainApp.unregister()
                }
            } catch {
                // Revert the checkbox to the actual registered state
                let registered = SMAppService.mainApp.status == .enabled
                startAtLoginCheck.state = registered ? .on : .off

                let alert = NSAlert()
                alert.messageText     = enable ? "Could Not Enable Launch at Login"
                                               : "Could Not Disable Launch at Login"
                alert.informativeText = error.localizedDescription
                alert.alertStyle      = .warning
                alert.addButton(withTitle: "OK")
                alert.runModal()
            }
            pendingLoginEnabled = nil
        }

        saveButton.isEnabled = false
    }

    @objc private func cancelTapped() {
        stopRecording(save: false)
        // Revert any uncommitted checkbox change
        if #available(macOS 13.0, *), pendingLoginEnabled != nil {
            let registered = SMAppService.mainApp.status == .enabled
            startAtLoginCheck.state = registered ? .on : .off
            pendingLoginEnabled = nil
        }
        window?.close()
    }

    // MARK: - NSWindowDelegate

    func windowWillClose(_ notification: Notification) {
        // Clean up if closed mid-recording
        if isRecording { stopRecording(save: false) }
    }

    // MARK: - Helpers

    private func makeLabel(_ text: String, size: CGFloat, weight: NSFont.Weight) -> NSTextField {
        let f = NSTextField(labelWithString: text)
        f.font = NSFont.systemFont(ofSize: size, weight: weight)
        f.isEditable   = false
        f.isSelectable = false
        f.isBordered   = false
        f.drawsBackground = false
        return f
    }
}
