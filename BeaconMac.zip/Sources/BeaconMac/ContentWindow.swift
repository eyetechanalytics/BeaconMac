// =============================================================================
//  ContentWindow.swift — NSWindow + WKWebView for displaying shortcut content
//
//  WKWebView is used (rather than a plain NSTextView) because VoiceOver's
//  H-key heading navigation and aria-label structured reading only work with
//  HTML content.  There is no AppKit-native equivalent.
//
//  ACCESSIBILITY LABEL NOTE — the root cause of BeaconMac appearing as
//  "Safari" in VoiceOver's VO+F1+F1 Application Chooser was the line:
//      self.setAccessibilityLabel("\(guide.title) shortcut guide")
//  VoiceOver reads AXLabel (not AXTitle) when both are set, so the chooser
//  announced "Safari shortcut guide" (or whatever guide was open) rather than
//  the BeaconMac app name.  Fixed by prefixing every label with "BeaconMac — ".
// =============================================================================
import AppKit
import WebKit

class ContentWindow: NSWindow, NSWindowDelegate {

    // MARK: - Dimensions

    private static let defaultWidth:  CGFloat = 820
    private static let defaultHeight: CGFloat = 680

    // MARK: - Cascade origin (so multiple windows don't stack on top of each other)

    private static var lastCascadeOrigin = NSPoint(x: 0, y: 0)

    /// Called when this window closes (via Escape, close button, or programmatically).
    /// AppDelegate uses this to re-show the search panel so the user can return to the list.
    var onClose: (() -> Void)?

    /// Stored so we can move VoiceOver focus into the web content after the page loads.
    private var webView: WKWebView!

    // MARK: - Init

    init(guide: ShortcutGuide) {
        let rect = NSRect(x: 0, y: 0,
                          width:  ContentWindow.defaultWidth,
                          height: ContentWindow.defaultHeight)

        super.init(
            contentRect: rect,
            styleMask:   [.titled, .closable, .resizable, .miniaturizable],
            backing:     .buffered,
            defer:       false
        )

        // Prefix the title so VoiceOver's VO+F1+F1 Application Chooser reads
        // "BeaconMac — [guide name]" rather than just the guide name alone.
        self.title                = "BeaconMac — \(guide.title)"
        self.isReleasedWhenClosed = false   // We release manually in windowWillClose
        self.minSize              = NSSize(width: 500, height: 400)
        self.delegate             = self

        // VoiceOver: prefix all accessibility labels with "BeaconMac — " so that
        // VO+F1+F1 always announces this window as belonging to BeaconMac, not as
        // "[guide title]" (which VoiceOver would read as the app/window name).
        self.setAccessibilityLabel("BeaconMac — \(guide.title) shortcut guide")
        self.setAccessibilityHelp("Press Escape to return to the guide list")

        setupWebView(for: guide)
        positionWindow()
    }

    // MARK: - WebView

    private func setupWebView(for guide: ShortcutGuide) {
        // Fail loudly if contentView is missing.  NSWindow always has a
        // contentView once super.init(contentRect:...) has returned, so this
        // should never trip — but a silent fallback here would leave the
        // webView IUO nil and crash much later, far from the real cause.
        guard let cv = contentView else {
            fatalError("ContentWindow.setupWebView() called before contentView was available")
        }

        let config = WKWebViewConfiguration()
        config.preferences.setValue(true, forKey: "allowFileAccessFromFileURLs")

        webView = WKWebView(frame: cv.bounds, configuration: config)
        webView.autoresizingMask   = [.width, .height]
        webView.navigationDelegate = self

        // VoiceOver: label the web view so it is introduced meaningfully
        webView.setAccessibilityLabel("BeaconMac — \(guide.title) shortcuts")
        webView.setAccessibilityHelp(
            "Shortcut reference for \(guide.title). " +
            "Use VoiceOver navigation commands to read the content. " +
            "Press Escape to close and return to the guide list."
        )

        // Dark mode: WKWebView reads the system appearance via CSS prefers-color-scheme
        if #available(macOS 12.0, *) {
            webView.underPageBackgroundColor = .windowBackgroundColor
        }

        cv.addSubview(webView)

        let html = HTMLGenerator.generate(for: guide)
        webView.loadHTMLString(html, baseURL: nil)
    }

    // MARK: - Positioning (cascade so multiple windows are visible)

    private func positionWindow() {
        if ContentWindow.lastCascadeOrigin == .zero {
            // First window: center on main screen
            if let screen = NSScreen.main {
                let sf = screen.visibleFrame
                let ox = sf.midX - frame.width  / 2
                let oy = sf.midY - frame.height / 2
                ContentWindow.lastCascadeOrigin = NSPoint(x: ox, y: oy)
            }
        }
        ContentWindow.lastCascadeOrigin = cascadeTopLeft(from: ContentWindow.lastCascadeOrigin)
    }

    // MARK: - Focus Handoff

    /// Transfers AppKit keyboard focus to the web view immediately.
    /// Called by AppDelegate right after makeKeyAndOrderFront so that arrow
    /// keys reach the JavaScript keydown listener with no gap, even before
    /// the HTML has finished loading.  The webView(_:didFinish:) callback
    /// re-asserts focus as a safety net in case something stole it in the
    /// interim (e.g. VoiceOver announcing a new window on first launch).
    func focusWebView() {
        makeFirstResponder(webView)
    }

    // MARK: - Keyboard: Escape closes window

    override func keyDown(with event: NSEvent) {
        if event.keyCode == 53 {   // Escape
            close()
        } else {
            super.keyDown(with: event)
        }
    }

    // MARK: - NSWindowDelegate

    func windowWillClose(_ notification: Notification) {
        // Notify AppDelegate so it can re-show the search panel.
        // Fire async so the window has fully dismissed before the panel appears.
        let callback = onClose
        DispatchQueue.main.async { callback?() }
    }
}

// MARK: - WKNavigationDelegate

extension ContentWindow: WKNavigationDelegate {

    /// Intercepts link clicks inside the web view.
    /// URLs (http/https) open in the default browser; mailto: opens in the default mail client.
    /// All other navigation (initial page load) is allowed through normally.
    func webView(_ webView: WKWebView,
                 decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard navigationAction.navigationType == .linkActivated,
              let url = navigationAction.request.url,
              let scheme = url.scheme,
              ["https", "http", "mailto"].contains(scheme) else {
            decisionHandler(.allow)
            return
        }
        NSWorkspace.shared.open(url)
        decisionHandler(.cancel)
    }

    /// Called when the HTML page has fully loaded inside the web view.
    /// Keyboard focus is re-asserted immediately (one run-loop tick) so that
    /// arrow keys work as soon as content is visible.  VoiceOver's cursor is
    /// moved into the web content after an additional 150 ms delay, which
    /// WebKit needs to finish constructing its accessibility tree.
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        // ── Phase 1: keyboard focus (one run-loop tick) ───────────────────────
        // focusWebView() was already called in openContentWindow, so in the
        // typical case this is a no-op.  It is repeated here as a safety net
        // for edge cases where focus was stolen between openContentWindow and
        // now — e.g. VoiceOver announcing the new window on first app launch,
        // or the Accessibility permission dialog appearing mid-navigation.
        // Using async (not asyncAfter) keeps the gap as short as possible so
        // the user cannot press arrow keys and get system beeps.
        DispatchQueue.main.async { [weak self] in
            guard let self = self, self.isVisible else { return }
            self.makeKeyAndOrderFront(nil)
            NSApp.activate(ignoringOtherApps: true)
            self.makeFirstResponder(webView)
            // NOTE: NSAccessibility.post(.focusedUIElementChanged) on the webView
            // is intentionally NOT called here.
            //
            // Posting it here anchors VoiceOver's cursor at the WKWebView AppKit
            // container element (the "web area" wrapper), NOT inside the HTML
            // content.  From that anchor, Phase 2's JS t.focus() call fires 500 ms
            // later and moves the DOM focus to #vo-focus-target, but VoiceOver's
            // cursor is already locked to the AppKit-level web area and does not
            // follow the DOM focus change — leaving the VO cursor outside the web
            // content and breaking H-key heading navigation and Up/Down cycling.
            //
            // makeFirstResponder(webView) alone is sufficient for AppKit keyboard
            // focus (arrow keys reach the JS keydown listener).  VoiceOver's cursor
            // is moved inside the web content by Phase 2's JS focus() call, which
            // fires after WebKit's accessibility tree has finished constructing.
            // That JS-triggered focus change generates a DOM focusin event that
            // VoiceOver's WebKit bridge converts into a proper AX focus notification
            // scoped to the element inside the page — the correct anchor point.
        }

        // ── Phase 1.5: assert window activation (two attempts) ───────────────
        //
        // Background
        // ──────────
        // SearchPanel → ContentWindow is an intra-app window transition.  VoiceOver
        // does not reliably move its cursor to the new window during intra-app
        // transitions the way it does for inter-app or fresh activations.
        //
        // Posting .focusedWindowChanged on NSApp tells VoiceOver "the focused
        // window has changed"; VoiceOver then queries NSApp.AXFocusedWindow, finds
        // ContentWindow, and moves its cursor to the web area — without "locking"
        // it there (as would happen if we posted .focusedUIElementChanged on the
        // webView element directly).  From that natural position Phase 2's JS
        // focus() can move the cursor inside the web content.
        //
        // Two attempts (0.35 s and 0.7 s) are used because VoiceOver processes
        // window events asynchronously.  If the first post arrives before VoiceOver
        // has finished dismissing SearchPanel, it may be ignored.  The second post
        // at 0.7 s catches that case.  Phase 2's JS focus begins at 1.0 s — after
        // both window-change notifications have fired — so VoiceOver always has at
        // least one successfully-processed window-change notification before the
        // first JS focus attempt.
        for windowDelay in [0.35, 0.7] as [Double] {
            DispatchQueue.main.asyncAfter(deadline: .now() + windowDelay) { [weak self] in
                guard let self = self, self.isVisible else { return }
                NSAccessibility.post(element: NSApplication.shared,
                                     notification: .focusedWindowChanged)
            }
        }

        // ── Phase 2: VoiceOver cursor inside web content (five attempts) ──────
        //
        // How it works
        // ─────────────
        // WebKit builds its AX tree asynchronously after didFinish.  A premature
        // focus() call lands before the tree is ready and is silently dropped;
        // VoiceOver's cursor stays at the AXWebArea container level, requiring the
        // user to press H before heading navigation works.
        //
        // blur() + focus() (with a 50 ms gap) produces a fresh DOM focusin event
        // that WebKit's AX bridge converts into a VoiceOver cursor move scoped to
        // the element inside the page — the correct anchor.
        //
        // Why no document.activeElement check
        // ─────────────────────────────────────
        // A naive optimisation would skip the blur/focus cycle once the element
        // already has DOM focus.  This is WRONG: VoiceOver's cursor position is
        // independent of DOM focus.  The failure mode is:
        //   • JS focus fires at 1.0 s → DOM receives focus (activeElement === t)
        //   • VoiceOver hasn't finished processing the window-change yet; it
        //     ignores the focusin event and stays at the AXWebArea wrapper level.
        //   • Retry at 1.7 s → activeElement === t → "already focused" → skipped.
        //   • VoiceOver is still at the wrapper. User must press H.
        // Omitting the check ensures each retry fires a fresh DOM focus event that
        // VoiceOver can respond to once it has settled on ContentWindow.  If VO
        // already entered at 1.0 s and a later retry re-announces the heading,
        // that is a minor nuisance and far preferable to forcing the user to press H.
        //
        // Five attempts (1.0 s, 1.7 s, 2.5 s, 3.5 s, 5.0 s) cover the range from
        // fast Macs to heavy first-launch event bursts.  The isVisible guard ensures
        // retries stop if the window is closed before they fire.
        //
        // WHY window._bmFocusDone:
        // Each blur/focus cycle fires a DOM focusin event that VoiceOver converts into
        // a cursor-move + announcement ("heading level 1, <title>").  Without the flag
        // all five retries would each trigger a fresh announcement, causing the heading
        // to be read 3–5 times in a row.  Setting the flag before t.focus() means only
        // the first retry that actually runs does the blur/focus; every subsequent call
        // is a silent no-op.  The focusedWindowChanged notifications above (Phase 1.5)
        // still fire on their own schedule to re-orient VoiceOver toward the window —
        // those are silent and are unaffected by this flag.
        let focusScript = """
            (function() {
                var t = document.getElementById('vo-focus-target');
                if (!t || window._bmFocusDone) return;
                window._bmFocusDone = true;
                t.blur();
                setTimeout(function(){ if (t.isConnected) t.focus(); }, 50);
            })();
            """
        for focusDelay in [1.0, 1.7, 2.5, 3.5, 5.0] as [Double] {
            DispatchQueue.main.asyncAfter(deadline: .now() + focusDelay) { [weak self] in
                guard let self = self, self.isVisible else { return }
                webView.evaluateJavaScript(focusScript) { _, _ in }
            }
        }
    }
}
