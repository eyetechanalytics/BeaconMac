// =============================================================================
//  AppDetector.swift — Focus-Aware App Detection
//
//  When the hotkey fires, detects which app was frontmost and returns a
//  search query pre-populating the panel with that app's relevant guides.
//
//  Usage:
//    let query = AppDetector.searchQuery(for: NSWorkspace.shared.frontmostApplication)
//    searchPanel.showPanel(initialQuery: query)
// =============================================================================
import AppKit

enum AppDetector {

    // MARK: - Public API

    /// Returns a search query string for the given running application,
    /// or nil if no matching shortcut guide exists.
    static func searchQuery(for app: NSRunningApplication?) -> String? {
        guard let app = app else { return nil }

        // Never pre-filter for ourselves
        let myID = Bundle.main.bundleIdentifier ?? "com.eyetechanalytics.BeaconMac"
        if (app.bundleIdentifier ?? "") == myID { return nil }

        let bundleID = (app.bundleIdentifier ?? "").lowercased()
        let appName  = (app.localizedName  ?? "").lowercased()

        // ── Bundle ID lookup (most reliable) ────────────────────────────────
        for (pattern, query) in bundleIDMap {
            if bundleID.contains(pattern) { return query }
        }

        // ── App name fallback ────────────────────────────────────────────────
        for (pattern, query) in appNameMap {
            if appName.contains(pattern) { return query }
        }

        return nil  // No match — panel opens with empty search
    }

    // MARK: - Bundle ID → Search Query

    /// Keys are lowercased substrings of the bundle ID.
    /// Values are the search string to pre-fill in the panel.
    private static let bundleIDMap: [(String, String)] = [
        // macOS Built-in Apps
        ("com.apple.finder",            "Finder"),
        ("com.apple.safari",            "Safari"),
        ("com.apple.mail",              "Mail"),
        ("com.apple.ical",              "Calendar"),
        ("com.apple.notes",             "Notes"),
        ("com.apple.photos",            "Photos"),
        ("com.apple.preview",           "Preview"),
        ("com.apple.terminal",          "Terminal"),
        ("com.apple.textedit",          "TextEdit"),
        ("com.apple.calculator",        "Calculator"),
        ("com.apple.maps",              "Maps"),
        ("com.apple.systempreferences", "Settings"),
        ("com.apple.activitymonitor",   "Activity Monitor"),
        ("com.apple.quicktimeplayer",   "QuickTime"),
        ("com.apple.dt.xcode",          "Xcode"),

        // Apple iWork
        ("com.apple.iwork.pages",       "Pages"),
        ("com.apple.iwork.numbers",     "Numbers"),
        ("com.apple.iwork.keynote",     "Keynote"),

        // Microsoft Office for Mac
        ("com.microsoft.word",          "Word"),
        ("com.microsoft.excel",         "Excel"),
        ("com.microsoft.powerpoint",    "PowerPoint"),
        ("com.microsoft.outlook",       "Outlook"),
        ("com.microsoft.onenote",       "OneNote"),
        ("com.microsoft.teams",         "Teams"),
        ("com.microsoft.onedrive",      "OneDrive"),

        // Google Chrome (catches Chrome + Chrome Canary etc.)
        ("com.google.chrome",           "Chrome"),

        // Firefox
        ("org.mozilla.firefox",         "Firefox"),
        ("org.mozilla.nightly",         "Firefox"),

        // Zoom
        ("us.zoom.xos",                 "Zoom"),

        // Adobe
        ("com.adobe.acrobat",           "Adobe"),
        ("com.adobe.reader",            "Adobe"),

        // VLC
        ("org.videolan.vlc",            "VLC"),

        // Spotify
        ("com.spotify.client",          "Spotify"),

        // Slack
        ("com.tinyspeck.slackmacgap",   "Slack"),

        // VS Code (stable, Insiders, and Codium variants)
        ("com.microsoft.vscode",        "VS Code"),
        ("com.visualstudio.code",       "VS Code"),
        ("com.vscodium",                "VS Code"),

        // iTerm2
        ("com.googlecode.iterm2",       "Terminal"),
    ]

    // MARK: - App Name → Search Query (fallback)

    /// Keys are lowercased substrings of the app's localized name.
    private static let appNameMap: [(String, String)] = [
        ("finder",          "Finder"),
        ("safari",          "Safari"),
        ("mail",            "Mail"),
        ("calendar",        "Calendar"),
        ("notes",           "Notes"),
        ("photos",          "Photos"),
        ("preview",         "Preview"),
        ("terminal",        "Terminal"),
        ("textedit",        "TextEdit"),
        ("quicktime",       "QuickTime"),
        ("xcode",           "Xcode"),
        // Apple iWork
        ("pages",           "Pages"),
        ("numbers",         "Numbers"),
        ("keynote",         "Keynote"),
        // Microsoft Office
        ("excel",           "Excel"),
        ("word",            "Word"),
        ("powerpoint",      "PowerPoint"),
        ("outlook",         "Outlook"),
        ("onenote",         "OneNote"),
        ("teams",           "Teams"),
        ("onedrive",        "OneDrive"),
        // Browsers
        ("chrome",          "Chrome"),
        ("firefox",         "Firefox"),
        // Other apps
        ("zoom",            "Zoom"),
        ("acrobat",         "Adobe"),
        ("adobe reader",    "Adobe"),
        ("vlc",             "VLC"),
        ("spotify",         "Spotify"),
        ("slack",           "Slack"),
        ("visual studio code", "VS Code"),
        ("vscodium",        "VS Code"),
        ("iterm",           "Terminal"),
    ]
}
