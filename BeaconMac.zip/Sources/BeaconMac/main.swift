// =============================================================================
//  main.swift — BeaconMac Entry Point
// =============================================================================
import AppKit

// Create and configure the NSApplication instance
let app = NSApplication.shared
// DO NOT set .accessory here, and do NOT set it anywhere else at runtime.
//
// BeaconMac runs permanently as a .regular application.  This is intentional:
//
//   • Calling setActivationPolicy(.accessory) — whether here before app.run()
//     or later from AppDelegate — stamps the process as a background agent in
//     macOS's process database.  VoiceOver then classifies BeaconMac under
//     "System Dialogs" in the VO+F1+F1 Application Chooser instead of listing
//     it as "BeaconMac", even after a subsequent switch back to .regular.
//     VoiceOver caches the policy during transitions; the damage is permanent
//     for the life of the process.
//
//   • Staying .regular costs nothing visually: the Dock icon only appears
//     while a window is on-screen (our SearchPanel or a ContentWindow), and
//     disappears automatically once all windows are hidden.  A .regular
//     app with no visible windows is behaviourally identical to an .accessory
//     app with no visible windows, minus the VoiceOver regression above.
//
// AppDelegate re-asserts .regular in toggleSearchPanel(), openGuide(), and
// openContentWindow() purely as a defensive belt-and-braces measure; none of
// those calls change the policy in practice because it's already .regular
// from launch.  See the comment on restorePreviousApp() in AppDelegate.swift
// for the full rationale.

// Attach the delegate before running
let delegate = AppDelegate()
app.delegate = delegate

// Start the event loop (blocks until quit)
app.run()
