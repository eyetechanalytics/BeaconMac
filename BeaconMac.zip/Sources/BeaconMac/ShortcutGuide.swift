// =============================================================================
//  ShortcutGuide.swift — Data Model
// =============================================================================
import Foundation

/// A single keyboard shortcut reference guide.
/// Content is provided as a lazy closure so it's only evaluated when opened.
struct ShortcutGuide {
    let id: String
    let title: String
    let description: String
    let category: String
    let content: () -> String
}
