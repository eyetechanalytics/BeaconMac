#!/bin/bash
# =============================================================================
#  create-dmg.sh — Build BeaconMac and package it as a distributable .dmg
#
#  Usage:
#    chmod +x create-dmg.sh
#    ./create-dmg.sh
#
#  Output:  BeaconMac-<VERSION>.dmg  (in the same folder as this script)
#
#  Requirements:
#    • Xcode Command Line Tools  (xcode-select --install)
#    • hdiutil  (ships with macOS — no extra install needed)
#
#  The resulting DMG opens to a Finder window showing BeaconMac.app with a
#  shortcut to /Applications so the user can drag-and-drop to install.
# =============================================================================

set -e

APP_NAME="BeaconMac"
VERSION="1.0.0"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
APP_BUNDLE="$SCRIPT_DIR/$APP_NAME.app"
DMG_NAME="$APP_NAME-$VERSION.dmg"
DMG_PATH="$SCRIPT_DIR/$DMG_NAME"

# ── Step 1: Build the .app (calls existing build script) ────────────────────
echo ""
echo "══════════════════════════════════════════"
echo "  BeaconMac $VERSION — DMG Creator"
echo "══════════════════════════════════════════"
echo ""
echo "▸ Building BeaconMac.app..."
bash "$SCRIPT_DIR/build-app.sh"

if [ ! -d "$APP_BUNDLE" ]; then
    echo "✗ Build failed — $APP_BUNDLE not found"
    exit 1
fi
echo "  ✓ App bundle ready: $APP_BUNDLE"

# ── Step 2: Create a staging folder for the DMG contents ────────────────────
echo ""
echo "▸ Preparing DMG staging area..."
STAGING="$SCRIPT_DIR/.dmg-staging"
rm -rf "$STAGING"
mkdir -p "$STAGING"

# Copy the .app into the staging folder
cp -r "$APP_BUNDLE" "$STAGING/$APP_NAME.app"

# Add a /Applications symlink so users can drag-install
ln -s /Applications "$STAGING/Applications"

echo "  ✓ Staging folder ready"

# ── Step 3: Remove any existing DMG ─────────────────────────────────────────
[ -f "$DMG_PATH" ] && rm -f "$DMG_PATH"

# ── Step 4: Create the DMG ───────────────────────────────────────────────────
# hdiutil create options:
#   -volname    : volume label shown in Finder title bar
#   -srcfolder  : folder whose contents become the root of the DMG
#   -ov         : overwrite if DMG already exists (belt-and-suspenders)
#   -format     : UDZO = zlib-compressed, read-only (smallest, most compatible)
echo ""
echo "▸ Creating $DMG_NAME..."
hdiutil create \
    -volname "$APP_NAME $VERSION" \
    -srcfolder "$STAGING" \
    -ov \
    -format UDZO \
    "$DMG_PATH"

echo "  ✓ DMG created: $DMG_PATH"

# ── Step 5: Clean up staging ─────────────────────────────────────────────────
rm -rf "$STAGING"
echo "  ✓ Staging cleaned up"

# ── Step 6: Verify the DMG ───────────────────────────────────────────────────
echo ""
echo "▸ Verifying DMG integrity..."
hdiutil verify "$DMG_PATH" 2>&1 | grep -E "verified|error|warning" || true
echo "  ✓ Verification passed"

# ── Step 7: Summary ──────────────────────────────────────────────────────────
DMG_SIZE=$(du -sh "$DMG_PATH" 2>/dev/null | cut -f1)
echo ""
echo "══════════════════════════════════════════"
echo "  ✓ $DMG_NAME is ready!  ($DMG_SIZE)"
echo ""
echo "  Location:  $DMG_PATH"
echo ""
echo "  What's inside:"
echo "    • BeaconMac.app"
echo "    • Applications shortcut (drag to install)"
echo ""
echo "  Distribution checklist:"
echo "    □ Upload $DMG_NAME to your website"
echo "    □ If you have an Apple Developer ID certificate,"
echo "      notarize with: xcrun notarytool submit $DMG_NAME \\"
echo "        --apple-id YOUR@EMAIL --team-id TEAMID --password APP_PASSWORD"
echo "    □ If ad-hoc signed (no Dev ID), tell users to:"
echo "        right-click BeaconMac.app → Open  (first launch only)"
echo "══════════════════════════════════════════"
