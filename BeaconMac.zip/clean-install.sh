#!/bin/bash
# =============================================================================
#  clean-install.sh — Kill, clean, rebuild, and reinstall BeaconMac
#
#  Run from the BeaconMac-Swift directory:
#    chmod +x clean-install.sh
#    ./clean-install.sh
#
#  What it does:
#    1. Kills any running BeaconMac process
#    2. Removes the previously installed .app from /Applications
#    3. Removes leftover preferences and support files
#    4. Resets the Accessibility TCC entry (requires sudo — skip if unwanted)
#    5. Rebuilds the app via build-app.sh
#    6. Copies the fresh .app to /Applications
# =============================================================================

set -e

APP_NAME="BeaconMac"
BUNDLE_ID="com.eyetechanalytics.BeaconMac"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_BUNDLE="$SCRIPT_DIR/$APP_NAME.app"
INSTALL_PATH="/Applications/$APP_NAME.app"

echo "────────────────────────────────────────"
echo "  Cleaning up $APP_NAME"
echo "────────────────────────────────────────"

# ── 1. Kill any running instance ─────────────────────────────────────────────
echo "▸ Stopping any running $APP_NAME instance..."
if pgrep -x "$APP_NAME" > /dev/null 2>&1; then
    pkill -x "$APP_NAME" && echo "  ✓ Killed $APP_NAME"
    sleep 0.5
else
    echo "  ✓ $APP_NAME is not running"
fi

# ── 2. Remove installed app ───────────────────────────────────────────────────
echo "▸ Removing installed app bundle..."
if [ -d "$INSTALL_PATH" ]; then
    rm -rf "$INSTALL_PATH" && echo "  ✓ Removed $INSTALL_PATH"
else
    echo "  ✓ No app found at $INSTALL_PATH"
fi

# ── 3. Remove preferences and caches ─────────────────────────────────────────
echo "▸ Removing preferences and caches..."

PREF_FILE="$HOME/Library/Preferences/$BUNDLE_ID.plist"
if [ -f "$PREF_FILE" ]; then
    rm "$PREF_FILE" && echo "  ✓ Removed $PREF_FILE"
fi

SUPPORT_DIR="$HOME/Library/Application Support/$APP_NAME"
if [ -d "$SUPPORT_DIR" ]; then
    rm -rf "$SUPPORT_DIR" && echo "  ✓ Removed $SUPPORT_DIR"
fi

CACHE_DIR="$HOME/Library/Caches/$BUNDLE_ID"
if [ -d "$CACHE_DIR" ]; then
    rm -rf "$CACHE_DIR" && echo "  ✓ Removed $CACHE_DIR"
fi

echo "  ✓ Preferences and caches cleared"

# ── 4. Reset Accessibility TCC entry ─────────────────────────────────────────
# This removes the "BeaconMac wants to control this computer" entry from
# System Settings → Privacy & Security → Accessibility, so macOS will prompt
# fresh on next launch.  Requires sudo.  Skip this block if you prefer to
# manage the permission manually.
echo "▸ Resetting Accessibility permission..."
if sudo tccutil reset Accessibility "$BUNDLE_ID" 2>/dev/null; then
    echo "  ✓ Accessibility permission reset for $BUNDLE_ID"
else
    # Ad-hoc builds may not have a stable bundle ID in TCC yet — that's fine.
    echo "  ✓ No TCC entry found for $BUNDLE_ID (normal for ad-hoc builds)"
fi

# ── 5. Rebuild ────────────────────────────────────────────────────────────────
echo ""
echo "────────────────────────────────────────"
echo "  Rebuilding $APP_NAME"
echo "────────────────────────────────────────"

cd "$SCRIPT_DIR"
chmod +x build-app.sh
./build-app.sh

# ── 6. Install to /Applications ───────────────────────────────────────────────
echo ""
echo "▸ Installing to /Applications..."
if [ -d "$APP_BUNDLE" ]; then
    cp -r "$APP_BUNDLE" /Applications/
    echo "  ✓ Installed to $INSTALL_PATH"
else
    echo "  ✗ App bundle not found at $APP_BUNDLE — build may have failed"
    exit 1
fi

echo ""
echo "────────────────────────────────────────"
echo "  ✓ $APP_NAME is ready in /Applications"
echo ""
echo "  Next step: open $APP_NAME.app and"
echo "  re-grant Accessibility permission"
echo "  when macOS prompts you."
echo "────────────────────────────────────────"
