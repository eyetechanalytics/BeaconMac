# BeaconMac — Code Review (April 2026)

Systematic pass over every Swift source file, build script, `Package.swift`, and `Info.plist`. Issues are ordered by severity. File:line references point at the exact location to edit.

---

## Bugs

### 1. `clean-install.sh` uses the wrong bundle ID — silently no-ops

`clean-install.sh:21` sets `BUNDLE_ID="com.local.BeaconMac"`, but the app's actual bundle ID (in `Info.plist:7` and `build-app.sh:16`) is `com.eyetechanalytics.BeaconMac`. Consequences:

- `rm "$HOME/Library/Preferences/com.local.BeaconMac.plist"` — file never exists; preferences are not cleared.
- `rm -rf "$HOME/Library/Caches/com.local.BeaconMac"` — same.
- `sudo tccutil reset Accessibility "com.local.BeaconMac"` — fails silently, script prints the "No TCC entry found" happy path.

**Fix:** change the constant to `com.eyetechanalytics.BeaconMac` (or source it from `Info.plist` with `defaults read`).

### 2. SearchPanel: stale "No matching guides" labels accumulate

`SearchPanel.swift:243–275` (`rebuildGuideList()`) removes every `GuideListItemButton` before rebuilding, but the empty-state `NSTextField` ("No matching guides") added at line 266 is not tracked in `guideButtons` and is never removed. Each transition from empty → non-empty → empty leaves an orphan label in `listStackView`. Over a long session this manifests as phantom blank rows above the results and extra VoiceOver stops (even with `setAccessibilityElement(false)` the layout cost remains).

**Fix:** remove *all* arranged subviews at the top of `rebuildGuideList()`, not just `guideButtons`. Something like:

```swift
for sub in listStackView.arrangedSubviews {
    listStackView.removeArrangedSubview(sub)
    sub.removeFromSuperview()
}
guideButtons.removeAll()
```

### 3. Menu bar hotkey label never refreshes after Preferences change

`AppDelegate.swift:354–359` (`openPreferences`) calls `buildMenu()` synchronously, right after `showPreferences()` returns. Since `showPreferences()` only orders the window front (it does not block), `buildMenu()` runs *before* the user has touched the UI. The comment on line 357 says "We use a notification posted by PreferencesWindow on save" — but no such notification is posted anywhere in `PreferencesWindow.swift`.

Net effect: after the user saves a new hotkey in Preferences, the menu-bar menu continues to show the old hotkey in "Open Shortcut Guide (⌃⌥G)" and the tooltip is likewise stale, until something else (e.g. `onPermissionGranted`) triggers a rebuild.

**Fix (pick one):**
- Have `PreferencesWindowController.saveTapped()` post a `Notification` (e.g. `.bmHotkeyChanged`) that `AppDelegate` observes and responds to by calling `buildMenu()` + `updateStatusTooltip()`.
- Or expose `GlobalHotkey.onSettingChanged` as a callback and have `AppDelegate` subscribe.

### 4. `build-app.sh:133` — `&& true` swallows a failure differently than intended

```bash
codesign --force --deep --sign - "$APP_BUNDLE" 2>/dev/null && true
```

Under `set -e`, this construction does *not* reliably suppress the exit code the way `|| true` does. If the ad-hoc signing fails, the script exits before printing the "no stable certificate" warning box the author clearly wants the user to see.

**Fix:** `codesign --force --deep --sign - "$APP_BUNDLE" 2>/dev/null || true`

### 5. `create-pkg.sh` readme announces the wrong default hotkey

`create-pkg.sh:91` (inside the generated `readme.html` heredoc):

> This lets it detect the global hotkey (default: Control + Shift + Space) from any app.

The actual default is `Control + Option + G` (see `HotkeySetting.swift:20` — `keyCode: 5, modifiers: ["ctrl", "alt"]`). Users installing from the PKG will be told something incorrect.

**Fix:** change to `Control + Option + G` (or parametrise from `HotkeySetting.default.displayString`, though that requires running Swift at build time — literal string is fine).

### 6. `UpdateChecker.showUpdateAlert` mentions "BeaconMac.zip" in body text

`UpdateChecker.swift:121`:

```
Click "Download BeaconMac.zip" to download the latest version directly.
```

But the button on the next line (`:124`) is `"Download BeaconMac.pkg"`. The prose and the button disagree — copy-paste leftover from when `.zip` was the distribution format.

**Fix:** change `.zip` → `.pkg` on line 121.

---

## Stale documentation / contradictions

### 7. `main.swift` and `Info.plist` claim the app switches to `.accessory`

`main.swift:8–26` and `Info.plist:27–36` both document an `.accessory` ↔ `.regular` switching scheme, including "restorePreviousApp() calls setActivationPolicy(.accessory)". But `AppDelegate.swift:42–51, 293–304` explicitly states the opposite: "The app always runs with .regular activation policy (never .accessory)." — and grep confirms `AppDelegate.swift` never calls `setActivationPolicy(.accessory)`.

The design changed to always-`.regular` but the old comments in `main.swift` and `Info.plist` were never updated. Future maintainers will be confused.

**Fix:** rewrite the comments in `main.swift` and `Info.plist` to match `AppDelegate.swift`'s narrative.

### 8. `ShortcutContent.swift` uses category `"Google Suite"`, docs say `"Google Workspace"`

`ShortcutContent.swift:169, 176, 183, 190, 197` all set `category: "Google Suite"`. `AI-HANDOFF.md:160` advertises `"Google Workspace"` as the canonical category name. Google itself rebranded from G Suite to Workspace in 2020. This is cosmetic (search-by-category still works because it's whatever's actually in the code), but it means a user typing "workspace" into the search field gets no hits.

**Fix:** change five occurrences in `ShortcutContent.swift` to `"Google Workspace"`. No other file references the string.

### 9. SearchPanel keyboard-help overpromises `[` / `]` heading navigation

`SearchPanel.swift:446–447` advertises:

```
[ : Previous heading
] : Next heading
```

for the guide window. But `HTMLGenerator.swift:371–375` only handles `ArrowUp` / `ArrowDown` in its `keydown` listener — there is no `[` or `]` handler in the generated JavaScript. Pressing `[` or `]` inside a guide does nothing (or whatever the webview default is).

**Fix options:**
- Add a matching `keydown` case for `[` and `]` in the HTMLGenerator script (iterate only `h2.section-header` for these two keys), *or*
- Remove the two lines from the help text.

### 10. Hard-coded version number in 6–7 places

`Beaconmac_version.txt`, `Info.plist:17` (CFBundleShortVersionString), `UpdateChecker.swift:25`, `AppDelegate.swift:364`, `build-app.sh:17`, `create-dmg.sh:22`, `create-pkg.sh:27` all independently hard-code `1.0.0`. Any future version bump requires touching all of them — high risk of drift (e.g. `UpdateChecker.currentVersion` lagging behind the actual build).

**Fix:** have the build scripts read `Beaconmac_version.txt` and patch `Info.plist` + `UpdateChecker.swift` from it, or at least cross-reference in a single `VERSION` file sourced by all scripts.

---

## Nits / low-priority

### 11. `AttributedStringRenderer.swift` is a 7-line dead stub

The whole file is a comment saying the file is unused. Safe to delete; `Package.swift` pulls in all files under `Sources/BeaconMac` automatically so removing it has no effect on the build.

### 12. `PreferencesWindow.stopRecording(save:)` — `save: true` is never passed

`stopRecording(save: false)` is the only call throughout the file (lines 254, 273, 302, 309, 339, 409, 423). The `save` parameter is effectively dead. Either remove the parameter or actually use it from `saveTapped()` to consolidate cleanup.

### 13. Redundant `searchField!` force-unwraps in `SearchPanel.swift`

`searchField` is an implicitly-unwrapped optional, so the `!` at `:518` (`element: searchField!`) is unnecessary. Cosmetic.

### 14. `Package.swift` uses `unsafeFlags` to force-link AppKit and WebKit

`Package.swift:22` — `swiftSettings: [.unsafeFlags(["-framework", "AppKit", "-framework", "WebKit"])]`. SwiftPM auto-links Apple frameworks when you `import` them on macOS targets. The `unsafeFlags` marks the target as "unsafe" and would prevent other packages from depending on it — fine for an executable, but ideally remove.

### 15. `AppDelegate.showAbout` hard-codes "BeaconMac 1.0.0"

Line 364 — should use `UpdateChecker.currentVersion` (the closest "single source of truth" inside the app binary).

### 16. `create-pkg.sh` assigns `PKG_SIGN_ARGS` and never uses it

Line 170 assigns `PKG_SIGN_ARGS="--sign \"$SIGN_ID\""`, but line 182 uses the independent `${SIGN_ID:+--sign "$SIGN_ID"}` expansion instead. Dead variable.

---

## What I did NOT find

- No syntax errors in any `.swift` file (file lengths and structural counts all match expected values: `ShortcutContent.swift` has 82 `Get*Content` declarations and 81 balanced triple-quoted string pairs, matching the 82 `ShortcutGuide` entries).
- No broken id → content-closure references in `allGuides`.
- No obvious retain cycles in closures — `[weak self]` is used consistently in escaping callbacks.
- No thread-safety issues in `GlobalHotkey`: the CGEventTap callback runs on the main run loop (the source is added to `CFRunLoopGetMain()`), and state mutation (`suppressFiring`, `currentSetting`) is confined to the main thread.
- The `dismissingForGuide` flag in `SearchPanel.openSelectedGuide` looks racy at first glance but is safe: `orderOut(_:)` posts `windowDidResignKey` synchronously, so the guard at `:577` fires while the flag is still `true`, before it is reset on the line after `hidePanel()`.
- Accessibility-related code (VoiceOver label prefixing, `.focusedWindowChanged` posts, WebKit warmup window with `.titled` styleMask) is consistent with the architectural rationale documented in `AI-HANDOFF.md`.

---

## Summary

Six real bugs, five documentation contradictions, six nits. The bulk of the code is in good shape; most of the issues above are the kind of drift that accumulates over several months of incremental changes.

If you want a follow-up pass where these get fixed, I'd recommend starting with issues 1, 2, and 3 — those have the most user-visible impact. Issue 5 should be fixed before the next public PKG release.
