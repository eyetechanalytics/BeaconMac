# BeaconMac — Installation & Setup Guide

**EyeTech Analytics** | beacon@eyetechanalytics.com | (859) 212-3668

---

## Quick Start (Pre-built App)

If you have received a pre-built `BeaconMac.app`:

1. **Copy to Applications**
   Drag `BeaconMac.app` into your `/Applications` folder.

2. **First Launch**
   Double-click `BeaconMac.app`. If macOS shows a Gatekeeper warning ("cannot be opened because it is from an unidentified developer"), right-click the app and choose **Open**, then confirm in the dialog.

3. **Grant Accessibility Permission**
   BeaconMac requires Accessibility access to register its global hotkey. On first launch it shows a plain-English setup dialog explaining exactly what to do:

   > *"To open the shortcut guide from any app using Control+Option+G, BeaconMac needs Accessibility permission from macOS."*
   >
   > 1. Click **Open Settings** in that dialog
   > 2. Find **BeaconMac** in the list and flip its switch to **ON**
   > 3. macOS will ask for your **password or Touch ID** to confirm

   The keyboard shortcut activates immediately once you flip the switch — no restart needed.

   If the dialog does not appear, open System Settings manually, navigate to **Privacy & Security → Accessibility**, click the **+** button, and add `BeaconMac.app`.

4. **Verify the Menu Bar Icon**
   After launching, a small keyboard icon (⌨) appears in the menu bar. Select it to access Preferences or to quit. Keyboard/VoiceOver users: press **Ctrl + F8** to focus the menu bar, arrow to the BeaconMac icon, and press **Return** to open the menu.

5. **Open BeaconMac**
   Press the default hotkey (**Control + Option + G** — or your configured shortcut) from any application. The search panel will appear. Start typing to find a guide.

---

## Configuring Your Hotkey

1. Open the BeaconMac menu bar icon (⌨) and choose **Preferences…** — keyboard users: press **Ctrl + F8** to focus the menu bar, arrow to the BeaconMac icon, and press **Return**; then use arrow keys to choose Preferences and press **Return**.
2. Press the **Change Hotkey** button (Tab to it, then Space or Return), then press your desired key combination (e.g., Control + Option + G, Command + Shift + /, etc.).
3. Press **Return** or **Save**. The new hotkey takes effect immediately.

> **Tip:** Choose a combination that doesn't conflict with any app you use frequently. Control + Option combinations are rarely used by other applications.

---

## Building from Source

### Prerequisites

- **macOS 12.0 or later**
- **Xcode Command Line Tools** (includes the Swift compiler)

  Install via Terminal:
  ```
  xcode-select --install
  ```

### Steps

1. **Clone or download the repository**
   ```
   git clone https://github.com/eyetechanalytics/BeaconMac.git
   cd BeaconMac/BeaconMac-Swift
   ```

2. **Make the build script executable**
   ```
   chmod +x build-app.sh
   ```

3. **Build the app**
   ```
   ./build-app.sh
   ```
   The script compiles a release binary, assembles the `.app` bundle, signs it, and removes the quarantine attribute for local testing.

4. **Install**
   ```
   cp -r BeaconMac.app /Applications/
   ```

5. **Launch and grant Accessibility permission** (see Quick Start steps 2–4 above)

### Code Signing (Recommended)

The build script will warn if no stable code-signing certificate is found and will fall back to an ad-hoc signature. An ad-hoc signature changes on every build, causing macOS to revoke the Accessibility permission after each rebuild.

To avoid re-granting permission on every build, create a free local certificate once:

1. Open **Keychain Access**
2. Menu: **Certificate Assistant → Create a Certificate…**
3. Name: `BeaconMac-Dev`
   Identity Type: `Self Signed Root`
   Certificate Type: `Code Signing`
4. Accept all defaults and click **Create**
5. Re-run `./build-app.sh` — the script will detect and use the certificate automatically

---

## Adding or Editing Guides

Guides are defined in:
```
Sources/BeaconMac/ShortcutContent.swift
```

Each guide is a `ShortcutGuide` entry in the `allGuides` array plus a corresponding content closure. Content uses a plain-text format with three element types:

```
-- Section Header --
>> Section note — italic callout block rendered below the header

Key: Action :: Context description    ← three-column row (key | action | context)
Key: Description                      ← two-column row (backward-compatible)

Plain note text (no colon in key position = italic grey line)
```

After editing, rebuild with `./build-app.sh` and copy the updated app to Applications.

---

## App Detection Mappings

BeaconMac can automatically suggest the relevant guide when you switch to a specific application. These mappings live in:
```
Sources/BeaconMac/AppDetector.swift
```

Add a new entry matching the app's bundle identifier (e.g., `com.microsoft.Word`) to the guide ID defined in `ShortcutContent.swift`.

---

## Uninstalling

1. Quit BeaconMac (open the menu bar icon ⌨ → Quit, or press **Cmd + Q** while a BeaconMac window is active)
2. Delete `/Applications/BeaconMac.app`
3. Remove Accessibility permission: System Settings → Privacy & Security → Accessibility → select BeaconMac → press the `–` button

---

## Troubleshooting

**Hotkey doesn't work**
BeaconMac shows a setup dialog on first launch guiding you through the permission. If you dismissed it, open the menu bar icon (⌨) — a ⚠ warning item will be visible. Click it to go directly to System Settings → Privacy & Security → Accessibility, then flip BeaconMac's switch ON and enter your password or Touch ID when prompted. The hotkey activates within one second of granting access.

**App blocked by Gatekeeper**
Right-click `BeaconMac.app` and choose **Open**, then confirm. This only needs to be done once per build.

**Accessibility permission revoked after rebuild**
You rebuilt with an ad-hoc signature. Create a local code-signing certificate (see Code Signing section above) so the identity is stable across builds.

**Panel doesn't appear on the correct display**
The panel appears on whichever display your cursor is on when the hotkey is pressed.

---

## Support

EyeTech Analytics
Email: beacon@eyetechanalytics.com
Phone: (859) 212-3668
Website: https://eyetechanalytics.com/projects/
