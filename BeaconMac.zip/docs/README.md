# BeaconMac

**A native macOS keyboard shortcut reference tool by [EyeTech Analytics](https://eyetechanalytics.com/projects/)**

---

## Overview

BeaconMac is a lightweight, fully native macOS application that gives you instant access to keyboard shortcut reference guides for macOS and popular applications — all from a single floating search panel that appears over any app with a single keypress.

No browser tabs. No digging through menus. Just press your configured hotkey from anywhere, type a few letters, and open the guide you need in under two seconds.

BeaconMac is built with accessibility as a first-class priority. Every guide is fully navigable with VoiceOver, supports H-key heading navigation, and announces shortcut entries clearly when arrowing through content.

---

## Features

- **82 built-in guides** covering macOS, Microsoft Office, Google Workspace, Apple iWork, creative tools, developer tools, communication apps, and more
- **Instant search** — type any part of an app name or category and the list filters in real time
- **Floating panel** — appears over any application; dismisses with Escape and leaves your previous focus intact
- **Full VoiceOver support** — panel announcements, H-key heading navigation, per-row aria-labels, and dedicated VoiceOver Tips sections in guides for Safari, Finder, Mail, Calendar, Notes, Messages, Terminal, Slack, VS Code, Word, Google Docs, Pages, Numbers, Keynote, and more
- **Auto-detects frontmost app** — optionally jumps directly to the relevant guide for the app you're currently using
- **Light and dark mode** — guide windows use `prefers-color-scheme` and adapt automatically
- **Configurable hotkey** — set any modifier + key combination via the menu bar Preferences window
- **Launch at Login** — optional setting to start BeaconMac automatically at login (macOS 13 Ventura or later)
- **MIT licensed** — free to use, modify, and redistribute

---

## Guide Categories

| Category | Guides |
|---|---|
| General | Introduction, Browse All, Modifier Keys |
| macOS System | System shortcuts, Command shortcuts, Clipboard, Text Navigation, App Switching, Screenshots |
| macOS Built-in Apps | Finder, Safari, Mail, Calendar, Notes, Photos, Preview, Terminal, TextEdit, Messages, FaceTime, Reminders, Music, Contacts, iMovie, GarageBand |
| Microsoft Office (Mac) | Word, Excel, PowerPoint, Outlook, OneNote |
| Office 365 Online | Word Online, Excel Online, PowerPoint Online, Outlook Online, OneNote Online, Teams Web, OneDrive, SharePoint |
| Google Workspace | Docs, Sheets, Slides, Gmail, Meet |
| Apple iWork | Pages, Numbers, Keynote |
| Other Apps | Browser (Chrome/Firefox), Zoom, Teams Desktop, Adobe Acrobat, Slack, VS Code, Xcode, Discord, Figma, Sketch, 1Password, Obsidian, Notion, Bear, iTerm2, WhatsApp |
| Multimedia | YouTube, VLC, Spotify, QuickTime, Final Cut Pro, Logic Pro, Pro Tools, REAPER, Adobe Photoshop, Adobe Illustrator, Adobe Premiere Pro |
| Accessibility | Overview, VoiceOver, Zoom Magnifier, Voice Control, Dictation, Flo Tools, PTAccess, Libby |

---

## System Requirements

- **macOS 12.0 Monterey or later**
- Accessibility permission (required for global hotkey): on first launch BeaconMac shows a plain-English dialog explaining exactly what to enable and where; the hotkey activates the moment you flip the switch — no restart required

---

## License

BeaconMac is distributed under the [MIT License](../LICENSE).
Copyright © 2025–2026 EyeTech Analytics

---

## Contact

**EyeTech Analytics**
Phone: (859) 212-3668
Email: beacon@eyetechanalytics.com
Website: https://eyetechanalytics.com/projects/
