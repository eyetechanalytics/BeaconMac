# ShortcutContent.swift — Verification Changelog

This document summarises the corrections made to `Sources/BeaconMac/ShortcutContent.swift` during a systematic verification pass of every shortcut guide in the file. Shortcuts were checked against official vendor documentation and Mac defaults.

## Summary

- Batches 1–9 (meeting/chat apps, Microsoft Office for Mac, Office 365 online, Google Workspace, macOS system, macOS built-in apps, iWork, developer tools) were verified in earlier sessions with corrections applied in-place.
- Batches 10–13 (creative tools, productivity apps, multimedia, accessibility guides) were verified in the most recent session — corrections listed below.
- Final structural integrity check: file contains 82 `Get*Content` functions with 81 balanced triple-quoted string pairs (one function returns an empty string by design). No syntax regressions detected.

## Batch 10 — Creative Tools

### Figma
- **Ellipse tool**: changed `E` → `O` (the `E` key does not activate the ellipse tool in Figma).
- **Toggle UI**: changed `Cmd + Shift + H` → `Cmd + \` (the correct Figma shortcut on macOS; `Cmd + Shift + H` hides selected layers).

### Sketch
- **Hand tool**: replaced `H` with `Hold Space: Pan canvas` (Sketch pans by holding Space, not a dedicated `H` tool key).
- **Colour picker**: changed `I` → `Ctrl + C` (Sketch samples colour via the inspector, not a standalone `I` shortcut).
- **Toggle rulers**: changed `Cmd + Shift + H` → `Ctrl + R` (the actual Sketch rulers shortcut).

### Adobe Premiere Pro
- **Delete vs. ripple delete** were reversed. Corrected to: `Delete` clears the selection leaving a gap, `Shift + Delete` is ripple delete.
- **Previous/next edit point**: changed `Cmd + Left/Right` → `Up Arrow` / `Down Arrow` (the Premiere defaults on Mac).
- **Add edit at playhead**: `Cmd + K` razors targeted tracks only; added `Shift + Cmd + K` for adding an edit to all tracks (the existing description incorrectly claimed `Cmd + K` cut all tracks).
- **Panel focus**: changed `Cmd + 1`–`Cmd + 4` (Project / Source / Timeline / Program) to `Shift + 1`–`Shift + 4`, matching Premiere Pro's default panel-focus shortcuts on Mac.

### Final Cut Pro
- **Audio meters**: changed `Cmd + Shift + H` → `Cmd + Shift + 8`.
- **Browser**: changed `W` → `Cmd + 1` (consistent with other view toggles).
- **Color Board**: updated to `Color Inspector` (terminology change in Final Cut Pro X).
- **Append to timeline**: changed `G` → `E` (FCP's append shortcut is `E`).
- **Overwrite/Replace**: `D` is Overwrite at playhead (not "Replace with gap"). Replace-with-gap uses `Shift + Delete`, which is already listed in the timeline-editing section.
- **Insert freeze frame**: changed `Cmd + Shift + F` → `Option + F`.

### Logic Pro
- **Cycle toggle**: changed `F` → `C` (Logic Pro uses `C` to toggle cycle mode).
- **Join regions**: changed `Cmd + G` → `Cmd + J` (`Cmd + J` is the documented Join Regions shortcut).
- **Duplicate region**: corrected the description of `Cmd + D` (it duplicates; looping is a separate `L` toggle).

### Pro Tools
- **Edit / Mix windows**: `Cmd + =` toggles between the two; removed the incorrect standalone `Cmd + L: Mix window` line.
- **Transport window**: changed `Cmd + 9` → `Cmd + 1`.
- **Video window**: changed `Cmd + Shift + J` → `Cmd + 9`.

### Photoshop, Illustrator, REAPER
- Verified against official Adobe and REAPER/OSARA documentation — no changes required.

## Batch 11 — Productivity Apps

### Browser (Chrome / Firefox)
- **Private window**: added a separate line for Firefox's `Cmd + Shift + P` alongside Chrome/Safari's `Cmd + Shift + N`.

### Adobe Reader / Acrobat
- **Full screen**: changed `Cmd + 4` → `Cmd + L` (the documented Acrobat shortcut).
- **Navigation pane**: changed `Cmd + Shift + H` → `F4` (resolves a duplicate-shortcut conflict in the same section).
- **Highlight tool**: changed `Cmd + Shift + H` → `U` (single-key accelerators), with a note that Preferences must have "Use single-key accelerators" enabled.

### Obsidian
- **Back / forward**: changed `Alt + Left/Right` → `Cmd + Option + Left/Right` (Obsidian's documented Mac defaults).

### 1Password, Notion, Bear
- Verified against vendor documentation — no changes required.

## Batch 12 — Multimedia

### YouTube
- **Next / previous video** in playlist: changed `Option + Right/Left` → `Shift + N` / `Shift + P` (YouTube's documented playlist shortcuts).

### VLC
- **Stop**: changed `S` → `Cmd + .` (the Mac-standard VLC Stop shortcut).
- **Playlist navigation**: `Cmd + Right` and `Cmd + Left` are Next/Previous in playlist on Mac (the existing text used these for seeking, which is wrong).
- **Full screen**: changed `F` → `Cmd + F` (the Mac menu binding; bare `F` may still work as a secondary).
- **Seek by 1 minute**: changed `Cmd + Right/Left` → `Cmd + Shift + Right/Left` (the VLC Mac "Medium Jump" default).
- **Seek by 10 seconds**: changed `Option + Right/Left` → `Cmd + Option + Right/Left` (VLC Mac "Short Jump").
- **Seek by 3 seconds**: changed `Shift + Right/Left` → `Cmd + Ctrl + Right/Left` (VLC Mac "Very Short Jump").

### QuickTime Player
- **Timecode display line removed**: it duplicated `Cmd + T` with Trim. QuickTime Player has no standalone timecode toggle with that shortcut.
- **Split clip**: changed `Cmd + K` → `Cmd + Y` (the QT Player menu shortcut for splitting a clip at the playhead).
- **New Screen Recording**: changed `Cmd + Option + S` → `Cmd + Ctrl + N` (macOS Mojave+ QuickTime shortcut).

### Spotify
- Verified against vendor documentation — no changes required.

## Batch 13 — Accessibility Guides

### PTAccess
- **Edit / Mix window navigation**: `Cmd + =` toggles between Edit and Mix (same as the Pro Tools section fix). Replaced the incorrect `Cmd + L: Mix window` line with a correct `Cmd + 1: Transport window` entry.

### VoiceOver, Accessibility Overview, System Zoom, Voice Control, Dictation, Flo Tools, Libby
- Verified against Apple and vendor documentation — no changes required.

## Structural Check

- File length: 5184 lines (unchanged trend from verification edits).
- `return """` openings: 81
- Closing `"""` markers at column 1: 81 (balanced)
- `Get*Content` function declarations: 82 (81 multi-line + 1 one-liner returning an empty string for `BrowseAll`).
- No orphaned brace mismatches or malformed string literals detected.

## Notes

- Several of the shortcuts in this file differ from their Windows/Linux counterparts; this verification pass explicitly preserves the Mac-specific defaults.
- Where Pro Tools / Logic Pro shortcuts depend on user-selectable keyboard focus modes (Commands vs. Transport keypad), the documented default modes are used.
- REAPER shortcuts assume the OSARA key map imported via reaperaccessibility.com.
