# BeaconMac — Website Blurb

*Copy and paste options below. Short version for cards/previews, long version for a dedicated project page.*

---

## Short Version (Card / Preview / Meta Description — ~60 words)

**BeaconMac** is a free, native macOS tool that puts 82 keyboard shortcut reference guides one keypress away. Press your hotkey from any app, type a few letters to search, and instantly open the guide you need — no browser, no mouse required. Fully VoiceOver accessible. Built for macOS 12 and later.

[Download BeaconMac](https://eyetechanalytics.com/projects/) · MIT License

---

## Medium Version (Project Card — ~120 words)

### BeaconMac — Instant Keyboard Shortcut Reference for macOS

Stop losing your flow to forgotten keyboard shortcuts. **BeaconMac** is a lightweight, native macOS application that gives you instant access to shortcut guides for 82 apps — right from your current workspace.

Press a single hotkey, type the name of any app, and open a clean, readable reference guide in under two seconds. When you're done, press Escape and you're right back where you were.

Built with accessibility in mind, BeaconMac is fully compatible with VoiceOver and supports keyboard-only navigation throughout.

Covers macOS, Microsoft Office, Google Workspace, Adobe Creative Suite, Final Cut Pro, Logic Pro, developer tools, and much more.

**Free · Open Source · MIT License · macOS 12+**

[View Project →](https://eyetechanalytics.com/projects/)

---

## Long Version (Full Project Page — ~300 words)

### BeaconMac

**Instant keyboard shortcut reference — always one keypress away.**

Developed by EyeTech Analytics, BeaconMac is a free, native macOS application that solves a simple but persistent problem: you know there's a keyboard shortcut for what you're trying to do, but you can't quite remember it — and looking it up means leaving your app, opening a browser, and hunting through documentation.

BeaconMac puts that reference a single hotkey away, right on top of whatever you're working on.

**How it works**

Press your configured hotkey from any application. A compact floating search panel appears instantly. Start typing the name of any app or category — the list filters as you type. Select a guide and a clean, scrollable reference window opens with every shortcut organized by section. Press Escape when you're done and your previous focus is restored.

**What's included**

BeaconMac ships with 82 built-in shortcut guides across ten categories:

- macOS system shortcuts, Finder, Safari, Mail, Messages, Calendar, Notes, Photos, FaceTime, Reminders, Music, iMovie, GarageBand
- Microsoft Office for Mac (Word, Excel, PowerPoint, Outlook, OneNote) and Office 365 Online equivalents
- Google Workspace (Docs, Sheets, Slides, Gmail, Meet)
- Apple iWork (Pages, Numbers, Keynote)
- Creative tools (Adobe Photoshop, Illustrator, Premiere Pro, Final Cut Pro, Logic Pro, Figma, Sketch)
- Developer tools (VS Code, Xcode, Terminal, iTerm2)
- Communication apps (Slack, Discord, Microsoft Teams, Zoom, WhatsApp)
- Note-taking and productivity (Obsidian, Notion, Bear, 1Password)
- Accessibility tools (VoiceOver, Voice Control, Dictation, Zoom Magnifier)

**Accessibility first**

BeaconMac is built to work seamlessly with VoiceOver. The search panel announces guide titles as you navigate, guide content supports H-key heading navigation, and every shortcut row is read as a single combined announcement. Most guides also include a dedicated VoiceOver Tips section with app-specific screen reader commands, navigation strategies, and accessibility settings — covering Safari, Finder, Mail, Notes, Calendar, Messages, Terminal, VS Code, Slack, Word, Google Docs, Pages, Numbers, Keynote, and more.

**Open source · MIT License · Free to use and modify**

System Requirements: macOS 12.0 Monterey or later

---

*EyeTech Analytics · (859) 212-3668 · beacon@eyetechanalytics.com · https://eyetechanalytics.com/projects/*
