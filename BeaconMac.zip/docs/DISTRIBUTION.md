# BeaconMac — Distribution & Architecture Guide

**EyeTech Analytics** | beacon@eyetechanalytics.com

---

## Can I Distribute BeaconMac from My Website?

**Yes.** You can absolutely host BeaconMac on your website and let users download it directly. This is called "outside the Mac App Store" distribution, and it is fully supported by macOS. There are a few things to understand about how it works.

---

## What Users Will Experience When Downloading

When a user downloads a `.app` or `.zip` from a website, macOS applies a **quarantine attribute** to the file. What happens next depends on how the app is signed:

### Option A — Ad-hoc signed only (current default build)

The app is signed with a hash-based identity tied to that specific build. Users will see:

> *"BeaconMac.app cannot be opened because it is from an unidentified developer."*

The user can still open it by **right-clicking → Open → Open** (one-time only). After that it opens normally. This works fine for technically comfortable users but creates friction for general audiences.

### Option B — Developer ID signed + Notarized (recommended for public distribution)

You sign the app with an Apple Developer ID certificate and submit it to Apple's notarization service. Apple scans it for malware and attaches a ticket. Users then see:

> *"BeaconMac is from a verified developer."*

The app opens on the first double-click with no warnings. This is the professional distribution path.

**Cost:** Apple Developer Program membership is required — currently **$99 USD/year**.

### Option C — Self-signed certificate (good for known users)

The app is signed with a locally-created certificate (the BeaconMac-Dev certificate described in INSTALL.md). This gives the app a stable identity so Accessibility permissions don't get revoked, but it does NOT satisfy Gatekeeper for other people's machines. Users still see the "unidentified developer" warning and must right-click → Open.

---

## Recommended Distribution Workflow (Without Apple Developer Account)

If you want to distribute without paying for the Developer Program:

1. Build with `./build-app.sh`
2. Create a ZIP: `cd BeaconMac-Swift && zip -r BeaconMac-1.0.0.zip BeaconMac.app`
3. Host the ZIP on your website
4. Include clear instructions: *"Right-click the app and choose Open the first time you launch it"*
5. Link to your `INSTALL.md` for the full Accessibility permission setup

This works well and many Mac utilities are distributed this way.

---

## Recommended Distribution Workflow (With Apple Developer Account)

1. Enroll at https://developer.apple.com/programs/
2. Create a **Developer ID Application** certificate in Xcode or Keychain Access
3. Build: `./build-app.sh` (the script automatically picks up Developer ID certs)
4. Notarize:
   ```bash
   # Create a ZIP for notarization
   zip -r BeaconMac.zip BeaconMac.app

   # Submit to Apple (requires app-specific password from appleid.apple.com)
   xcrun notarytool submit BeaconMac.zip \
     --apple-id "your@email.com" \
     --team-id "YOUR_TEAM_ID" \
     --password "xxxx-xxxx-xxxx-xxxx" \
     --wait

   # Staple the notarization ticket to the app
   xcrun stapler staple BeaconMac.app

   # Re-zip for distribution
   zip -r BeaconMac-1.0.0.zip BeaconMac.app
   ```
5. Host the stapled ZIP on your website — users can now double-click to open with no warnings

---

## Intel vs. Apple Silicon — Will It Run on Both?

### The Short Answer

**Not automatically.** The current build script (`swift build -c release`) compiles for **the architecture of the machine you build on**:

- Built on an **Apple Silicon Mac** (M1, M2, M3, M4, etc.) → produces an **arm64** binary → runs natively on Apple Silicon, **does not run on Intel**
- Built on an **Intel Mac** → produces an **x86_64** binary → runs on Intel, runs on Apple Silicon via **Rosetta 2** (translation layer), but not natively

### What You Probably Want: A Universal Binary

A **universal binary** (also called a "fat binary") contains both the arm64 and x86_64 versions of the code inside a single `.app`. It runs natively on both chip families with no Rosetta translation.

### How to Build a Universal Binary

You must be on an Apple Silicon Mac with Xcode Command Line Tools installed. Run:

```bash
# Build for Apple Silicon (arm64)
swift build -c release --arch arm64

# Build for Intel (x86_64)
swift build -c release --arch x86_64

# Combine both into a universal binary using lipo
lipo -create \
  .build/arm64-apple-macosx/release/BeaconMac \
  .build/x86_64-apple-macosx/release/BeaconMac \
  -output .build/release/BeaconMac

# Now run the rest of the build script manually (bundle creation + signing)
```

> **Note:** You can only cross-compile for x86_64 from an Apple Silicon Mac. You cannot build an arm64 binary on an Intel Mac. So universal binaries must be built on Apple Silicon.

### Updating build-app.sh for Universal Builds

To make the build script produce a universal binary automatically, the `swift build` line would need to be replaced with the three-step `arm64` + `x86_64` + `lipo` sequence above. Ask your AI assistant or developer to update `build-app.sh` if you want this baked into the standard build process.

### Do You Need to Support Intel?

As of 2024, the Mac installed base is rapidly shifting to Apple Silicon. Intel Macs are still in use but Apple stopped making them in 2023. Rosetta 2 (built into every Apple Silicon Mac) transparently runs Intel binaries, so even without a universal build, an arm64 BeaconMac will run fine on Apple Silicon, and an x86_64 BeaconMac will run on Intel machines plus Apple Silicon via Rosetta.

**Practical recommendation:**
- If most of your users are on newer Macs (2020 and later): build on Apple Silicon, distribute arm64 — it will run natively on Apple Silicon and via Rosetta on Intel
- If you want maximum compatibility with no Rosetta dependency: build a universal binary using the steps above
- If you have an Apple Developer account and are notarizing: build universal — it is the professional standard

---

## Hosting on Your Website

There is no restriction on hosting a macOS `.app` or `.zip` on your website. Some practical notes:

- Distribute as a **ZIP file** — `.app` bundles are directories, and browsers handle ZIPs better than naked directories
- Use a versioned filename like `BeaconMac-1.0.0.zip` so users can tell which version they have
- Host the `INSTALL.md` or a condensed version of it on your site so users know how to grant Accessibility permission
- If you update the app, bump the version number in `build-app.sh` (`VERSION="1.0.0"` near the top of the file) before rebuilding

---

## System Requirements for End Users

| Requirement | Details |
|---|---|
| macOS version | 12.0 Monterey or later |
| Architecture | arm64 (Apple Silicon), x86_64 (Intel), or Universal |
| Accessibility permission | Required — user grants once in System Settings |
| Apple Developer account | Not required to run; required only to notarize |
| Internet connection | Not required (fully offline) |

---

## Summary

| Scenario | Works? | User Experience |
|---|---|---|
| Download on same architecture as build machine | ✅ Yes | Right-click → Open first time (no Developer ID) |
| Download on different architecture, no Rosetta | ❌ No | App won't launch |
| Download on Apple Silicon, Intel binary via Rosetta | ✅ Yes | Right-click → Open first time; slight perf cost |
| Universal binary, no notarization | ✅ Both chips | Right-click → Open first time |
| Universal binary, Developer ID + notarized | ✅ Both chips | Double-click, no warnings |

---

*EyeTech Analytics · (859) 212-3668 · beacon@eyetechanalytics.com · https://eyetechanalytics.com/projects/*
